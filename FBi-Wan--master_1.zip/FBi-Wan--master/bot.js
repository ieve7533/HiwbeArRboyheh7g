const Discord = require('discord.js');
const client = new Discord.Client();
const moment = require('moment');
const zalgo = require('zalgolize');
const math = require('math-expression-evaluator');
const figlet = require('figlet');
const fs = require('fs');
const ms = require('ms');
const {
    prefix,
    devs,
} = require('./config')




client.on('message', msg => {
    if (msg.content === 'باك') {
        msg.reply('** :wink: وِلِـكُمِـ ﻧَوِرُتْ   :sparkling_heart:**');
    }
});



client.on('message', msg => {
    if (msg.content === `<@670993199011201025>`) {
        msg.reply('**لا تمنشني يا ورع**');
    }
});


client.on('message', msg => {

    if (msg.content === `<@266968615733952512>`) {

        msg.reply('**مشغول الحين😁**');

    }

});


client.on('message', msg => {
    if (msg.content === `<@598973121390837761>`) {
        msg.reply('**حبوسة السمبوسة مشغول**');
    }
});





client.on('message', msg => {
    if (msg.content === 'احبك') {
        msg.reply('** و انا كمان**');
    }
});



client.on('message', msg => {
    if (msg.content === 'هلا') {
        1
        msg.reply('**هلا بيك :heart: **');
    }
});


client.on('message', msg => {
    if (msg.content === 'السلام عليكم') {
        1
        msg.reply('**و عليكم السلام :heart: **');
    }
});





client.on("message", message => {
    if (message.content.startsWith(prefix + 'v2min') || message.content.startsWith(prefix + 'فويس')) {
        let args = message.content.split(" ").slice(1);
        var nam = args.join(' ');

        if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('`ADMINISTRATOR` للأسف هذه الخاصية تحتاج الى ').then(msg => msg.delete(6000))
        if (!nam) return message.channel.send(`<@${message.author.id}> يجب عليك ادخال اسم`).then(msg => msg.delete(10000))
        message.guild.createChannel(nam, 'voice').then(c => setTimeout(() => c.delete(), 120000))
        message.channel.send(`:ballot_box_with_check: TemporarySound : \`${nam}\``).then(c => setTimeout(() => c.edit(`<@${message.author.id}> :stopwatch:  انتهى وقت الروم الصوتي`), 120000))
    }
});

client.on("message", message => {
    if (message.content.startsWith(prefix + "emoji") || message.content.startsWith(prefix + 'ايموجي')) {
        var emojiid = message.content.split(" ").slice(1).join(" ")
        console.log(emojiid)
        if (emojiid.length < "18" || emojiid.length > "18" || isNaN(emojiid)) return message.channel.send(`- Usage  
${prefix}emoji <EmojiID>`);
        else
            message.channel.send("This is the emoji that you requested:-", {
                files: [`https://cdn.discordapp.com/emojis/${emojiid}.png`]
            })
    }
})



client.on("message", message => {
    if (message.channel.type === "dm") {

        message.channel.startTyping();
        setTimeout(() => {
            message.channel.stopTyping();
        }, Math.random() * (1 - 3) + 1 * 1000);

    }
});

const clans = {};
const system = {};
const level = {};


client.on('message', async message => {
    if (message.author.bot) return;
    if (message.channel.type === 'dm') return;

    let args = message.content.split(' ');
    let random = Math.floor(Math.random() * 5) + 2;
    let author = message.author;

    let xpLeft;
    let nameClan;
    let membersClan = [];
    let levelClan = 0;
    if (!system[author.id]) system[author.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };

    if (!level[author.id]) level[author.id] = { level: 1, xp: 1 };


    level[author.id].xp += (+random);
    if (level[author.id].xp >= 300) {
        if (level[author.id].xp > 300) xpLeft = level[author.id].xp - 300;
        level[author.id] = {
            level: level[author.id].level + 1,
            xp: xpLeft
        };

    }
    if (message.content.startsWith(prefix + "clan") || message.content.startsWith(prefix + "كلان") || message.content.startsWith("كلان")) {
        if (message.content.split(' ')[0] !== `${prefix}clan`) return;

        if (!args[1] || args[1] && args[1] === 'info') {
            let embed = new Discord.RichEmbed()
                .setAuthor('الكلانات', message.author.avatarURL)
                .setDescription(`- \`${prefix}clan\`: نظام الكلانات هو نظام شبه مسلي ينمي التفاعل ويمكنك التحكم بالكلان تبعك بشكل كامل
  - \`${prefix}clan info\`: لأظهار رسالة الأوامر ( هذه الرسالة ) ء
  - \`${prefix}clan create\`: لأنشاء كلان بالأسم الذي تريده
  - \`${prefix}clan invite\`: لدعوة شخص ما للكلان تبعك
  - \`${prefix}clan join\`: للتقديم على دخول الكلان الذي تريده
  - \`${prefix}clan promote\`: لأعطاء شخص بالكلان صلاحيات الادمن ( يتطلب صلاحية الادمن ) ء
  - \`${prefix}clan demote\`: لأزالة صلاحية الادمن من عضو بالكلان ( صاحب الكلان فقط ) ء
  - \`${prefix}clan ownership\`: لنقل ملكيةالكلان
  - \`${prefix}clan leave\`: للخروج من الكلان الذي انت به
  - \`${prefix}clan kick\`: لطرد عضو من الكلان ( يتطلب صلاحية الادمن ) ء
  - \`${prefix}clan disband\`: لمسح الكلان من السستم ( صاحب الكلان فقط ) ء
  - \`${prefix}clan stats\`: لعرض معلومات الكلان تبعك
  - \`${prefix}clan list\`: يظهر لك اعضاء الكلان برسالة
  - \`${prefix}clan accept\`: لقبول شخص وجعل الشخص يدخل الكلان ( يتطلب صلاحية الادمن ) ء
  - \`${prefix}clan decline\`: لرفض شخص وعم جعل الشخص يدخل الكلان ( يطلب صلاحية الادمن ) ء
  - \`${prefix}clan room\`: لعمل روم شات او كتابي بأسم الكلان ( صاحب الكلان فقط ) ء`)
                .setFooter(message.author.username, message.author.avatarURL);
            message.channel.send(embed);
        }

        if (args[1] && args[1] === 'create') {
            if (level[author.id].level < 10) return message.channel.send('**# يجب أن يكون لديك 10 مستويات لعمل كلان , لتجميع مستويات تفاعل بالشات وسيتم حساب النقاط**');
            if (system[author.id].clan !== 'None') return message.channel.send('**# يجب عليك ان تخرج من الكلان الذي أنت به حاليا**');

            let m = await message.channel.send('**# أكتب أسم الكلان الان**');
            let awaited = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 20000, errors: ['time'] }).then(collected => {
                if (collected.first().content.length > 25) return message.channel.send("**# لا يمكنك وضع اسم للكلان يفوق الـ25 حرفا , أعد كابة الأمر**");
                if (collected.first().content.includes("None")) return message.channel.send("**# `None`, لا يمكنك وضع هذه الكلمة كأسم للكلان**");
                collected.first().delete().catch();
                nameClan = collected.first().content;
            });

            m = await m.edit('**# جارى عمل الكلان**');
            awaited = await setTimeout(async() => {
                let membersArray = {
                    nameClan: {
                        array: []
                    }
                };
                let members = membersArray.nameClan.array;
                members.push(message.author.id);
                clans[nameClan] = {
                    name: nameClan,
                    createdAt: new Date().toLocaleString(),
                    level: levelClan,
                    creator: message.author.id,
                    members: members,
                    applylist: [],
                    admins: []
                };

                system[author.id] = {
                    clan: nameClan,
                    joinedAt: new Date().toLocaleString(),
                    clanLevel: 0,
                    creator: message.author.id
                };

                m = await m.edit('**# تم عمل الكلان بنجاح**');
            }, 2300);

        }
        if (args[1] && args[1] === 'invite') {
            if (!system[author.id]) return message.channel.send("**# أنت لست بكلان**");
            let clan = system[author.id].clan;
            if (system[author.id].clan === 'None') return message.channel.send('**# أنت لست بكلان**');
            if (!clans[clan].admins.includes(message.author.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send('**# يجب عليك ان تكون اداري بالكلان**');
            let mention = message.mentions.users.first();
            if (!mention) return message.channel.send('**# منشن شخص لدعوته للكلان**');
            if (clans[clan].members.includes(mention.id)) return message.channel.send("**# هذا العضو بالكلان بالفعل**");
            if (clans[clan].members.length === 10) return message.channel.send("**# هذا الكلان وصل للحد الاقصى من الاعضاء يمكنك**");
            let m = await message.channel.send(`**${mention} # \`${clan}\`, تم دعوتك لدخول الكلان**\n\n - لقبول الدعوة \`نعم\`\n - لرفض الدعوة \`لا\``);
            let awaiting = await message.channel.awaitMessages(r => r.author.id === mention.id, { max: 1, time: 20000, errors: ['time'] }).then(collected => {
                collected.first().delete().catch();
                if (collected.first().content === 'نعم') {
                    clans[clan].members.push(mention.id);

                    system[author.id].members += 1;


                    system[mention.id] = {
                        clan: clan,
                        joinedAt: new Date().toLocaleString(),
                        clanLevel: 0,
                        creator: clans[clan].creator
                    };

                    message.channel.send(`**${message.author} # تم قبول الدعوة**`);
                }
                if (collected.first().content === 'لا') {
                    message.channel.send(`**${message.author} # تم رفض الدعوة**`);
                } else if (collected.first().content !== 'نعم' && collected.first().content !== 'لا') {
                    return message.channel.send('**# يجب عليك كتابة `نعم` أو `لا`**');
                }
            });
        }
        if (args[1] && args[1] === 'stats') {
            if (system[author.id].clan === 'None') return message.channel.send('**# يجب ان تكون بكلان لأستخدام هذا الأمر**');
            let clan = system[author.id].clan;
            let embed = new Discord.RichEmbed()
                .setAuthor(`${message.author.username} || الكلانات`, message.author.avatarURL)
                .setDescription(`الكلان || \`${clan.toString()}\``)
            embed.addField('» اسم الكلان', clan, true)
            embed.addField('» تاريخ عمل الكلان', clans[clan].createdAt, true);
            embed.addField('» تاريخ دخول الكلان', system[author.id].joinedAt, true)
            embed.addField('» صاحب الكلان', `<@${clans[clan].creator}>`, true);
            embed.addField('» لفل الكلان', clans[clan].level, true);
            embed.addField('» عدد اعضاء الكلان', clans[clan].members.length, true);
            embed.addField('» عدد التقديمات للكلان', clans[clan].applylist.length, true);
            embed.addField('» عدد الادمنية بالكلان', clans[clan].admins.length, true);
            embed.addField('» اعضاء الكلان', `${prefix}clan list || يظهرلك رسالة بها اعضاء الكلان`);
            message.channel.send(embed);

        }
        if (args[1] && args[1] === 'join') {
            let clanName = message.content.split(' ').slice(2).join(" ");
            if (system[author.id].clan !== 'None') return message.channel.send("**# يجب أن لا تكون بكلان**");
            if (!args[2]) return message.channel.send("**# يجب عليك كتابة اسم الكلان**");
            if (!clans[clanName]) return message.channel.send("**# هذا الكلان غير موجود**");
            if (clans[clanName].applylist.includes(message.author.id)) return message.channel.send("**# لقد قدمت على دخول هذا الكلان مسبقا");
            clans[clanName].applylist.push(message.author.id);
            message.channel.send("**# لقد تم التقديم على دخول الكلان , سيتم الرد عليك من قبل احد ادارة الكلان**");

        }
        if (args[1] && args[1] === 'accept') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب عليك ان تكون بكلان لأستخدام هذا الأمر**");
            if (!clans[system[author.id].clan].admins.includes(message.author.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب عليك ان تكون اداري بالكلان لأستخدام هذا الأمر**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة شخص لأستخدام هذا الأمر**");
            if (!system[mention.id]) system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };

            if (!clans[system[author.id].clan].applylist.includes(mention.id)) return message.channel.send("**# هذا الشخص لم يقم بالتقديم على دخول الكلان**");

            clans[system[author.id].clan].applylist.shift(mention.id);
            clans[system[author.id].clan].members.push(mention.id);
            let clan = system[author.id].clan;


            system[mention.id] = {
                clan: clan,
                joinedAt: new Date().toLocaleString(),
                clanLevel: 0,
                creator: clans[clan].creator
            };


            mention.send(`**# \`${system[author.id].clan}\`, لقد تم قبولك بالكلان**`).catch();
            message.channel.send(`**# \`${mention.username}\`, لقد تم قبول الشخص ودخوله للكلان**`);
        }
        if (args[1] && args[1] === 'decline') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب عليك ان تكون بكلان لأستخدام هذا الأمر**");
            if (!clans[system[author.id].clan].admins.includes(message.author.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب عليك ان تكون اداري بالكلان لأستخدام هذا الأمر**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة شخص لأستخدام هذا الأمر**");
            if (!system[mention.id]) system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };

            if (!clans[system[author.id].clan].applylist.includes(message.author.id)) return message.channel.send("**# هذا الشخص لم يقم بالتقديم على دخول الكلان**");

            clans[system[author.id].clan].applylist.shift(mention.id);

            system[mention.id] = {
                clan: clans[system[author.id].clan],
                joinedAt: new Date().toLocaleString(),
                clanLevel: 0
            };


            mention.send(`**# \`${system[author.id].clan}\`, لقد تم رفض دخولك للكلان**`).catch();
            message.channel.send(`**# \`${mention.username}\`, لقد تم رفض دخول الشخص للكلان**`);
            //WESO#0001
        }
        if (args[1] && args[1] === 'promote') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (!clans[system[author.id].clan].admins.includes(message.author.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب عليك ان تكون اونر او ادمن بالكلان لترقية عضو بالكلان**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة عضو بالكلان لأعطائه الترقية**");
            if (!system[mention.id]) system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };

            if (system[mention.id].clan === 'None') return message.channel.send("**# هذا الشخص ليس بكلان**");
            if (!clans[system[author.id].clan].members.includes(mention.id)) return message.channel.send("**# هذا الشخص ليس بالكلان**");
            if (clans[system[author.id].clan].admins.includes(mention.id)) return message.channel.send("**# هذا العضو لديه ادمن بالفعل**");
            if (mention.id === message.author.id) return message.channel.send("**# لا يمكنك اعطاء نفسك ترقية**");

            clans[system[author.id].clan].admins.push(mention.id);


            mention.send(`**# \`${system[author.id].clan}\`, لقد تم ترقيتك الى ادمن**`).catch();
            message.channel.send(`**# \`${mention.username}\`, لقد تم ترقية العضو الى رتبة ادمن**`);
        }
        if (args[1] && args[1] === 'demote') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# هذا الأمر لضاحب الكلان فقط**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة عضو بالكلان لأعطائه الترقية**");
            if (!system[mention.id]) system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };
            if (system[mention.id].clan === 'None') return message.channel.send("**# هذا الشخص ليس بكلان**");
            if (!clans[system[author.id].clan].members.includes(mention.id)) return message.channel.send("**# هذا الشخص ليس بالكلان**");
            if (!clans[system[author.id].clan].admins.includes(mention.id)) return message.channel.send("**# هذا الشخص ليس ادمن بالكلان**");
            if (mention.id === message.author.id) return message.channel.send("**# لا يمكنك اعطاء نفسك ترقية**"); //

            clans[system[author.id].clan].admins.shift(mention.id);

            mention.send(`**# \`${system[author.id].clan}\`, لقد تم ازالتك من منصب الادمن**`).catch();
            message.channel.send(`**# \`${mention.username}\`, لقد تم ازالة الادمنية من العضو**`);
        }
        if (args[1] && args[1] === 'rename') {
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            let newName;
            let oldName = clans[system[author.id].clan];
            if (clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# هذا الأمر مخصص لصاحب الكلان فقط**");
            if (!args[2]) return message.channel.send("**# يجب عليك تحديد اسم الكلان**");

            let c = message.content.split(' ').slice(2).join(" ");
            newName = c;
            let clanInfo = clans[system[author.id].clan];
            let m = await message.channel.send(`**# \`${c}\`, هل أنت متأكد من تغيير اسم الكلان \n\n - للتأكيد \`نعم\`\n - للرفض \`لا\`**`);
            let awaiting = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 20000, errors: ['time'] }).then(c => {
                let collected = c.first();
                collected.delete().catch();
                m.delete().catch();
                if (collected.content === 'نعم') {
                    clans[newName] = {
                        name: newName,
                        createdAt: clanInfo.createdAt,
                        level: clanInfo.level,
                        creator: clanInfo.creator,
                        members: clanInfo.members,
                        applylist: clanInfo.applylist,
                        admins: clanInfo.admins
                    };
                    clans[system[author.id].clan] = undefined;

                    system[author.id].clan = newName;


                    message.channel.send("**# جارى تغيير الاسم**");
                    message.channel.send("**# تم تغيير اسم الكلان بنجاح**");

                } else if (collected.content === 'لا') {
                    message.channel.send(`**# \`${newName}\`, تم الغاء تغيير اسم الكلان**`);

                } else if (collected.first().content !== 'نعم' && collected.first().content !== 'لا') {
                    return message.channel.send('**# يجب عليك كتابة `نعم` أو `لا`**')
                }
            });
        }
        if (args[1] && args[1] === 'list') {
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب عليك ان تكون بكلان لأستخدام هذا الأمر**");
            let clan = clans[system[author.id].clan];
            let members = Array.from(clan.members);
            let admins = Array.from(clan.admins);
            let applylist = Array.from(clan.applylist);
            let i = 1;
            let o = 1;

            let embed = new Discord.RichEmbed();
            embed.setAuthor(`${message.author.username} || ${clan.name}`, message.author.avatarURL);
            embed.addField("# Members", members.map(r => `\`${i++}.\` **|| <@${r}>**`).join('\n') || `\`1.\` **|| None**`, true);
            embed.addField('# Admins', admins.map(r => `\`${o++}.\` **|| <@${r}>**`).join('\n') || `\`1.\` **|| None**`, true);
            embed.addField('# Apply', applylist.map(r => `\`${o++}.\` **|| <@${r}>**`).join('\n') || `\`1.\` **|| None**`, true);
            embed.addField('# Owner', `\`1.\` **|| <@${clan.creator}>**`, true);
            message.channel.send(embed);
        }
        if (args[1] && args[1] === 'leave') {
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            let m = await message.channel.send("**# هل انت متأكد انك تريد الخروج من الكلان \n\n - للتأكيد \`نعم\`\n - للألغاء \`لا\`**");
            let awaited = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 20000, errors: ['time'] }).then(c => {
                let collected = c.first();
                if (collected.content === 'نعم') {
                    clans[system[author.id].clan].members.shift(author.id);

                    system[author.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };


                    message.channel.send("**# لقد غادرت الكلان**");
                } else if (collected.content === 'لا') {
                    message.channel.send("**# تم الغاء الخروج من الكلان**");
                } else if (collected.content !== 'نعم' && collected.content === 'لا') {
                    message.channel.send('**# يجب عليك كتابة `نعم` أو `لا`**');
                }
            });
        }
        if (args[1] && args[1] === 'kick') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (!clans[system[author.id].clan].admins.includes(message.author.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب عليك ان تكون اونر او ادمن بالكلان لأستخدام هذا الامر**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة عضو بالكلان لطرده**");
            if (!system[mention.id]) system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };

            if (system[mention.id].clan === 'None') return message.channel.send("**# هذا الشخص ليس بكلان**");
            if (!clans[system[author.id].clan].members.includes(mention.id)) return message.channel.send("**# هذا الشخص ليس بالكلان**");
            if (clans[system[author.id].clan].admins.includes(mention.id) && clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# هذا العضو لديه ادمن**");
            if (mention.id === message.author.id) return message.channel.send("**# لا يمكنك طرد نفسك**");

            let index = clans[system[author.id].clan].members.indexOf(mention.id);
            let index2 = clans[system[author.id].clan].admins.indexOf(mention.id) || "";
            clans[system[author.id].clan].members.splice(index, 1);
            if (clans[system[author.id].clan].admins.includes(mention.id)) clans[system[author.id].clan].admins.splice(index2, 1);

            system[mention.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };


            message.channel.send(`**# \`${mention.username}\`, تم طرد الشخص من الكلان**`);
            mention.send(`**# \`${system[author.id].clan}\`, لقد تم طردك من الكلان**`).catch();
        }
        if (args[1] && args[1] === 'ownership') {
            let mention = message.mentions.users.first();
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (!mention) return message.channel.send("**# يجب عليك منشنة شخص لتسليمه الأونر**");
            if (clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب أن تكون صاحب الكلان لأستخدام هذا الأمر**");
            if (!clans[system[author.id].clan].members.includes(mention.id)) return message.channel.send("**# هذا الشخص ليس بالكلان**");
            let o = Math.floor(Math.random() * 8) + 1;
            let t = Math.floor(Math.random() * 8) + 1;
            let th = Math.floor(Math.random() * 8) + 1;
            let f = Math.floor(Math.random() * 8) + 1;
            let number = `${o}${t}${th}${f}`;

            message.author.send(`- \`${number}\`, أكتب هذا الرقم بالشات للأستمرار`).catch(e => {
                return message.channel.send(`**# يجب عليك فتح خاصك لأستخدام هذا الأمر**`);
            });

            let m = await message.channel.send("**# تم ارسال رقم التكملة بالخاص .. يجب عليك كتابة الرقم بالشات للأستمرار**");
            let awaited = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 10000, errors: ['time'] }).then(c => {
                let collected = c.first();

                if (collected.content === number) {
                    clans[system[author.id].clan].creator = mention.id;


                    m.delete();
                    message.channel.send(`**# \`${mention.username}\`, تم تحويل اونر الكلان للشخص**`);
                } else
                if (collected.content !== number) {
                    m.delete();
                }
            });
        }
        if (args[1] && args[1] === 'disband') {
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب أن تكون صاحب الكلان لأستخدام هذا الأمر**");
            let o = Math.floor(Math.random() * 8) + 1;
            let t = Math.floor(Math.random() * 8) + 1;
            let th = Math.floor(Math.random() * 8) + 1;
            let f = Math.floor(Math.random() * 8) + 1;
            let fi = Math.floor(Math.random() * 8) + 1;
            let number = `${o}${t}${th}${f}${fi}`;

            message.author.send(`- \`${number}\`, أكتب هذا الرقم بالشات للأستمرار`).catch(e => {
                return message.channel.send(`**# يجب عليك فتح خاصك لأستخدام هذا الأمر**`);
            });

            let m = await message.channel.send("**# تم ارسال رقم التكملة بالخاص .. يجب عليك كتابة الرقم بالشات للأستمرار**");
            let awaited = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 60000, errors: ['time'] }).then(c => {
                let collected = c.first();

                if (collected.content === number) {
                    m.delete().catch();
                    collected.delete().catch();
                    let name = system[author.id].clan;
                    let members = clans[system[author.id].clan].members.length;
                    let cvlMembers = Array.from(clans[name].members);
                    for (let i = 0; i < cvlMembers.length; i++) {
                        let g = hero.users.get(cvlMembers[0]);
                        g.send(`- \`${system[author.id].clan}\`, تم اقفال الكلان`).catch();
                        system[g.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };


                        cvlMembers.shift();
                        if (cvlMembers.length <= 0) {
                            message.channel.send(`- \`${name}\`, تم اقفال الكلان`);

                            system[author.id] = { clan: 'None', joinedAt: new Date().toLocaleString(), clanLevel: 0 };
                            clans[system[author.id].clan] = undefined;

                        }
                    }
                } else
                if (collected.content !== number) {
                    m.delete();
                    message.channel.send(`- \`${name}\`, تم الإلغاء`);
                }
            });
        }
        if (args && args[1] === 'room') {
            if (system[author.id].clan === 'None') return message.channel.send("**# يجب ان تكون بكلان لأستخدام هذا الأمر**");
            if (clans[system[author.id].clan].creator !== message.author.id) return message.channel.send("**# يجب أن تكون صاحب الكلان لأستخدام هذا الأمر**");
            if (message.guild.channels.find(r => r.name.toLowerCase() === system[author.id].clan && r.type === 'text') || message.guild.channels.find(r => r.name === system[author.id].clan && r.type === 'voice')) return message.channel.send("**# الكلان لديه روم بالفعل**");
            let id = '487721170687229977';
            let m = await message.channel.send("**# اكتب نوع الروم الان\n\n - `كتابي`\n - `صوتي`**");
            let awaited = await message.channel.awaitMessages(r => r.author.id === message.author.id, { max: 1, time: 20000, errors: ['time'] }).then(c => {
                let collected = c.first();
                if (collected.content === 'كتابي') {
                    message.guild.createChannel(system[author.id].clan, 'text').then(c => {
                        c.setParent(id);
                        c.overwritePermissions(message.guild.id, {
                            SEND_MESSAGES: false,
                            READ_MESSAGES: true,
                            CONNECT: false,
                            SPEAK: false
                        });

                        let newArray = Array.from(clans[system[author.id].clan].members);
                        for (let i = 0; i < newArray.length; i++) {
                            c.overwritePermissions(newArray[0], {
                                SEND_MESSAGES: true,
                                READ_MESSAGES: true,
                                CONNECT: true,
                                SPEAK: true
                            });

                            newArray.shift();
                        }
                    });
                    m.edit('**# تم عمل الروم**');
                } else if (collected.content === 'صوتي') {
                    message.guild.createChannel(system[author.id].clan, 'voice').then(c => {
                        c.setParent(id);
                        c.overwritePermissions(message.guild.id, {
                            CONNECT: false,
                            SPEAK: false
                        });

                        let newArray = Array.from(clans[system[author.id].clan].members);
                        for (let i = 0; i < newArray.length; i++) {
                            c.overwritePermissions(newArray[0], {
                                CONNECT: true,
                                SPEAK: true
                            });

                            newArray.shift();
                        }
                    });
                    m.edit('**# تم عمل الروم**');
                }
            });
        }
    }
});

client.on('message', message => {
    if (message.content == prefix + "جمع") {
        var x = ["212+212=?",
            "321+43=?",
            "4534+23",
            "23+3434=?",
            "2311+32=?",
            "765+343=?",
            "343+1121=?",
            "43234+1=?",
            "10000000000+2=?",
            "232+21=?",
            "12+23=?",
            "6+27=?",
            "5+27=?",
            "5060+70=?",
            "60+50=?"
        ];
        var x2 = ['424',
            "364",
            "4557",
            "3457",
            "2343",
            "1108",
            "1464",
            "43235",
            "10000000002",
            "253",
            "35",
            "33",
            "5130",
            "110",
        ];

        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(` اول شخص يحل جمع : __**${x[x3]}**_
لديك 15 ثانية للاجابة`).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                maxMatches: 1,
                time: 15000,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الإجآبة الصحيحةة هي __**${x2[x3]}**__`)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author} لقد قمت بحل جمع في الوقت المناسب  `);
            })
        })
    }
})

client.on('message', message => {
    if (message.content == prefix + "ضرب") {
        var x = ["9x9=?",
            "8x9=?",
            "4x4=?",
            "2x22=?",
            "12x2=?",
            "7x7=?",
            "5x5=?",
            "9x3=?",
            "2342432x0=?",
            "21321x1=?",
            "3x4x5=?",
            "6x9=?",
            "8x8=?",
            "12x12=?",
        ];
        var x2 = ['81',
            "72",
            "16",
            "44",
            "24",
            "49",
            "25",
            "27",
            "0",
            "21321",
            "60",
            "54",
            "64",
            "144",
        ];

        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(`  اول شخص يحل ضرب :  __**${x[x3]}**__
لديك 15 ثانية لحل ضرب`).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                maxMatches: 1,
                time: 15000,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الإجآبة الصحيحةة هي __**${x2[x3]}**__`)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author}لقد قمت بكتابة حل  في الوقت المناسب  `);
            })
        })
    }
})

client.on('message', message => {
    if (message.content == prefix + "طرح") {
        var x = ["4326-2345=?",
            "5822-8547=?",
            "543-823=?",
            "1500-500=?",
            "4322-2768=?",
            "5652-1255=?",
            "3421-11234=?",
            "34545-1233=?",
            "23456-54332=?",
            "2312-3433=?",
            "4321-321=?",
        ];
        var x2 = ['1981',
            "-2725",
            "-280",
            "1000",
            "1554",
            "4397",
            "-7813",
            "33312",
            "-30876",
            "1121",
            "4000",


        ];

        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(`  اول شخص يكتب حل صح :  __**${x[x3]}**__
لديك 15 ثانية لكتابة حل صحيح`).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                maxMatches: 1,
                time: 15000,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الإجآبة الصحيحةة هي __**${x2[x3]}**__`)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author}لقد قمت بكتابة حل في الوقت المناسب  `);
            })
        })
    }
});

const pics = JSON.parse(fs.readFileSync('./pics.json', 'utf8'));
client.on('message', message => {
    if (!message.channel.guild) return;

    let room = message.content.split(" ").slice(1);
    let findroom = message.guild.channels.find('name', `${room}`)
    if (message.content.startsWith(prefix + "setMedia")) {
        if (!message.channel.guild) return message.reply('**This Command Only For Servers**');
        if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send('**Sorry But You Dont Have Permission** `MANAGE_GUILD`');
        if (!room) return message.channel.send('Please Type The Channel Name')
        if (!findroom) return message.channel.send('Cant Find This Channel')
        let embed = new Discord.RichEmbed()
            .setTitle('**Done The MediaOnly Code Has Been Setup**')
            .addField('Channel:', `${room}`)
            .addField('Requested By', `${message.author}`)
            .setThumbnail(message.author.avatarURL)
            .setFooter(`${client.user.username}`)
        message.channel.sendEmbed(embed)
        pics[message.guild.id] = {
                channel: room,
                onoff: 'On'
            },
            fs.writeFile("./pics.json", JSON.stringify(pics), (err) => {
                if (err) console.error(err)

            })
    }
})
client.on('message', message => {

    if (message.content.startsWith(prefix + "toggleMedia")) {
        if (!message.channel.guild) return;

        if (!message.channel.guild) return message.reply('**هاذ الامر للسيرفرات فقط**');
        if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send('**آسف ولكن ليس لديك الصلاحية** `MANAGE_GUILD`');
        if (!pics[message.guild.id]) pics[message.guild.id] = {
            onoff: 'Off'
        }
        if (pics[message.guild.id].onoff === 'Off') return [message.channel.send(`**The MediaCode Is __𝐎𝐍__ !**`), pics[message.guild.id].onoff = 'On']
        if (pics[message.guild.id].onoff === 'On') return [message.channel.send(`**The MediaCode Is __𝐎𝐅𝐅__ !**`), pics[message.guild.id].onoff = 'Off']
        fs.writeFile("./pics.json", JSON.stringify(pics), (err) => {
            if (err) console.error(err)

        })
    }

})

client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.author.bot) return;

    if (!pics[message.guild.id]) pics[message.guild.id] = {
        onoff: 'Off'
    }
    if (pics[message.guild.id].onoff === 'Off') return;

    if (message.channel.name !== `${pics[message.guild.id].channel}`) return;

    let types = [
        'jpg',
        'jpeg',
        'png',
        'http://prntscr.com/'
    ]
    if (message.attachments.size <= 0) {
        message.delete();
        message.channel.send(`${message.author}, This Channel For Media 🖼️ Only !`)
            .then(msg => {
                setTimeout(() => {
                    msg.delete();
                }, 5000)
            })
        return;
    }
    if (message.attachments.size >= 1) {
        let filename = message.attachments.first().filename
        console.log(filename);
        if (!types.some(type => filename.endsWith(type))) {
            message.delete();
            message.channel.send(`${message.author}, This Channel For Media 🖼️ Only !`)
                .then(msg => {
                    setTimeout(() => {
                        msg.delete();
                    }, 5000)
                })
                .catch(err => {
                    console.error(err);
                });
        }
    }
})
client.on('message', message => {
    if (message.content.startsWith(prefix + "infoMedia")) {
        let embed = new Discord.RichEmbed()
            .addField('حالة الغرفة', `${pics[message.guild.id].onoff}`)
            .addField('Media Channel', `${pics[message.guild.id].channel}`)
            .addField('Requested By', `${message.author}`)
            .setThumbnail(message.author.avatarURL)
            .setFooter(`${client.user.username}`)
        message.channel.sendEmbed(embed)
    }
})

const kingmas = [
    '*** منشن الجميع وقل انا اكرهكم. ***',
    '*** اتصل على امك و قول لها انك تحبها :heart:. ***',
    '***     تصل على الوالده  و تقول لها  احب وحده.***',
    '*** تتصل على شرطي تقول له عندكم مطافي.***',
    '*** صور اي شيء يطلبه منك الاعبين.***',
    '*** اكتب في الشات اي شيء يطلبه منك الاعبين في الخاص. ***',
    '*** اتصل على احد من اخوياك  خوياتك , و اطلب منهم مبلغ على اساس انك صدمت بسيارتك.***',
    '*** اعطي اي احد جنبك كف اذا مافيه احد جنبك اعطي نفسك و نبي نسمع صوت الكف.***',
    '***  تروح عند شخص تقول له احبك. ***',
    '***روح عند اي احد بالخاص و قول له انك تحبه و الخ.***',
    '*** اذهب الى واحد ماتعرفه وقل له انا كيوت وابي بوسه. ***',
    '*** روح الى اي قروب عندك في الواتس اب و اكتب اي شيء يطلبه منك الاعبين  الحد الاقصى 3 رسائل. ***',
    '*** اذا انت ولد اكسر اغلى او احسن عطور عندك اذا انتي بنت اكسري الروج حقك او الميك اب حقك. ***',
    '*** ذي المرة لك لا تعيدها.***',
    '*** ارمي جوالك على الارض بقوة و اذا انكسر صور الجوال و ارسله في الشات العام.***',
    '*** اتصل على ابوك و قول له انك رحت مع بنت و احين هي حامل..... ***',
    '*** تكلم باللهجة السودانية الين يجي دورك مرة ثانية.***',
    '***سو مشهد تمثيلي عن مصرية بتولد.***',
    '*** قول نكتة اذا و لازم احد الاعبين يضحك اذا محد ضحك يعطونك ميوت الى ان يجي دورك مرة ثانية. ***',
    '*** قول نكتة اذا و لازم احد الاعبين يضحك اذا محد ضحك يعطونك ميوت الى ان يجي دورك مرة ثانية.***',
    '*** سامحتك خلاص مافيه عقاب لك :slight_smile:. ***',
    '*** اذهب الى واحد ماتعرفه وقل له انا كيوت وابي بوسه.***',
    '*** تتصل على الوالده  و تقول لها خطفت شخص. ***',
    '*** روح اكل ملح + ليمون اذا مافيه اكل اي شيء من اختيار الي معك.  ***'
]
client.on('message', message => {
    var prefix = '-';
    if (message.content.startsWith(prefix + 'حكم')) {
        var mariam = new Discord.RichEmbed()
            .setTitle("لعبة حكم ..")
            .setColor('RANDOM')
            .setDescription(`${kingmas[Math.floor(Math.random() * kingmas.length)]}`)
        message.channel.sendEmbed(mariam);
        message.react(":thinking:")
    }
});

client.on('message', PuP => {
    let args = PuP.content.split(" ").slice(1).join(" ")
    if (PuP.content.startsWith(`${prefix}sr`)) {
        if (!PuP.member.hasPermission("MANAGE_SERVER")) return;
        if (!args) return PuP.channel.send('`**يرجي ادخال اسم السرفر الجديد**`');
        PuP.guild.owner.send(`**ى تغيير اسم السرفر الي ${args}
                بواسطة : <@${PuP.author.id}>**`)
        PuP.guild.setName(args)
        PuP.channel.send(`**تم تغير اسم السيرفر الي : __${args}__ **`);

    }

});



client.on('ready', function() {
    var ms = 10000;
    var setGame = [`${prefix}help`, `انا موجود في  ${client.guilds.size} سيرفر`, `i help ${client.users.size} Members`];
    var i = -1;
    var j = 0;
    setInterval(function() {
        if (i == -1) {
            j = 1;
        }
        if (i == (setGame.length) - 1) {
            j = -1;
        }
        i = i + j;
        client.user.setGame(setGame[i], `http://www.twitch.tv/blu4egam3r`);
    }, ms);
    console.log(`Logged in as ${client.user.tag}!`);
    console.log('')
    console.log('')
    console.log('╔[═════════════════════════════════════════════════════════════════]╗')
    console.log(`[Start] ${new Date()}`);
    console.log('╚[═════════════════════════════════════════════════════════════════]╝')
    console.log('')
    console.log('╔[════════════════════════════════════]╗');
    console.log(`Logged in as * [ " ${client.user.username} " ]`);
    console.log('')
    console.log('Informations :')
    console.log('')
    console.log(`servers! [ " ${client.guilds.size} " ]`);
    console.log(`Users! [ " ${client.users.size} " ]`);
    console.log(`channels! [ " ${client.channels.size} " ]`);
    console.log('╚[════════════════════════════════════]╝')
    console.log('')
    console.log('╔[════════════]╗')
    console.log(' Bot Is Online')
    console.log('╚[════════════]╝')
    console.log('')
    console.log('')
});


client.on('message', message => {

    if (message.content === prefix + "hchannel" || message.content === prefix + "اخفاء") {
        if (!message.channel.guild) return;
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('You Dont Have Perms :x:');
        message.channel.overwritePermissions(message.guild.id, {
            READ_MESSAGES: false
        })
        message.channel.send('Channel Hided Successfully ! :white_check_mark:  ')
    }
});

client.on('message', async Epic => {

    if (Epic.content.startsWith(prefix + "vonline") || Epic.content.startsWith(prefix + "عدد الصوت")) {
        if (!Epic.guild.member(Epic.author).hasPermissions('MANAGE_CHANNELS')) return Epic.reply(':x: **I Dont Have Permissions**');
        if (!Epic.guild.member(client.user).hasPermissions(['MANAGE_CHANNELS', 'MANAGE_ROLES_OR_PERMISSIONS'])) return Epic.reply(':x: **You Dont Have Permissions**');
        Epic.guild.createChannel(`Voice المتصلين بي : [ ${Epic.guild.members.filter(m => m.voiceChannel).size} ]`, 'voice').then(c => {
            console.log(`Voice Online Is Activation In ${Epic.guild.name}`);
            c.overwritePermissions(Epic.guild.id, {
                CONNECT: false,
                SPEAK: false
            });
            setInterval(() => {
                c.setName(`Voice Online :  ${Epic.guild.members.filter(m => m.voiceChannel).size} .`)
            }, 1000);
        });
    }
});


client.on('message', message => {

    var cats = ["http://www.shuuf.com/shof/uploads/2015/09/09/jpg/shof_b9d73150f90a594.jpg", "https://haltaalam.info/wp-content/uploads/2015/05/0.208.png", "https://haltaalam.info/wp-content/uploads/2015/05/266.png", "https://haltaalam.info/wp-content/uploads/2015/05/250.png", "https://haltaalam.info/wp-content/uploads/2017/02/0.2517.png", "https://pbs.twimg.com/media/CP0mi02UAAA3U2z.png", "http://www.shuuf.com/shof/uploads/2015/08/31/jpg/shof_3b74fa7295ec445.jpg", "http://www.shuuf.com/shof/uploads/2015/08/22/jpg/shof_fa3be6ab68fb415.jpg", "https://pbs.twimg.com/media/CSWPvmRUcAAeZbt.png", "https://pbs.twimg.com/media/B18VworIcAIMGsE.png"]
    var args = message.content.split(" ").slice(1);
    if (message.content.startsWith(prefix + 'هل تعلم')) {
        var cat = new Discord.RichEmbed()
            .setImage(cats[Math.floor(Math.random() * cats.length)])
        message.channel.sendEmbed(cat);
    }
});



client.on('message', message => {

    if (message.content === prefix + "schannel" || message.content === prefix + "اضهار الشات" || message.content === prefix + "الشات") {
        if (!message.channel.guild) return;
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply(':x:');
        message.channel.overwritePermissions(message.guild.id, {
            READ_MESSAGES: true
        })
        message.channel.send('تم اضهار الشات بنجاح')
    }
});

client.on('message', message => {
    if (message.author.bot) return;
    if (message.isMentioned(client.user)) {
        message.reply(`**حمبي :upside_down: البرفكس حقي ** : ${prefix}`)
    }
});


client.on("message", async message => {
    if (message.author.bot) return;
    if (message.channel.type === "dm") return;


    let messageArray = message.content.split(" ");
    let cmd = messageArray[0];
    let args = messageArray.slice(1);



    if (cmd === `{prefix}8ball`) {


        if (!args[1]) return message.reply("يرجى طرح سؤال كامل!");
        let replies = ["نعم", "لا", "لم افهم", "عيد السؤال باليز"];

        let result = Math.floor((Math.random() * replies.length));
        let question = args.slice(1).join(" ");

        let ballembed = new Discord.RichEmbed()
            .setAuthor(message.author.tag)
            .setColor("#FF9900")
            .addField("Question", question)
            .addField("Answer", replies[result]);

        message.channel.send(ballembed);
    }
});

const Love = ["**احبك / عدد قطرات المـــطر والشجر وامواج البحر والنجوم الي تتزاحم مبهورة في جمال القمر**.", "**ساعزفك وساجعلك لحنا تغني عليه جميع قصائد العشــق**.", "**احبك موت... لاتسألني ما الدليل ارأيت رصاصه تسأل القتيل؟**.", "**ربما يبيع الانسان شيئا قد شراه لاكن لا يبيع قلبا قد هواه**.", "**و ما عجبي موت المحبين في الهوى ........... و لكن بقاء العاشقين عجيب**.", "**حلفت / لاحشـــد جيوش الحب واحتلك مسكين ربي بلاك بعـــاشق ارهـــابي**.", "**العيــن تعشق صورتك ... والقلب يجري فيه دمك وكل مااسمع صوتك ...شفايفي تقول احبك**.", "**ياحظ المكان فيك..ياحظ من هم حواليك ...ياحظ الناس تشوفك ... وانا مشتاق اليك**.", "**لو كنت دمعة داخل عيوني بغمض عليك وصدقي ما راح افتح...ولو كان الثمن عيوني**.", "**سهل اموت عشانك لكن الصعب اعيش بدونك سهل احبك لكن صعب انساك**.", "**أخشى ان انظر لعيناك وأنا فى شوق ولهيب لرؤياك**.", "**أتمنى ان اكون دمعة تولد بعينيك واعيش على خديك واموت عند شفتيك**.", "**أحياناً أرى الحياة لا تساوى إبتسامة لكن دائماً إبتسامتك هى كيانى**.", "**من السهل أن ينسى الانسان نفسه .. لكن من الصعب ان ينسى نفساً سكنت نفسه !**.", "**نفسى أكون نجمة سماك .. همسة شفاك .. شمعة مساك .. بس تبقى معايا وانا معاك**.", "**أهنئ قلبى بحبك وصبر عينى فى بعدك وأقول إنك نور عينى يجعل روحى فدى قلبك**.", ]


client.on('message', message => {
    if (message.content.startsWith(prefix + "love") || message.content.startsWith(prefix + "حب")) {
        if (!message.channel.guild) return message.reply('**هاذ الامر مخصص للسيرفرات**');
        var embed = new Discord.RichEmbed()
            .setColor(0xd3d0c4)
            .setFooter(`PuP System`)
            .setThumbnail(message.author.avatarURL)
            .addField('حب',
                `${Love[Math.floor(Math.random() * Love.length)]}`)
        message.channel.sendEmbed(embed);

    }
});

client.on("message", message => {
    let roleembed = new Discord.RichEmbed()
        .setDescription(`
    أمثله على الأوامر :
	تفضل @mention rolename : لأعطاء رتبة لعضو معين
    ${prefix}role @mention rolename : لأعطاء رتبة لعضو معين
    ${prefix}role all rolename : لأعطاء رتبة للجميع
    ${prefix}role humans rolename : لأعطاء رتبة للاشخاص فقط
    ${prefix}role bots rolename : لأعطاء رتبة لجميع البوتات`)
        .setFooter('Requested by' + message.author.username, message.author.avatarURL)
    var args = message.content.split(' ').slice(1);
    var msg = message.content.toLowerCase();
    if (!message.guild) return;
    if (!msg.startsWith(prefix + 'role') || !msg.startsWith('تفضل')) return;
    if (!message.member.hasPermission('MANAGE_ROLES')) return message.channel.send(' **__ليس لديك صلاحيات__**');
    if (msg.toLowerCase().startsWith(prefix + 'roleembed') || msg.toLowerCase().startsWith('تفضل')) {
        if (!args[0]) return message.channel.sendEmbed(roleembed)
        if (!args[1]) return message.channel.sendEmbed(roleembed)
        var role = msg.split(' ').slice(2).join(" ").toLowerCase();
        var role1 = message.guild.roles.filter(r => r.name.toLowerCase().indexOf(role) > -1).first();
        if (!role1) return message.reply('**:x: يرجى وضع الرتبة المراد اعطاءها الى الشخص**');
        if (message.mentions.members.first()) {
            message.mentions.members.first().addRole(role1);
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] رتبة [ ' + args[0] + ' ] تم اعطاء الى **');
        }
        if (args[0].toLowerCase() == "all") {
            message.guild.members.forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى الكل رتبة**');
        } else if (args[0].toLowerCase() == "bots") {
            message.guild.members.filter(m => m.user.bot).forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى البوتات رتبة**');
        } else if (args[0].toLowerCase() == "humans") {
            message.guild.members.filter(m => !m.user.bot).forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الى البشريين رتبة**');
        }
    } else {
        if (!args[0]) return message.reply('**:x: يرجى وضع الشخص المراد اعطائها الرتبة**');
        if (!args[1]) return message.reply('**:x: يرجى وضع الرتبة المراد اعطائها للشخص**');
        var role = msg.split(' ').slice(2).join(" ").toLowerCase();
        var role1 = message.guild.roles.filter(r => r.name.toLowerCase().indexOf(role) > -1).first();
        if (!role1) return message.reply('**:x: يرجى وضع الرتبة المراد اعطائها للشخص**');
        if (message.mentions.members.first()) {
            message.mentions.members.first().addRole(role1);
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] رتبة [ ' + args[0] + ' ] تم اعطاء **');
        }
        if (args[0].toLowerCase() == "all") {
            message.guild.members.forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء الكل رتبة**');
        } else if (args[0].toLowerCase() == "bots") {
            message.guild.members.filter(m => m.user.bot).forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء البوتات رتبة**');
        } else if (args[0].toLowerCase() == "humans") {
            message.guild.members.filter(m => !m.user.bot).forEach(m => m.addRole(role1))
            return message.reply('**:white_check_mark: [ ' + role1.name + ' ] تم اعطاء البشريين رتبة**');
        }
    }
});



client.on("message", (message) => {

    if (message.content.startsWith(prefix + "new") || message.content.startsWith(prefix + "tekit") || message.content.startsWith(prefix + "نذكرة")) {
        const reason = message.content.split(" ").slice(1).join(" ");
        if (!message.guild.roles.exists("name", "Support Team")) return message.channel.send(`لا يوجد لدية رتبة \`Support Team\` تم القيام بالدور ، لذلك لن يتم فتح التذكرة. \ إذا كنت مشرفًا ، فقم بعمل واحد بهذا الاسم تمامًا وأعطه للمستخدمين الذين يمكنهم رؤية التذاكر.`);
        if (message.guild.channels.exists("name", "${prefix}ticket{message.author.id}" + message.author.id)) return message.channel.send(`لديك تذكرة مفتوحة بالفعل.`);
        message.guild.createChannel(`${prefix}ticket${message.author.username}`, "text").then(c => {
            let role = message.guild.roles.find("name", "Support Team");
            let role2 = message.guild.roles.find("name", "@everyone");
            c.overwritePermissions(role, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            c.overwritePermissions(role2, {
                SEND_MESSAGES: false,
                READ_MESSAGES: false
            });
            c.overwritePermissions(message.author, {
                SEND_MESSAGES: true,
                READ_MESSAGES: true
            });
            message.channel.send(`:white_check_mark: تم إنشاء تذكرتك, #${c.name}.`);
            const embed = new Discord.RichEmbed()
                .setColor(0xCF40FA)
                .addField(`مهلا ${message.author.username}!`, ` 
                                يرجى محاولة شرح سبب فتح هذه التذكرة بأكبر قدر ممكن من التفاصيل.سيتواجد ** فريق الدعم ** لدينا قريبً ا للمساعدة.
                                `)
                .setTimestamp();
            c.send({
                embed: embed
            });
        }).catch(console.error);
    }


    if (message.content.startsWith(prefix + "closeticket") || message.content.startsWith(prefix + "اغلق التذكرة")) {
        if (!message.channel.name.startsWith(`
                                $ { prefix }
                                ticket `)) return message.channel.send(`لا يمكنك استخدام الأمر إغلاق خارج روم التكت `);

        message.channel.send(`هل أنت متأكد؟ بمجرد التأكيد، لا يمكنك تغير هذا الإجراء!\للتأكيد، اكتب\ ${prefix}confirmتأكيد\.ستنتهي المهلة خلال 10 ثوانٍ وسيتم إلغاؤها.`)
            .then((m) => {
                message.channel.awaitMessages(response => response.content === `${prefix}confirm`, {
                        max: 1,
                        time: 10000,
                        errors: ['time'],
                    })
                    .then((collected) => {
                        message.channel.delete();
                    })
                    .catch(() => {
                        m.edit('انتهت المهلة، لم يتم إغلاق التذكرة.').then(m2 => {
                            m2.delete();
                        }, 3000);
                    });
            });
    }

});

let antihack = JSON.parse(fs.readFileSync('./antihack.json', 'utf8'));
client.on('message', message => {
    if (message.content.startsWith(prefix + "tAntihack") || message.content.startsWith(prefix + "مكافحة الهكر")) {
        if (!message.channel.guild) return message.reply('**هاذ الامر مخصص للسيرفرات فقط**');
        if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send('**ليس لديك الصلاحيات الكافية ل استخدام هاذ الامر');
        if (!antihack[message.guild.id]) antihack[message.guild.id] = {
            onoff: 'Off'
        }
        if (antihack[message.guild.id].onoff === 'Off') return [message.channel.send(` ** تم تشغيل مكافحة الهكر** `), antihack[message.guild.id].onoff = 'On']
        if (antihack[message.guild.id].onoff === 'On') return [message.channel.send(` **تم اطفاء محافحة الهكر** `), antihack[message.guild.id].onoff = 'Off']
        fs.writeFile("./antihack.json", JSON.stringify(antihack), (err) => {
            if (err) console.error(err)
                .catch(err => {
                    console.error(err);
                });
        });
    }

})


let banse = new Set();
let bane = JSON.parse(fs.readFileSync('./data1.json', 'utf8'));
client.on('guildBanAdd', function(guild) {
    guild.fetchAuditLogs().then(logs => {
        const ser = logs.entries.first().executor;
        if (!bane[ser.id + guild.id]) bane[ser.id + guild.id] = {
            bans: 2
        }
        if (antihack[guild.guild.id].onoff === 'Off') return;
        let boner = bane[ser.id + guild.id]
        banse.add(ser.id)
        boner.bans = Math.floor(boner.bans + 1)


        setTimeout(() => {
            boner.bans = 2
            banse.delete(ser.id)
        }, 8000)

        if (boner.bans > 2) {
            let roles = guild.members.get(ser.id).roles.array()
            guild.members.get(ser.id).removeRoles(roles)
        }

    })
    fs.writeFile('./data1.json', JSON.stringify(bane), (err) => {
        if (err) console.error(err);
    })

})
client.on('guildMemberRemove', (u) => {
    u.guild.fetchAuditLogs().then(s => {
        var ss = s.entries.first();
        if (ss.action == `MEMBER_KICK `) {
            if (!data[ss.executor.id]) {
                data[ss.executor.id] = {
                    time: 1
                };
                if (antihack[u.guild.id].onoff === 'Off') return;

            } else {
                data[ss.executor.id].time += 1
            };
            if (antihack[u.guild.id].onoff === 'Off') return;
            data[ss.executor.id].time = 0
            u.guild.members.get(ss.executor.id).roles.forEach(r => {
                r.edit({
                    permissions: []
                });
                data[ss.executor.id].time = 0
            });
            setTimeout(function() {
                if (data[ss.executor.id].time <= 3) {
                    data[ss.executor.id].time = 0
                }
            })
        };
    });
    const data = require("./data.json");
});
client.on('roleDelete', (u) => {
    u.guild.fetchAuditLogs().then(s => {
        var ss = s.entries.first();
        if (ss.action == `ROLE_DELETE `) {
            if (!data[ss.executor.id]) {
                data[ss.executor.id] = {
                    time: 1
                };
                if (antihack[u.guild.id].onoff === 'Off') return;

            } else {
                data[ss.executor.id].time += 1
            };
            if (antihack[u.guild.id].onoff === 'Off') return;

            data[ss.executor.id].time = 0
            u.guild.members.get(ss.executor.id).roles.forEach(r => {
                r.edit({
                    permissions: []
                });
                data[ss.executor.id].time = 0
            });
            setTimeout(function() {
                if (data[ss.executor.id].time <= 3) {
                    data[ss.executor.id].time = 0
                }
            }, 60000)
        };
    });
    const data = require("./data.json");
});
client.on('channelDelete', (u) => {
    u.guild.fetchAuditLogs().then(s => {
        var ss = s.entries.first();
        if (ss.action == `CHANNEL_DELETE `) {
            if (!data[ss.executor.id]) {
                data[ss.executor.id] = {
                    time: 1
                };
                if (antihack[u.guild.id].onoff === 'Off') return;
            } else {
                data[ss.executor.id].time += 1
            };
            if (antihack[u.guild.id].onoff === 'Off') return;
            data[ss.executor.id].time = 0
            u.guild.members.get(ss.executor.id).roles.forEach(r => {
                r.edit({
                    permissions: []
                });
                data[ss.executor.id].time = 0
            });
            setTimeout(function() {
                if (data[ss.executor.id].time <= 3) {
                    data[ss.executor.id].time = 0
                }
            })
        };
    });
    const data = require("./data.json");
})

client.on('message', message => {
    if (message.content.startsWith(prefix + "link") || message.content.startsWith(prefix + "رابط")) {

        message.channel.createInvite({
            thing: true,
            maxUses: 100,
            maxAge: 86400
        }).then(invite =>
            message.author.sendMessage(invite.url)
        )
        message.channel.send("**:link:.تم ارسال الرابط برسالة خاصة**")

        message.author.send(` ** مدة الرابط: يـوم عدد استخدامات الرابط: 100 ** `)


    }
});



client.on('message', message => {
    if (message.author.bot) return;
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'setlog')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply("**تحتاج الى `MANAGE_CHANNELS`**");
        let log = message.guild.channels.find("name", "log")
        if (log) return message.reply("**يوجد بالفعل روم اللوق**")
        if (!log) {
            message.guild.createChannel("log", "text").then(c => {
                c.overwritePermissions(message.guild.id, {
                    SEND_MESSAGES: false
                })
            })
            message.channel.send("**✅ ,تم انشاء روم اللوق بنجــاح**")
        }
    }
})
client.on('error', console.error);

client.on('messageDelete', message => {
    if (message.author.bot) return;
    if (message.channel.type === 'dm') return;
    if (!message.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!message.guild.member(client.user).hasPermission('MANAGE_MESSAGES')) return;

    var logChannel = message.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    let messageDelete = new Discord.RichEmbed()
        .setTitle('**[تم حذف رسالة]**')
        .setColor('RED')
        .setThumbnail(message.author.avatarURL)
        .setDescription(`**\n**:wastebasket: تم بي نجاح رسالة\`\`حذف\`\` **في روم**${message.channel}\n\n**روم:** \`\`${message.channel.name}\`\` (ID: ${message.channel.id})\n**الرسالة ID:** ${message.id}\n**ارسلت بواسطة:** <@${message.author.id}> (ID: ${message.author.id})\n**الرسالة:**\n\`\`\`${message}\`\`\``)
        .setTimestamp()
        .setFooter(message.guild.name, message.guild.iconURL)

    logChannel.send(messageDelete);
});
client.on('messageUpdate', (oldMessage, newMessage) => {

    if (oldMessage.author.bot) return;
    if (!oldMessage.channel.type === 'dm') return;
    if (!oldMessage.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!oldMessage.guild.member(client.user).hasPermission('MANAGE_MESSAGES')) return;

    var logChannel = oldMessage.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    if (oldMessage.content.startsWith('https://')) return;

    let messageUpdate = new Discord.RichEmbed()
        .setTitle('**تم تعديل رسالة**')
        .setThumbnail(oldMessage.author.avatarURL)
        .setColor('BLUE')
        .setDescription(`**\n**:wrench: تم بي نجاح\`\`تعديل\`\` **في روم** In ${oldMessage.channel}\n\n**روم:** \`\`${oldMessage.channel.name}\`\` (ID: ${oldMessage.channel.id})\n**الرسالة ID:** ${oldMessage.id}\nارسلت بواسطة:** <@${oldMessage.author.id}> (ID: ${oldMessage.author.id})\n\n**قبل التعديل:**\`\`\`${oldMessage}\`\`\`\n**بعد التعديل:**\`\`\`${newMessage}\`\`\``)
        .setTimestamp()
        .setFooter(oldMessage.guild.name, oldMessage.guild.iconURL)

    logChannel.send(messageUpdate);
});



client.on('roleCreate', role => {

    if (!role.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!role.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = role.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    role.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        let roleCreate = new Discord.RichEmbed()
            .setTitle('**[تم صناعة رتبة]**')
            .setThumbnail(userAvatar)
            .setDescription(`**\n**:white_check_mark: تم بنجاح\`\`صناعة\`\` رتبة.\n\n**اسم الرتبة:** \`\`${role.name}\`\` (ID: ${role.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setColor('GREEN')
            .setTimestamp()
            .setFooter(role.guild.name, role.guild.iconURL)

        logChannel.send(roleCreate);
    })
});
client.on('roleDelete', role => {

    if (!role.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!role.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = role.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    role.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        let roleDelete = new Discord.RichEmbed()
            .setTitle('**تم حذف رتبة**')
            .setThumbnail(userAvatar)
            .setDescription(`**\n**:white_check_mark: تم بي نجاح\`\`حذف\`\` رتبة.\n\n**اسم الرتبة:** \`\`${role.name}\`\` (ID: ${role.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setColor('RED')
            .setTimestamp()
            .setFooter(role.guild.name, role.guild.iconURL)

        logChannel.send(roleDelete);
    })
});
client.on('roleUpdate', (oldRole, newRole) => {

    if (!oldRole.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!oldRole.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = oldRole.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    oldRole.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        if (oldRole.name !== newRole.name) {
            let roleUpdateName = new Discord.RichEmbed()
                .setTitle('**تم تحديث صلاحيات رتبة**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:white_check_mark: تم بي نجاح\`\`تعديل رتبةاسم رتبة\`\` Role Name.\n\n**الاسم القديم:** \`\`${oldRole.name}\`\`\n**الاسم الجديد:** \`\`${newRole.name}\`\`\n**الرتبة ID:** ${oldRole.id}\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldRole.guild.name, oldRole.guild.iconURL)

            logChannel.send(roleUpdateName);
        }
        if (oldRole.hexColor !== newRole.hexColor) {
            if (oldRole.hexColor === '#000000') {
                var oldColor = '`Default`';
            } else {
                var oldColor = oldRole.hexColor;
            }
            if (newRole.hexColor === '#000000') {
                var newColor = '`Default`';
            } else {
                var newColor = newRole.hexColor;
            }
            let roleUpdateColor = new Discord.RichEmbed()
                .setTitle('**تم تحديث لون رتبة**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:white_check_mark:تم بي نجاح \`\`تحديث لون رتبة\`\` **${oldRole.name}** Role Color.\n\n**اللون القديم:** ${oldColor}\n**اللون الجديد:** ${newColor}\n**الرتبة ID:** ${oldRole.id}\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldRole.guild.name, oldRole.guild.iconURL)

            logChannel.send(roleUpdateColor);
        }
        if (oldRole.permissions !== newRole.permissions) {
            let roleUpdate = new Discord.RichEmbed()
                .setTitle('**[UPDATE ROLE PERMISSIONS]**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:first_place: تم بي نجاح \`\`تحديث صلاحبات رتبة\`\` **${oldRole.name}**!\n\n**الصلاحيات القديمة:** \`\`${oldRole.permissions}\`\`\n**الصلاحيات الجديدة:** \`\`${newRole.permissions}\`\`\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldRole.guild.name, oldRole.guild.iconURL)

            logChannel.send(roleUpdate)
        }
    })
});



client.on('channelCreate', channel => {

    if (!channel.guild) return;
    if (!channel.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!channel.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = channel.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    if (channel.type === 'text') {
        var roomType = 'Text';
    } else
    if (channel.type === 'voice') {
        var roomType = 'Voice';
    } else
    if (channel.type === 'category') {
        var roomType = 'Category';
    }

    channel.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        let channelCreate = new Discord.RichEmbed()
            .setTitle('**[CHANNEL CREATE]**')
            .setThumbnail(userAvatar)
            .setDescription(`**\n**:white_check_mark: تم بي نجاح \`\`صناعة\`\` **${roomType}**روم.\n\n**اسم الروم:** \`\`${channel.name}\`\` (ID: ${channel.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setColor('GREEN')
            .setTimestamp()
            .setFooter(channel.guild.name, channel.guild.iconURL)

        logChannel.send(channelCreate);
    })
});
client.on('channelDelete', channel => {
    if (!channel.guild) return;
    if (!channel.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!channel.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = channel.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    if (channel.type === 'text') {
        var roomType = 'Text';
    } else
    if (channel.type === 'voice') {
        var roomType = 'Voice';
    } else
    if (channel.type === 'category') {
        var roomType = 'Category';
    }

    channel.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        let channelDelete = new Discord.RichEmbed()
            .setTitle('**تم حذف روم**')
            .setThumbnail(userAvatar)
            .setDescription(`**\n**:white_check_mark: تم بي نجاح\`\`حذف\`\` **${roomType}** روم.\n\n**اسم الروم:** \`\`${channel.name}\`\` (ID: ${channel.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setColor('RED')
            .setTimestamp()
            .setFooter(channel.guild.name, channel.guild.iconURL)

        logChannel.send(channelDelete);
    })
});
client.on('channelUpdate', (oldChannel, newChannel) => {
    if (!oldChannel.guild) return;

    var logChannel = oldChannel.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    if (oldChannel.type === 'text') {
        var channelType = 'Text';
    } else
    if (oldChannel.type === 'voice') {
        var channelType = 'Voice';
    } else
    if (oldChannel.type === 'category') {
        var channelType = 'Category';
    }

    oldChannel.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        if (oldChannel.name !== newChannel.name) {
            let newName = new Discord.RichEmbed()
                .setTitle('**تم تعديل اسم روم**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:wrench: تم بينجاح **${channelType}** تعديل اسم روم\n\n**الاسم القديم:** \`\`${oldChannel.name}\`\`\n**الاسم الجديد:** \`\`${newChannel.name}\`\`\n**الروم ID:** ${oldChannel.id}\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldChannel.guild.name, oldChannel.guild.iconURL)

            logChannel.send(newName);
        }
        if (oldChannel.topic !== newChannel.topic) {
            let newTopic = new Discord.RichEmbed()
                .setTitle('**تم تحديث صلاحيات الروم**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:wrench:تم تعديل **${channelType}** صلاحيات الرومn\n**الصلاحيات القديمة:**\n\`\`\`${oldChannel.topic || 'NULL'}\`\`\`\n**الصلاحيات الجديدة:**\n\`\`\`${newChannel.topic || 'NULL'}\`\`\`\n**اسم الروم:** ${oldChannel} (ID: ${oldChannel.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldChannel.guild.name, oldChannel.guild.iconURL)

            logChannel.send(newTopic);
        }
    })
});



client.on('guildBanAdd', (guild, user) => {

    if (!guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        if (userID === client.user.id) return;

        let banInfo = new Discord.RichEmbed()
            .setTitle('**تم حظر**')
            .setThumbnail(userAvatar)
            .setColor('DARK_RED')
            .setDescription(`**\n**:airplane:تم بي نجاح\`\`حظر\`\` **${user.username}** من هاذ السيرفر!\n\n**المستخدم:** <@${user.id}> (ID: ${user.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setTimestamp()
            .setFooter(guild.name, guild.iconURL)

        logChannel.send(banInfo);
    })
});
client.on('guildBanRemove', (guild, user) => {
    if (!guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;

        let unBanInfo = new Discord.RichEmbed()
            .setTitle('**تم فك الحظر**')
            .setThumbnail(userAvatar)
            .setColor('GREEN')
            .setDescription(`**\n**:unlock: تم بي نجاح \`\`فك الحظر عن\`\` **${user.username}** في هاذ السيرفر\n\n**المستخدم:** <@${user.id}> (ID: ${user.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
            .setTimestamp()
            .setFooter(guild.name, guild.iconURL)

        logChannel.send(unBanInfo);
    })
});
client.on('guildMemberUpdate', (oldMember, newMember) => {
    var logChannel = oldMember.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    oldMember.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userAvatar = logs.entries.first().executor.avatarURL;
        var userTag = logs.entries.first().executor.tag;

        if (oldMember.nickname !== newMember.nickname) {
            if (oldMember.nickname === null) {
                var oldNM = '\`\`اسمه الاصلي\`\`';
            } else {
                var oldNM = oldMember.nickname;
            }
            if (newMember.nickname === null) {
                var newNM = '\`\`اسمه الاصلي\`\`';
            } else {
                var newNM = newMember.nickname;
            }

            let updateNickname = new Discord.RichEmbed()
                .setTitle('**تغير اسم العضو**')
                .setThumbnail(userAvatar)
                .setColor('BLUE')
                .setDescription(`**\n**:spy: تم بي نجاح \`\`تغير\`\`اسم العضو.\n\n**المستخدم:** ${oldMember} (ID: ${oldMember.id})\n**الاسم القديم:** ${newNM}\n**الاسم الجديد:** ${newNM}\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(oldMember.guild.name, oldMember.guild.iconURL)

            logChannel.send(updateNickname);
        }
        if (oldMember.roles.size < newMember.roles.size) {
            let role = newMember.roles.filter(r => !oldMember.roles.has(r.id)).first();

            let roleAdded = new Discord.RichEmbed()
                .setTitle('**تم تحديث رتبة العضو**')
                .setThumbnail(oldMember.guild.iconURL)
                .setColor('GREEN')
                .setDescription(`**\n**:white_check_mark: تم بي نجاح \`\`تحديث\`\`رتبة **${oldMember.user.username}**\n\n**المستخدم:** <@${oldMember.id}> (ID: ${oldMember.user.id})\n**رتبة:** \`\`${role.name}\`\` (ID: ${role.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(roleAdded);
        }
        if (oldMember.roles.size > newMember.roles.size) {
            let role = oldMember.roles.filter(r => !newMember.roles.has(r.id)).first();

            let roleRemoved = new Discord.RichEmbed()
                .setTitle('**تم حذف الرتبة من العضو**')
                .setThumbnail(oldMember.guild.iconURL)
                .setColor('RED')
                .setDescription(`**\n**:negative_squared_cross_mark: تم بي نجاح\`\`حذف\`\`الرتبة من **${oldMember.user.username}**\n\n**المستخدم:** <@${oldMember.user.id}> (ID: ${oldMember.id})\n**رتبة:** \`\`${role.name}\`\` (ID: ${role.id})\n**بواسطة:** <@${userID}> (ID: ${userID})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(roleRemoved);
        }
    })
    if (oldMember.guild.owner.user.id !== newMember.guild.owner.user.id) {
        let newOwner = new Discord.RichEmbed()
            .setTitle('**[UPDATE GUILD OWNER]**')
            .setThumbnail(oldMember.guild.iconURL)
            .setColor('GREEN')
            .setDescription(`**\n**:white_check_mark: تم بي نجاح \`\`تغير المالك\`\` The Owner Ship.\n\n**المالك القديم:** <@${oldMember.user.id}> (ID: ${oldMember.user.id})\n**المالك الجديد:** <@${newMember.user.id}> (ID: ${newMember.user.id})`)
            .setTimestamp()
            .setFooter(oldMember.guild.name, oldMember.guild.iconURL)

        logChannel.send(newOwner);
    }
});
client.on('guildMemberAdd', member => {
    var logChannel = member.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    let newMember = new Discord.RichEmbed()
        .setTitle('**انضم العضة**')
        .setThumbnail(member.user.avatarURL)
        .setColor('GREEN')
        .setDescription(`**\n**:arrow_lower_right: تم بي نجاح انضمام العضو **${member.user.username}**لهاذ السيرفر!\n\n**المستخدم:** <@${member.user.id}> (ID: ${member.user.id})\n**في يوم:** ${Days(member.user.createdAt)}`)
        .setTimestamp()
        .setFooter(member.user.tag, member.user.avatarURL)

    logChannel.send(newMember);
});

function Days(date) {
    let now = new Date();
    let diff = now.getTime() - date.getTime();
    let days = Math.floor(diff / 86400000);
    return days + (days == 1 ? " day" : " days") + " ago";
}
client.on('guildMemberRemove', member => {
    var logChannel = member.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    let leaveMember = new Discord.RichEmbed()
        .setTitle('**[LEAVE MEMBER]**')
        .setThumbnail(member.user.avatarURL)
        .setColor('GREEN')
        .setDescription(`**\n**:arrow_upper_left: Leave **${member.user.username}** From the server.\n\n**User:** <@${member.user.id}> (ID: ${member.user.id})`)
        .setTimestamp()
        .setFooter(member.user.tag, member.user.avatarURL)

    logChannel.send(leaveMember);
});



client.on('voiceStateUpdate', (voiceOld, voiceNew) => {

    if (!voiceOld.guild.member(client.user).hasPermission('EMBED_LINKS')) return;
    if (!voiceOld.guild.member(client.user).hasPermission('VIEW_AUDIT_LOG')) return;

    var logChannel = voiceOld.guild.channels.find(c => c.name === 'log');
    if (!logChannel) return;

    voiceOld.guild.fetchAuditLogs().then(logs => {
        var userID = logs.entries.first().executor.id;
        var userTag = logs.entries.first().executor.tag;
        var userAvatar = logs.entries.first().executor.avatarURL;


        if (voiceOld.serverMute === false && voiceNew.serverMute === true) {
            let serverMutev = new Discord.RichEmbed()
                .setTitle('**[VOICE MUTE]**')
                .setThumbnail('https://images-ext-1.discordapp.net/external/pWQaw076OHwVIFZyeFoLXvweo0T_fDz6U5C9RBlw_fQ/https/cdn.pg.sa/UosmjqDNgS.png')
                .setColor('RED')
                .setDescription(`**User:** <@${voiceOld.user.id}> (ID: ${voiceOld.user.id})\n**By:** <@${userID}> (ID: ${userID})\n**Channel:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannel.id})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(serverMutev);
        }

        if (voiceOld.serverMute === true && voiceNew.serverMute === false) {
            let serverUnmutev = new Discord.RichEmbed()
                .setTitle('**[VOICE UNMUTE]**')
                .setThumbnail('https://images-ext-1.discordapp.net/external/u2JNOTOc1IVJGEb1uCKRdQHXIj5-r8aHa3tSap6SjqM/https/cdn.pg.sa/Iy4t8H4T7n.png')
                .setColor('GREEN')
                .setDescription(`**User:** <@${voiceOld.user.id}> (ID: ${voiceOld.user.id})\n**By:** <@${userID}> (ID: ${userID})\n**Channel:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannel.id})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(serverUnmutev);
        }

        if (voiceOld.serverDeaf === false && voiceNew.serverDeaf === true) {
            let serverDeafv = new Discord.RichEmbed()
                .setTitle('**[VOICE DEAFEN]**')
                .setThumbnail('https://images-ext-1.discordapp.net/external/7ENt2ldbD-3L3wRoDBhKHb9FfImkjFxYR6DbLYRjhjA/https/cdn.pg.sa/auWd5b95AV.png')
                .setColor('RED')
                .setDescription(`**User:** <@${voiceOld.user.id}> (ID: ${voiceOld.user.id})\n**By:** <@${userID}> (ID: ${userID})\n**Channel:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannel.id})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(serverDeafv);
        }

        if (voiceOld.serverDeaf === true && voiceNew.serverDeaf === false) {
            let serverUndeafv = new Discord.RichEmbed()
                .setTitle('**[VOICE UNDEAFEN]**')
                .setThumbnail('https://images-ext-2.discordapp.net/external/s_abcfAlNdxl3uYVXnA2evSKBTpU6Ou3oimkejx3fiQ/https/cdn.pg.sa/i7fC8qnbRF.png')
                .setColor('GREEN')
                .setDescription(`**User:** <@${voiceOld.user.id}> (ID: ${voiceOld.user.id})\n**By:** <@${userID}> (ID: ${userID})\n**Channel:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannel.id})`)
                .setTimestamp()
                .setFooter(userTag, userAvatar)

            logChannel.send(serverUndeafv);
        }
    })

    if (voiceOld.voiceChannelID !== voiceNew.voiceChannelID && !voiceOld.voiceChannel) {
        let voiceJoin = new Discord.RichEmbed()
            .setTitle('**[JOIN VOICE ROOM]**')
            .setColor('GREEN')
            .setThumbnail(voiceOld.user.avatarURL)
            .setDescription(`**\n**:arrow_lower_right: Successfully \`\`JOIN\`\` To Voice Channel.\n\n**Channel:** \`\`${voiceNew.voiceChannel.name}\`\` (ID: ${voiceNew.voiceChannelID})\n**User:** ${voiceOld} (ID: ${voiceOld.id})`)
            .setTimestamp()
            .setFooter(voiceOld.user.tag, voiceOld.user.avatarURL)

        logChannel.send(voiceJoin);
    }

    if (voiceOld.voiceChannelID !== voiceNew.voiceChannelID && !voiceNew.voiceChannel) {
        let voiceLeave = new Discord.RichEmbed()
            .setTitle('**[LEAVE VOICE ROOM]**')
            .setColor('GREEN')
            .setThumbnail(voiceOld.user.avatarURL)
            .setDescription(`**\n**:arrow_upper_left: Successfully \`\`LEAVE\`\` From Voice Channel.\n\n**Channel:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannelID})\n**User:** ${voiceOld} (ID: ${voiceOld.id})`)
            .setTimestamp()
            .setFooter(voiceOld.user.tag, voiceOld.user.avatarURL)

        logChannel.send(voiceLeave);
    }

    if (voiceOld.voiceChannelID !== voiceNew.voiceChannelID && voiceNew.voiceChannel && voiceOld.voiceChannel != null) {
        let voiceLeave = new Discord.RichEmbed()
            .setTitle('**[CHANGED VOICE ROOM]**')
            .setColor('GREEN')
            .setThumbnail(voiceOld.user.avatarURL)
            .setDescription(`**\n**:repeat: Successfully \`\`CHANGED\`\` The Voice Channel.\n\n**From:** \`\`${voiceOld.voiceChannel.name}\`\` (ID: ${voiceOld.voiceChannelID})\n**To:** \`\`${voiceNew.voiceChannel.name}\`\` (ID: ${voiceNew.voiceChannelID})\n**User:** ${voiceOld} (ID: ${voiceOld.id})`)
            .setTimestamp()
            .setFooter(voiceOld.user.tag, voiceOld.user.avatarURL)

        logChannel.send(voiceLeave);
    }
});



client.on("message", msg => {
    if (msg.content === prefix + "id" || msg.content === prefix + "معلوماتي") {
        const embed = new Discord.RichEmbed();
        embed.addField("🔱| اسم الحساب :", `${msg.author.username}#${msg.author.discriminator}`, true)
            .addField("🆔| الاي دي :", `${msg.author.id}`, true)
            .setColor("RANDOM")
            .setFooter(msg.author.username, msg.author.avatarURL)
            .setThumbnail(`${msg.author.avatarURL}`)
            .setTimestamp()
            .setURL(`${msg.author.avatarURL}`)
            .addField('📛| الحالة :', `${msg.author.presence.status.toUpperCase()}`, true)
            .addField('🎲| بلاينج :', `${msg.author.presence.game === null ? "No Game" : msg.author.presence.game.name}`, true)
            .addField('🏅| الرتب : ', `${msg.member.roles.filter(r => r.name).size}`, true)
            .addField('📅| تم الانضمام للديسكورد في :', `${msg.createdAt}`, true)
            .addField('🤖| هل هو بوت ؟', `${msg.author.bot.toString().toUpperCase()}`, true);
        msg.channel.send({ embed: embed })
    }
});

client.on('message', function(message) {

    let args = message.content.split(" ").slice(1).join(" ");
    if (message.content.startsWith(prefix + "say") || message.content.startsWith(prefix + "قول")) {
        if (!args) return;
        message.channel.send(`**${args}**`);
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + "hack") || message.content.startsWith(prefix + "هكر")) {
        if (!message.author.id === '') return;
        if (message.author.bot) return
        message.delete();
        let args = message.content.split(' ').slice(1);

        let virusname = args.join(' ');
        if (virusname < 1) {
            return message.channel.send("**```اكتب اسم الشخص الي تبي يتهكر```**");
        }
        message.channel.send({ embed: new Discord.RichEmbed().setTitle('Loading ' + virusname + "...").setColor(0xFF0000) }).then(function(m) {
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓ ] 1%').setColor(0xFF0000) })
            }, 1000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓ ] 2%').setColor(0xFF0000) })
            }, 2000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓ ] 3%').setColor(0xFF0000) })
            }, 3000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓ ] 4%').setColor(0xFF0000) })
            }, 4000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓ ] 20%').setColor(0xFF0000) })
            }, 5000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 30%').setColor(0xFF0000) })
            }, 6000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 40%').setColor(0xFF0000) })
            }, 7000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 50%').setColor(0xFF0000) })
            }, 8000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 70%').setColor(0xFF0000) })
            }, 9000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 85%').setColor(0xFF0000) })
            }, 10000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 90%').setColor(0xFF0000) })
            }, 11000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 95%').setColor(0xFF0000) })
            }, 12000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 96%').setColor(0xFF0000) })
            }, 13000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 97%').setColor(0xFF0000) })
            }, 14000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 98%').setColor(0xFF0000) })
            }, 15000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ] 99%').setColor(0xFF0000) })
            }, 16000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: Loading Discord Virus [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 100%').setColor(0xFF0000) })
            }, 17000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']:' + virusname + 'done it\'s going good 100.9%').setColor(0xFF0000) })
            }, 18000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يتم تهكير ').setColor(0xFF0000) })
            }, 19000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: تحديث بسيط' + virusname + ".key").setColor(0xFF0000) })
            }, 22000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يرجى انتضار ثواني 5...').setColor(0xFF0000) })
            }, 25000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يرجى انتضار ثواني 4...').setColor(0xFF0000) })
            }, 26000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يرجى انتضار ثواني 3...').setColor(0xFF0000) })
            }, 27000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يرجى انتضار ثواني 2...').setColor(0xFF0000) })
            }, 28000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: يرجى انتضار ثواني 1...').setColor(0xFF0000) })
            }, 29000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 99%').setColor(0xFF0000) })
            }, 30000)
            setTimeout(function() {
                m.edit({ embed: new Discord.RichEmbed().setTitle('[' + virusname + ']: ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓]100% virus added').setColor(0xFF0000) })
            }, 31000)
            setTimeout(function() {
                m.delete()
            }, 32000)
            setTimeout(function() {
                message.channel.send('** ! تمت عمليه التهكير بنجاح **')
            }, 33000)
        });
    }
})




client.on('message', message => {
    let args = message.content.split(' ');
    if (args[0] === `${prefix}avatar`) {
        let mentions = message.mentions.members.first()
        if (!mentions) {
            let sicon = message.author.avatarURL
            let embed = new Discord.RichEmbed()
                .setImage(message.author.avatarURL)
                .setColor("#f7abab")
                .setDescription(`**${message.author.username}#${message.author.discriminator}**'s avatar :`);
            message.channel.send({ embed })
        } else {
            let sicon = mentions.user.avatarURL
            let embed = new Discord.RichEmbed()
                .setColor("#f7abab")
                .setDescription(`**${mentions.user.username}#${mentions.user.discriminator}**'s avatar :`)
                .setImage(sicon)
            message.channel.send({ embed })
        }
    };
});




client.on('message', message => {
    if (message.author.bot) return;
    if (message.content.startsWith(prefix + "contact")) {
        if (!message.channel.guild) return;



        let args = message.content.split(" ").slice(1).join(" ");



        client.users.get(`${devs}`).send(
            "\n" + "**" + "● السيرفر :" + "**" +
            "\n" + "**" + "» " + message.guild.name + "**" +
            "\n" + "**" + " ● المرسل : " + "**" +
            "\n" + "**" + "» " + message.author.tag + "**" +
            "\n" + "**" + " ● الرسالة : " + "**" +
            "\n" + "**" + args + "**")

        let embed = new Discord.RichEmbed()
            .setAuthor(message.author.username, message.author.avatarURL)
            .setDescription('📬 تم ارسال الرسالة الى صاحب البوت بنجاح')
            .setThumbnail(message.author.avatarURL)
            .setFooter("Bot | System")


        message.channel.send(embed);


    }

});










client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'ping')) {
        if (!message.channel.guild) return;
        var msg = `${Date.now() - message.createdTimestamp}`
        var api = `${Math.round(client.ping)}`
        if (message.author.bot) return;
        let embed = new Discord.RichEmbed()
            .setAuthor(message.author.username, message.author.avatarURL)
            .setColor('#5016f3')
            .addField('**Time Taken:**', msg + " ms :signal_strength: ")
            .addField('**WebSocket:**', api + " ms :signal_strength: ")
            .setTimestamp()
        message.channel.send({ embed: embed });
    }
});

client.on("guildMemberAdd", member => {
    member.createDM().then(function(channel) {
        return channel.send(`:rose:  ولكم نورت السيرفر:rose: 
:crown:اسم العضو  ${member}:crown:  
انت العضو رقم ${member.guild.memberCount} `)
    }).catch(console.error)
})

client.on('message', message => {
    if (message.content.includes('discord.gg/')) {
        if (message.member.hasPermission('ADMINISTRATOR')) return;
        message.delete();
        message.guild.member(message.author).addRole(message.guild.roles.find(r => r.name === 'Muted'));
        let embedP = new Discord.RichEmbed()
            .setTitle('❌ | تمت معاقبتك')
            .setAuthor(message.author.username, message.author.avatarURL)
            .addField(`** لقد قمت بمخالفة قوانين السيرفر من خلال نشر روابط اضافة الى سيرفرات اخرى  **`, `**ملاحظة  : إن كآن هذآ الاسكات عن طريق الخطأ الرجاء التوجه والتكلم مع الادآرة**`)
            .addField(`by`, `LegendSystem. `)
            .setColor('RED')
            .setThumbnail(message.author.avatarURL)
            .setFooter(`${message.guild.name} Server`, message.guild.iconURL)

        message.channel.send(embedP);
    }
});



client.on('message', message => {
    if (message.content === prefix + "mutechannel" || message.content === prefix + "اقفل" || message.content === prefix + "قفل" || message.content === "قفل") {
        if (!message.channel.guild) return message.reply('**هاذ الامر مخصص للسيرفرات**');

        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply(' **ليس لديك __الصلاحية__:Nope: **');
        message.channel.overwritePermissions(message.guild.id, {
            SEND_MESSAGES: false

        }).then(() => {
            message.reply("**تم قفل __الشات__:white_check_mark: **")
        });
    }

    if (message.content === prefix + "unmutechannel" || message.content === prefix + "فتح" || message.content === prefix + "افتح" || message.content === "فتح") {
        if (!message.channel.guild) return message.reply('** This command only for servers**');

        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply('**ليس لديك الصلاحية:Nope:**');
        message.channel.overwritePermissions(message.guild.id, {
            SEND_MESSAGES: true

        }).then(() => {
            message.reply("**تم فتح __الشات__:white_check_mark:**")
        });
    }

});

client.on('message', message => {
    if (message.content.startsWith(prefix + "bot") || message.content.startsWith(prefix + "بوت")) {
        message.channel.send({
            embed: new Discord.RichEmbed()
                .setAuthor(client.user.username, client.user.avatarURL)
                .setThumbnail(client.user.avatarURL)
                .setColor('RANDOM')
                .setTitle('Info WESO.Bot.')
                .addField('``My Ping``', [`${Date.now() - message.createdTimestamp}` + 'MS'], true)
                .addField('``RAM Usage``', `[${(process.memoryUsage().rss / 1048576).toFixed()}MB]`, true)
                .addField('``servers``', [client.guilds.size], true)
                .addField('``channels``', `[ ${client.channels.size} ]`, true)
                .addField('``Users``', `[ ${client.users.size} ]`, true)
                .addField('``My Name``', `[ ${client.user.tag} ]`, true)
                .addField('``My ID``', `[ ${client.user.id} ]`, true)
                .addField('``My Prefix``', `[ - ]`, true)
                .addField('``My Language``', `[ Java Script ]`, true)
        })
    }
});

client.on("message", message => {
    if (!message.channel.guild) return;
    if (message.author.bot) return;
    if (message.content === prefix + "savatar") {
        const embed = new Discord.RichEmbed()

        .setTitle(`ServerAvatar${message.guild.name} **  `)
            .setAuthor(message.author.username, message.guild.iconrURL)
            .setColor(0x164fe3)
            .setImage(message.guild.iconURL)
            .setURL(message.guild.iconrURL)
            .setTimestamp()

        message.channel.send({ embed });
    }
});


client.on("message", message => {
    var args = message.content.substring(prefix.length).split(" ");
    if (message.content.startsWith(prefix + "clear") || message.content.startsWith(prefix + "مسح") || message.content.startsWith(prefix + "امسح") || message.content.startsWith("مسح")) {
        if (!message.channel.guild) return message.reply('**❌ اسف لكن هذا الامر للسيرفرات فقط **');
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply('**⚠  لا يوجد لديك صلاحية لمسح الشات**');
        var msg;
        msg = parseInt();

        message.channel.fetchMessages({ limit: msg }).then(messages => message.channel.bulkDelete(messages)).catch(console.error);
        message.channel.sendMessage("", {
            embed: {
                title: "تــم مسح الشات",
                color: 0x5016f3,
                footer: {

                }
            }
        }).then(msg => { msg.delete(3000) });
    }


});


client.on('message', message => {
    if (message.content == prefix + 'members' || message.content == prefix + 'الاعضاء') {
        const embed = new Discord.RichEmbed()
            .setDescription(`**حالات الاعضاء🔋
:green_heart: اونلاين   ${message.guild.members.filter(m=>m.presence.status == 'online').size}
:heart:مشغول       ${message.guild.members.filter(m=>m.presence.status == 'dnd').size}
:yellow_heart: خامل      ${message.guild.members.filter(m=>m.presence.status == 'idle').size}   
:black_heart: اوفلاين   ${message.guild.members.filter(m=>m.presence.status == 'offline').size} 
:blue_heart:   الكل  ${message.guild.memberCount}**`)
        message.channel.send({ embed });

    }
});

client.on('message', message => {
    if (message.channel.type == 'dm') return;
    if (message.content.startsWith(prefix + "talk") || message.content.startsWith(prefix + "تحدث")) {
        var attentions = {};
        attentions[message.guild.id] = {};
        message.channel.send(message.author + ', **Wait , PuP System**').then((m) => {
            m.edit(message.author + ', **أرسل أيدي الروم**')
            m.channel.awaitMessages(m1 => m1.author == message.author, { maxMatches: 1, time: 600000 }).then((m1) => {
                m1 = m1.first();
                attentions[message.guild.id]['id'] = m1.content;
                m1.delete();
                m1 = message.guild.channels.get(`${attentions[message.guild.id]['id']}`)
                if (!m1) return message.reply(`**الأيدي هذا غير صحيح \`${attentions[message.guild.id]['id']}\`**`);

                m.edit(message.author + "**أرسل الرساله المراد توجيهها للروم**")
                m.channel.awaitMessages(m2 => m2.author == message.author, { maxMatches: 1, time: 600000 }).then((m2) => {
                    m2 = m2.first();
                    attentions[message.guild.id]['msg'] = m2.content;
                    m2.delete();
                    m.delete();
                    message.channel.send(`**هل تريد إرسال في روم <#${attentions[message.guild.id]['id']}>
${attentions[message.guild.id]['msg']}**`).then(msge => {
                        msge.react('✅').then(r => {
                            msge.react('❌')
                            const oneFilterBB = (reaction, user) => reaction.emoji.name === '✅' && user.id === message.author.id;
                            const threeFilterBB = (reaction, user) => reaction.emoji.name === '❌' && user.id === message.author.id;
                            const oneBY = msge.createReactionCollector(oneFilterBB, { maxMatches: 1, time: 400000, });
                            const threeBY = msge.createReactionCollector(threeFilterBB, { maxMatches: 1, time: 400000, });
                            oneBY.on('collect', r => {
                                msge.delete();
                                message.guild.channels.get(`${attentions[message.guild.id]['id']}`).send(`${attentions[message.guild.id]['msg']}`)
                            }).catch(RebeL => { console.log('`Error`: ' + RebeL) });
                            threeBY.on('collect', r => {
                                msge.delete();
                            })
                        })
                    })
                });
            });
        });

    }
});




client.on('message', function(msg) {
    if (msg.content.startsWith(prefix + 'server')) {
        if (!msg.channel.guild) return msg.reply('**:x: اسف لكن هذا الامر للاداره فقط**');
        let embed = new Discord.RichEmbed()
            .setColor('RANDOM')
            .setThumbnail(msg.guild.iconURL)
            .addField(':globe_with_meridians: **اسم السيرفر : **', `**[ ${msg.guild.name} ]**`, true)
            .addField(':earth_africa: ** موقع السيرفر :**', `**[ ${msg.guild.region} ]**`, true)
            .addField(':military_medal:** الرتب :**', `**[ ${msg.guild.roles.size} ]**`, true)
            .addField(':bust_in_silhouette:** عدد الاعضاء :**', `**[ ${msg.guild.memberCount} ]**`, true)
            .addField(':white_check_mark:** عدد الاعضاء الاونلاين :**', `**[ ${msg.guild.members.filter(m=>m.presence.status == 'online').size} ]**`, true)
            .addField(':pencil:** الرومات الكتابية :**', `**[ ${msg.guild.channels.filter(m => m.type === 'text').size} ]**`, true)
            .addField(':loud_sound:** رومات الصوت :**', `**[ ${msg.guild.channels.filter(m => m.type === 'voice').size} ]**`, true)
            .addField(':crown:** صاحب السيرفر :**', `**[ ${msg.guild.owner} ]**`, true)
            .addField(':id:** ايدي السيرفر :**', `**[ ${msg.guild.id} ]**`, true)
            .addField(':date:** تم عمل السيرفر في : **', msg.guild.createdAt.toLocaleString())
        msg.channel.send({ embed: embed });
    }
});

const cuttweet = [
    'كت تويت ‏| تخيّل لو أنك سترسم شيء وحيد فيصبح حقيقة، ماذا سترسم؟',
    'كت تويت | أكثر شيء يُسكِت الطفل برأيك؟',
    'كت تويت | الحرية لـ ... ؟',
    'كت تويت | قناة الكرتون المفضلة في طفولتك؟',
    'كت تويت ‏| كلمة للصُداع؟',
    'كت تويت ‏| ما الشيء الذي يُفارقك؟',
    'كت تويت | موقف مميز فعلته مع شخص ولا يزال يذكره لك؟',
    'كت تويت ‏| أيهما ينتصر، الكبرياء أم الحب؟',
    'كت تويت | بعد ١٠ سنين ايش بتكون ؟',
    'كت تويت ‏| مِن أغرب وأجمل الأسماء التي مرت عليك؟',
    '‏كت تويت | عمرك شلت مصيبة عن شخص برغبتك ؟',
    'كت تويت | أكثر سؤال وجِّه إليك مؤخرًا؟',
    '‏كت تويت | ما هو الشيء الذي يجعلك تشعر بالخوف؟',
    '‏كت تويت | وش يفسد الصداقة؟',
    '‏كت تويت | شخص لاترفض له طلبا ؟',
    '‏كت تويت | كم مره خسرت شخص تحبه؟.',
    '‏كت تويت | كيف تتعامل مع الاشخاص السلبيين ؟',
    '‏كت تويت | كلمة تشعر بالخجل اذا قيلت لك؟',
    '‏كت تويت | جسمك اكبر من عٌمرك او العكسّ ؟!',
    '‏كت تويت |أقوى كذبة مشت عليك ؟',
    '‏كت تويت | تتأثر بدموع شخص يبكي قدامك قبل تعرف السبب ؟',
    'كت تويت | هل حدث وضحيت من أجل شخصٍ أحببت؟',
    '‏كت تويت | أكثر تطبيق تستخدمه مؤخرًا؟',
    '‏كت تويت | ‏اكثر شي يرضيك اذا زعلت بدون تفكير ؟',
    '‏كت تويت | وش محتاج عشان تكون مبسوط ؟',
    '‏كت تويت | مطلبك الوحيد الحين ؟',
    '‏كت تويت | هل حدث وشعرت بأنك ارتكبت أحد الذنوب أثناء الصيام؟',
]

client.on('message', message => {
    if (message.content.startsWith(prefix + "cuttweet") || message.content.startsWith(prefix + "كت تويت")) {
        if (!message.channel.guild) return message.reply('** This command only for servers**');
        var embed = new Discord.RichEmbed()
            .setColor('RANDOM')
            .setThumbnail(message.author.avatarURL)
            .addField('لعبه كت تويت',
                `${cuttweet[Math.floor(Math.random() * cuttweet.length)]}`)
        message.channel.sendEmbed(embed);
        console.log('[id] Send By: ' + message.author.username)
    }
});

client.on('message', message => {
    if (!message.content.startsWith(prefix)) return;
    if (!message.channel.guild) return message.reply('**هاذ الامر مخصص للسيرفرات فقط**')
    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);
    if (command === prefix + "kill" || command === "قتل") {

        var sabotage = message.mentions.users.first();
        if (sabotage == message.author) return message.reply(`**الانتحار مو زين و الله**`);
        if (sabotage === client.user) return message.reply(`** تبي تقتلني ؟ **`);
        if (sabotage < 1) {
            message.delete();
            return message.channel.sendMessage('ضع شيئا للقتل، مثل ذكر مستخدم، أو استخدام رمز تعبيري');
        }
        if (!sabotage) return message.channel.send(`Please Mention A Member to Kill :warning:`)
        message.channel.send("▄︻̷̿┻̿═━一 ${sabotage")
            .then(msg => {
                msg.edit(`▄︻̷̿┻̿═━一 ${sabotage} :three:`);
                setTimeout(function() {
                    msg.edit(`▄︻̷̿┻̿═━一 ${sabotage} :two:`);
                }, 1000);
                setTimeout(function() {
                    msg.edit(`▄︻̷̿┻̿═━一 ${sabotage} :one:`);
                }, 2000);
                setTimeout(function() {
                    msg.edit(`▄︻̷̿┻̿═━一 :boom:`);
                }, 3000);
                setTimeout(function() {
                    msg.edit(`▄︻̷̿┻̿═━一 :fire:`);
                }, 4000);
                setTimeout(function() {
                    msg.edit(`▄︻̷̿┻̿═━一 :skull:`);
                }, 5000);
                msg.delete(6000)
                message.delete()
            })
        message.channel.send("**تم اخفاء الجريمة بنجاح 🕳 **").then(msg => msg.delete(7000));
    }
});


const Sra7a = [
    'صراحه  |  صوتك حلوة؟',
    'صراحه  |  التقيت الناس مع وجوهين؟',
    'صراحه  |  شيء وكنت تحقق اللسان؟',
    'صراحه  |  أنا شخص ضعيف عندما؟',
    'صراحه  |  هل ترغب في إظهار حبك ومرفق لشخص أو رؤية هذا الضعف؟',
    'صراحه  |  يدل على أن الكذب مرات تكون ضرورية شي؟',
    'صراحه  |  أشعر بالوحدة على الرغم من أنني تحيط بك كثيرا؟',
    'صراحه  |  كيفية الكشف عن من يكمن عليك؟',
    'صراحه  |  إذا حاول شخص ما أن يكرهه أن يقترب منك ويهتم بك تعطيه فرصة؟',
    'صراحه  |  أشجع شيء حلو في حياتك؟',
    'صراحه  |  طريقة جيدة يقنع حتى لو كانت الفكرة خاطئة" توافق؟',
    'صراحه  |  كيف تتصرف مع من يسيئون فهمك ويأخذ على ذهنه ثم ينتظر أن يرفض؟',
    'صراحه  |  التغيير العادي عندما يكون الشخص الذي يحبه؟',
    'صراحه  |  المواقف الصعبة تضعف لك ولا ترفع؟',
    'صراحه  |  نظرة و يفسد الصداقة؟',
    'صراحه  |  ‏‏إذا أحد قالك كلام سيء بالغالب وش تكون ردة فعلك؟',
    'صراحه  |  شخص معك بالحلوه والمُره؟',
    'صراحه  |  ‏هل تحب إظهار حبك وتعلقك بالشخص أم ترى ذلك ضعف؟',
    'صراحه  |  تأخذ بكلام اللي ينصحك ولا تسوي اللي تبي؟',
    'صراحه  |  وش تتمنى الناس تعرف عليك؟',
    'صراحه  |  ابيع المجرة عشان؟',
    'صراحه  |  أحيانا احس ان الناس ، كمل؟',
    'صراحه  |  مع مين ودك تنام اليوم؟',
    'صراحه  |  صدفة العمر الحلوة هي اني؟',
    'صراحه  |  الكُره العظيم دايم يجي بعد حُب قوي " تتفق؟',
    'صراحه  |  صفة تحبها في نفسك؟',
    'صراحه  |  ‏الفقر فقر العقول ليس الجيوب " ، تتفق؟',
    'صراحه  |  تصلي صلواتك الخمس كلها؟',
    'صراحه  |  ‏تجامل أحد على راحتك؟',
    'صراحه  |  اشجع شيء سويتة بحياتك؟',
    'صراحه  |  وش ناوي تسوي اليوم؟',
    'صراحه  |  وش شعورك لما تشوف المطر؟',
    'صراحه  |  غيرتك هاديه ولا تسوي مشاكل؟',
    'صراحه  |  ما اكثر شي ندمن عليه؟',
    'صراحه  |  اي الدول تتمنى ان تزورها؟',
    'صراحه  |  متى اخر مره بكيت؟',
    'صراحه  |  تقيم حظك ؟ من عشره؟',
    'صراحه  |  هل تعتقد ان حظك سيئ؟',
    'صراحه  |  شـخــص تتمنــي الإنتقــام منـــه؟',
    'صراحه  |  كلمة تود سماعها كل يوم؟',
    'صراحه  |  **هل تُتقن عملك أم تشعر بالممل؟',
    'صراحه  |  هل قمت بانتحال أحد الشخصيات لتكذب على من حولك؟',
    'صراحه  |  متى آخر مرة قمت بعمل مُشكلة كبيرة وتسببت في خسائر؟',
    'صراحه  |  ما هو اسوأ خبر سمعته بحياتك؟',
    '‏صراحه | هل جرحت شخص تحبه من قبل ؟',
    'صراحه  |  ما هي العادة التي تُحب أن تبتعد عنها؟',
    '‏صراحه | هل تحب عائلتك ام تكرههم؟',
    '‏صراحه  |  من هو الشخص الذي يأتي في قلبك بعد الله – سبحانه وتعالى- ورسوله الكريم – صلى الله عليه وسلم؟',
    '‏صراحه  |  هل خجلت من نفسك من قبل؟',
    '‏صراحه  |  ما هو ا الحلم  الذي لم تستطيع ان تحققه؟',
    '‏صراحه  |  ما هو الشخص الذي تحلم به كل ليلة؟',
    '‏صراحه  |  هل تعرضت إلى موقف مُحرج جعلك تكره صاحبهُ؟',
    '‏صراحه  |  هل قمت بالبكاء أمام من تُحب؟',
    '‏صراحه  |  ماذا تختار حبيبك أم صديقك؟',
    '‏صراحه  | هل حياتك سعيدة أم حزينة؟',
    'صراحه  |  ما هي أجمل سنة عشتها بحياتك؟',
    '‏صراحه  |  ما هو عمرك الحقيقي؟',
    '‏صراحه  |  ما اكثر شي ندمن عليه؟',
    'صراحه  |  ما هي أمنياتك المُستقبلية؟‏',
    'صراحه | نفسك فـ ايه ؟',
    'صراحه | هل تحب فتاه او احببت من قبل ؟',
    'صراحه | هل شكلك حلو او جيد او متوسط او سئ ؟',
    'صراحه | ما هي الماده الدراسيه التي تحبها اكثر وتفضلها؟',
    'صراحه | هل تحب مدرستك ؟',
    'صراحه | ما الشئ الذي تتمني ان يحصل ؟',
    'صراحه | هل تحب عائلتك ؟',
]
client.on('message', message => {
    if (message.author.bot) return;
    if (message.content.startsWith(prefix + 'sara7a') || message.content.startsWith(prefix + 'صراحة')) {
        if (!message.channel.guild) return message.reply('**هاذ الامر مخصص لسيرفرات فقط**');
        var client = new Discord.RichEmbed()
            .setTitle("لعبة صراحة ..")
            .setColor('RANDOM')
            .setDescription(`${Sra7a[Math.floor(Math.random() * Sra7a.length)]}`)
            .setImage("https://cdn.discordapp.com/attachments/371269161470525444/384103927060234242/125.png")
            .setTimestamp()

        message.channel.sendEmbed(client);
        message.react("??")
    }
});

client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content == prefix + 'count')
        var IzRo = new Discord.RichEmbed()
            .setThumbnail(message.author.avatarURL)
            .setFooter(message.author.username, message.author.avatarURL)
            .setTitle('🌍| Members info')
            .addBlankField(true)
            .addField('Mmeber Count', `${message.guild.memberCount}`)
    message.channel.send(IzRo);
});

client.on('message', msg => {
    if (msg.author.bot) return;
    if (!msg.content.startsWith(prefix)) return;
    let command = msg.content.split(" ")[0];
    command = command.slice(prefix.length);
    let args = msg.content.split(" ").slice(1);

    if (command === "مسح" || command === prefix + "مسح" || command === prefix + "امسح" || command === prefix + "clear") {
        const emoji = client.emojis.find("name", "wastebasket")
        let textxt = args.slice(0).join("");
        if (msg.member.hasPermission("MANAGE_MESSAGES")) {
            if (textxt == "") {
                msg.delete().then
                msg.channel.send("***```ضع عدد الرسائل التي تريد مسحها 👌```***").then(m => m.delete(3000));
            } else {
                msg.delete().then
                msg.delete().then
                msg.channel.bulkDelete(textxt);
                msg.channel.send("```php\nعدد الرسائل التي تم مسحها: " + textxt + "\n```").then(m => m.delete(3000));
            }
        }
    }
});

var Za7f = [
    "**صورة وجهك او رجلك او خشمك او يدك**.",
    "**اصدر اي صوت يطلبه منك الاعبين**.",
    "**سكر خشمك و قول كلمة من اختيار الاعبين الي معك**.",
    "**روح الى اي قروب عندك في الواتس اب و اكتب اي شيء يطلبه منك الاعبين  الحد الاقصى 3 رسائل**.",
    "**قول نكتة اذا و لازم احد الاعبين يضحك اذا محد ضحك يعطونك ميوت الى ان يجي دورك مرة ثانية**.",
    "**سمعنا صوتك و غن اي اغنية من اختيار الاعبين الي معك**.",
    "**ذي المرة لك لا تعيدها**.",
    "**ارمي جوالك على الارض بقوة و اذا انكسر صور الجوال و ارسله في الشات العام**.",
    "**صور اي شيء يطلبه منك الاعبين**.",
    "**اتصل على ابوك و قول له انك رحت مع بنت و احين هي حامل....**.",
    "**سكر خشمك و قول كلمة من اختيار الاعبين الي معك**.",
    "**سو مشهد تمثيلي عن مصرية بتولد**.",
    "**اعطي اي احد جنبك كف اذا مافيه احد جنبك اعطي نفسك و نبي نسمع صوت الكف**.",
    "**ذي المرة لك لا تعيدها**.",
    "**تعطي اي شخص 5 الاف كرديت**.",
    "**ارمي جوالك على الارض بقوة و اذا انكسر صور الجوال و ارسله في الشات العام**.",
    "**روح عند اي احد بالخاص و قول له انك تحبه و الخ**.",
    "**اكتب في الشات اي شيء يطلبه منك الاعبين في الخاص**.",
    "**قول نكتة اذا و لازم احد الاعبين يضحك اذا محد ضحك يعطونك ميوت الى ان يجي دورك مرة ثانية**.",
    "**سامحتك خلاص مافيه عقاب لك :slight_smile:**.",
    "**اتصل على احد من اخوياك  خوياتك , و اطلب منهم مبلغ على اساس انك صدمت بسيارتك**.",
    "**غير اسمك الى اسم من اختيار الاعبين الي معك**.",
    "**اتصل على امك و قول لها انك تحبها :heart:**.",
    "**لا يوجد سؤال لك سامحتك :slight_smile:**.",
    "**قل لواحد ماتعرفه عطني كف**.",
    "**منشن الجميع وقل انا اكرهكم**.",
    "**اتصل لاخوك و قول له انك سويت حادث و الخ....**.",
    "**روح المطبخ و اكسر صحن او كوب**.",
    "**اعطي اي احد جنبك كف اذا مافيه احد جنبك اعطي نفسك و نبي نسمع صوت الكف**.",
    "**قول لاي بنت موجود في الروم كلمة حلوه**.",
    "**تكلم باللغة الانجليزية الين يجي دورك مرة ثانية لازم تتكلم اذا ما تكلمت تنفذ عقاب ثاني**.",
    "**لا تتكلم ولا كلمة الين يجي دورك مرة ثانية و اذا تكلمت يجيك باند لمدة يوم كامل من الس��رفر**.",
    "**قول قصيدة **.",
    "**تكلم باللهجة السودانية الين يجي دورك مرة ثانية**.",
    "**اتصل على احد من اخوياك  خوياتك , و اطلب منهم مبلغ على اساس انك صدمت بسيارتك**.",
    "**اول واحد تشوفه عطه كف**.",
    "**سو مشهد تمثيلي عن اي شيء يطلبه منك الاعبين**.",
    "**سامحتك خلاص مافيه عقاب لك :slight_smile:**.",
    "**اتصل على ابوك و قول له انك رحت مع بنت و احين هي حامل....**.",
    "**روح اكل ملح + ليمون اذا مافيه اكل اي شيء من اختيار الي معك**.",
    "**تاخذ عقابين**.",
    "**قول اسم امك افتخر بأسم امك**.",
    "**ارمي اي شيء قدامك على اي احد موجود او على نفسك**.",
    "**اذا انت ولد اكسر اغلى او احسن عطور عندك اذا انتي بنت اكسري الروج حقك او الميك اب حقك**.",
    "**اذهب الى واحد ماتعرفه وقل له انا كيوت وابي بوسه**.",
    "**تتصل على الوالده  و تقول لها خطفت شخص**.",
    "** تتصل على الوالده  و تقول لها تزوجت با سر**.",
    "**����تصل على الوالده  و تقول لها  احب وحده**.",
    "**تتصل على شرطي تقول له عندكم مطافي**.",
    "**خلاص سامحتك**.",
    "** تصيح في الشارع انا  مجنوون**.",
    "** تروح عند شخص تقول له احبك**.",

];

client.on('message', message => {
    if (message.content === prefix + "rooms" || message.content === prefix + "روماتي") {
        var channels = message.guild.channels.map(channels => `${channels.name}, `).join(' ')
        const embed = new Discord.RichEmbed()
            .setColor('RANDOM')
            .addField('rooms:', `**[${channels}]**`)
        message.channel.sendEmbed(embed);
    }
});

client.on('message', async message => {
    var time = moment().format('Do MMMM YYYY , hh:mm');
    var room;
    var title;
    var duration;
    var gMembers;
    var currentTime = new Date(),
        hours = currentTime.getHours() + 3,
        minutes = currentTime.getMinutes(),
        done = currentTime.getMinutes() + duration / 60000,
        seconds = currentTime.getSeconds();
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    var suffix = "AM";
    if (hours >= 12) {
        suffix = "PM";
        hours = hours - 12;
    }
    if (hours == 0) {
        hours = 12;
    }

    var filter = m => m.author.id === message.author.id;
    if (message.content.startsWith(prefix + "giveaway")) {

        if (!message.guild.member(message.author).hasPermission('MANAGE_GUILD')) return message.channel.send(':heavy_multiplication_x:| **يجب أن يكون لديك خاصية التعديل على السيرفر**');
        message.channel.send(`:eight_pointed_black_star:| **اكتب اسم روم الجيفاواي**`).then(msg => {
            message.channel.awaitMessages(filter, {
                max: 1,
                time: 20000,
                errors: ['time']
            }).then(collected => {
                let room = message.guild.channels.find('name', collected.first().content);
                if (!room) return message.channel.send(':heavy_multiplication_x:| **i Found It :(**');
                room = collected.first().content;
                collected.first().delete();
                msg.edit(':eight_pointed_black_star:| **كم تريد وقت الجيفواي**').then(msg => {
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 20000,
                        errors: ['time']
                    }).then(collected => {
                        if (isNaN(collected.first().content)) return message.channel.send(':heavy_multiplication_x:| **انا لم افهم هاذا الوقت**');
                        duration = collected.first().content * 60000;
                        collected.first().delete();
                        msg.edit(':eight_pointed_black_star:| **ما هي الجائزة؟**').then(msg => {
                            message.channel.awaitMessages(filter, {
                                max: 1,
                                time: 20000,
                                errors: ['time']
                            }).then(collected => {
                                title = collected.first().content;
                                collected.first().delete();
                                msg.delete();
                                message.delete();
                                try {
                                    let giveEmbed = new Discord.RichEmbed()
                                        .setDescription(`**${title}** \nReact With 🎉 To Enter! \nTime remaining : ${duration / 60000} **Minutes**\n **Created at :** ${hours}:${minutes}:${seconds} ${suffix}`)
                                        .setFooter(message.author.username, message.author.avatarURL);
                                    message.guild.channels.find("name", room).send(' :heavy_check_mark: **تم صنع الجيفواي** :heavy_check_mark:', { embed: giveEmbed }).then(m => {
                                        let re = m.react('🎉');
                                        setTimeout(() => {
                                            let users = m.reactions.get("🎉").users;
                                            let list = users.array().filter(u => u.id !== m.author.id !== client.user.id);
                                            let gFilter = list[Math.floor(Math.random() * list.length) + 0]
                                            let endEmbed = new Discord.RichEmbed()
                                                .setAuthor(message.author.username, message.author.avatarURL)
                                                .setTitle(title)
                                                .addField('Giveaway Ended !🎉', `Winners : ${gFilter} \nEnded at :`)
                                                .setTimestamp()
                                            m.edit('** 🎉 GIVEAWAY ENDED 🎉**', { embed: endEmbed });
                                            message.guild.channels.find("name", room).send(`**Congratulations ${gFilter}! انت ربحت الجيفواي \`${title}\`**`, { embed: {} })
                                        }, duration);
                                    });
                                } catch (e) {
                                    message.channel.send(`:heavy_multiplication_x:| **ليست لدي الصلاحيات الكافية**`);
                                    console.log(e);
                                }
                            });
                        });
                    });
                });
            });
        });
    }
});


client.on('message', message => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);

    let args = message.content.split(" ").slice(1);
    if (command == "za5") {
        let say = new Discord.RichEmbed()
            .setTitle('Text emboss :');
        message.reply(`\n ${zalgo(args.join(' '))}`);
    }

});

client.on('guildCreate', guild => {
    var embed = new Discord.RichEmbed()
        .setColor(0x5500ff)
        .setDescription(`**شكراً لك لإضافه البوت الى سيرفرك**`)
    guild.owner.send(embed)
});




client.on('message', message => {
    var argresult = message.content.split(` `).slice(1).join(' ');
    if (!devs.includes(message.author.id)) return;

    if (message.content.startsWith(prefix + 'pt')) {
        client.user.setGame(argresult);
        message.channel.sendMessage(`**:white_check_mark:   ${argresult}**`)
    } else
    if (message.content === (prefix + "Percie")) {
        message.guild.leave();
    } else
    if (message.content.startsWith(prefix + 'wt')) {
        client.user.setActivity(argresult, { type: 'WATCHING' });
        message.channel.sendMessage(`**:white_check_mark:   ${argresult}**`)
    } else
    if (message.content.startsWith(prefix + 'setprefix')) {
        client.user.setPrefix(argresult).then
        message.channel.send(`**Prefix Changed :white_check_mark: ${argresult}** `)
    } else
    if (message.content.startsWith(prefix + 'ls')) {
        client.user.setActivity(argresult, { type: 'LISTENING' });
        message.channel.sendMessage(`**:white_check_mark:   ${argresult}**`)
    } else
    if (message.content.startsWith(prefix + 'setname')) {
        client.user.setUsername(argresult).then
        message.channel.sendMessage(`**${argresult}** : Done `)
        return message.reply("**Name Changed :white_check_mark:**");
    } else
    if (message.content.startsWith(prefix + 'setavatar')) {
        client.user.setAvatar(argresult);
        message.channel.sendMessage(`**${argresult}** : تم تغير صورة البوت`);
    } else
    if (message.content.startsWith(prefix + 'st')) {
        client.user.setGame(argresult, "https://www.twitch.tv/idk");
        message.channel.sendMessage(`**:white_check_mark:   ${argresult}**`)
    }

});

client.on('message', message => {
    if (message.content.startsWith(prefix + "عقاب")) {
        if (!message.channel.guild) return message.reply('**هاذ الامر مخصص للسيرفرات فقط**');
        var embed = new Discord.RichEmbed()
            .setColor('RANDOM')
            .setThumbnail(message.author.avatarURL)
            .addField('system | Bot',
                `${Za7f[Math.floor(Math.random() * Za7f.length)]}`)
        message.channel.sendEmbed(embed);
        console.log('[wan] Send By: ' + message.author.username)
    }
});


const zead = [
    '*** انا اسمي مريم ***',
    '*** مرحباَ ماهو اسمك ؟ ***',
    `*** اهلا بك ! انا تائهه في هذا المكان  ***`,
    '*** هل تود مساعدتي ؟ ***',
    '*** لماذا هل انت قاسي القلب ؟ ***',
    '*** انني اشفق عليك يجب ان تطهر روحك وتحب الخير للجميع ***',
    '*** ابتعد عني قليل انني متعبة ***',
    '*** هل انت نادم على ماقلت ؟ ***',
    '*** هل تود مساعدتي ؟ ***',
    '*** واو اشكرك انك شخصاَ رائع ! ***',
    '*** ابحث معي عن منزلي لقد كان قريباَ من هنا ***',
    '*** ولاكن عندما حل الليل لم اعد ارى اي شيء ***',
    '*** مذا تظن اين يوجد ؟ يمين او يسار ***',
    '*** هيا اذاَ ***',
    '*** اود ان اسئلك سؤال ونحن في الطريق ***',
    '*** هل تراني فتاة لطيفة ام مخيفة ***',
    '*** اشكرك !  ***',
    '*** لقد وصلنا الى المنزل شكراَ جزيلَ انتطرني ثواني وسوف اعود ***',
    '*** هل انت جاهز ؟ ***',
    '*** لقد اخبرت والدي عنك وهم متحمسين لرؤيتك ***',
    '*** هل تود ان تراهم الان ***',
    '*** انا لست الحوت الازرق كما يدعون ***',
    '*** انا لست كاذبة صدقني***',
    '*** لماذا ارى في عينيك الخوف ؟ ***',
    '*** انا مجرد فتاة لطيفة تحب اللعب مع الجميع ***',
    '*** اعرف كل شيء يحدث اسمع ذالك بالراديو ***',
    '*** سمعت ان البشر يقتلون من اجل المال فقط ***',
    '*** لماذا لم تدخل الغرفة ؟ ***',
    '*** ههههههههههههههههههه انت الان مسجون في هذه الغرفة ***',
    '*** لن تخرج حتى اعود لك بعد قليل ***',
    '*** المفتاح معك ! اكتب .مريم  ***',
    '*** مفتاح احمر , هل حصلت عليه ؟ ***',
    '*** ان لم تحصل عليه , اكتب .مريم مرة اخرى ***',
    '*** مفتاح اسود . هل حصلت عليه ؟ ***',
    '*** اين تريد ان تختبئ بسرعة قبل ان تعود ***',
    '*** لقد عادت من جديد الى المنزل ***',
    '*** لا تصدر اي صوت ! ***',
    '*** مريم : لقد عدت ***',
    '*** مريم : يا ايها المخادع اين انت ***',
    '*** مريم : اعلم انك هنا في المنزل ***',
    '*** مريم : ماذا تريد ان تسمع ***',
    '*** احد ما خرج من المنزل ***',
    '*** انتظر الجزء الثاني عندما يوصل البوت 100 سيرفر , ساعدني في نشر البوت وادخل هذا السيرفر  ***'
];
client.on('message', message => {
    if (message.content.startsWith(prefix + 'مريم')) {
        var mariam = new Discord.RichEmbed()
            .setTitle("لعبة مريم ..")
            .setColor('RANDOM')
            .setDescription(`${zead[Math.floor(Math.random() * zead.length)]}`)
            .setImage("https://www.npa-ar.com/wp-content/uploads/2017/08/%D9%84%D8%B9%D8%A8%D8%A9-%D9%85%D8%B1%D9%8A%D9%85-300x200.jpg")
        message.channel.sendEmbed(mariam);
    }
});

client.on("message", function(message) {
    if (message.content.startsWith(prefix + "rps")) {
        let messageArgs = message.content.split(" ").slice(1).join(" ");
        let messageRPS = message.content.split(" ").slice(2).join(" ");
        let arrayRPS = ['**Rock**', '**Paper**', '**Scissors**'];
        let result = `${arrayRPS[Math.floor(Math.random() * arrayRPS.length)]}`;
        var RpsEmbed = new Discord.RichEmbed()
            .setAuthor(message.author.username)
            .setThumbnail(message.author.avatarURL)
            .addField("Rock", "🇷", true)
            .addField("Paper", "🇵", true)
            .addField("Scissors", "🇸", true)
        message.channel.send(RpsEmbed).then(msg => {
            msg.react(' 🇷')
            msg.react("🇸")
            msg.react("🇵")
                .then(() => msg.react('🇷'))
                .then(() => msg.react('🇸'))
                .then(() => msg.react('🇵'))
            let reaction1Filter = (reaction, user) => reaction.emoji.name === '🇷' && user.id === message.author.id;
            let reaction2Filter = (reaction, user) => reaction.emoji.name === '🇸' && user.id === message.author.id;
            let reaction3Filter = (reaction, user) => reaction.emoji.name === '🇵' && user.id === message.author.id;
            let reaction1 = msg.createReactionCollector(reaction1Filter, { time: 12000 });
            let reaction2 = msg.createReactionCollector(reaction2Filter, { time: 12000 });
            let reaction3 = msg.createReactionCollector(reaction3Filter, { time: 12000 });
            reaction1.on("collect", r => {
                message.channel.send(result)
            })
            reaction2.on("collect", r => {
                message.channel.send(result)
            })
            reaction3.on("collect", r => {
                message.channel.send(result)
            })

        })
    }
});

client.on('message', message => {
    if (message.content == prefix + "quas" || message.content == prefix + "سؤال") {
        message.react('🤔', '👌')
        var x = ['اين يلعب مصطفي فتحي؟', 'ما هو اسم ملعب بارشالونة', 'ما هو يوم الحج الأكبر؟', 'ما هو أطول أنهار أوربا ؟', 'ما هو اسم بيت الدجاج', 'ما هو أول بنك قام بالنشاط المصرفي في السعودية عام 1926م', 'ما هو أول جامع أقيم في مصر', 'ما هو أطول نهر في آسيا', 'ما هو أقرب كوكب إلى الشمس', 'ما هو الحيوان الذي يُسمى البهنس', 'ما هو اول مسجد أسس بالمدينة', 'متى وقع صلح الحديبية عام 6هـ او 3هـ او 2هـ؟', 'متى قامت أمريكا بأول رحلة فضائية', 'متى كانت غزوة خيبر؟', 'ما هي السورة التي تبدأ بقوله تعالى " يا أيها النبي اتق الله ولا تطع الكافرين والمنافقين إن الله كان عليما حكيما ".اجب؟', 'ما هي السورة التي يطلق عليها عروس القرآن', 'ماذا يسمى من لايقرأ ولايكتب', 'ماهي أول دولة استخدمت طابع البريد', 'ماهو شعار الولايات المتحدة الامريكية', 'ماهو اذكي الحيوانات', 'من هو مكتشف أمريكا', 'مامعنى "فرعون" اجب؟', 'ماهو اقرب كوكب إلى الارض', 'ما هي نسبه المياه من الكره الارضيه?', 'كم عدد السجدات في القرآن الكريم؟', 'من هو بطل كاس العالم في عام 1966', 'أين أفتتح اول متحف في العالم?', 'ماأسم أنثى الحمار?', 'كم تبلغ درجه حراره الشمس؟', 'من هي مدينة الضباب', 'أين توجد أطول سكة حديد في العالم?'];
        var x2 = ['التعاون', 'كامب نو', 'يوم النحر', 'الدانوب', 'قن', 'البنك الهولندي', 'جامع عمرو بن العاص', 'اليانجستي', 'عطارد', 'الاسد', 'مسجد قباء', '6', 'سنة 1962', 'عام 7هـ', 'الاحزاب', 'سورة الرحمن', 'امي', 'بريطانيا', 'النسر الاصلع', 'الدلفين', 'كولمبس', 'البيت الكبير', 'الزهره', '71%', '15 سجدة', 'انكلترا ', 'القاهرة', 'الاتان', '15 مليون درجه مئوية', 'لندن', 'كندا'];
        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(`📢 امامك دقيقة لحل الاسئلة , السؤال يقول :  __**${x[x3]}**__ `).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                thing: true,
                maxMatches: 1,
                time: 60000,
                maxUses: 1,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح `)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author} لقد قمت بكتابة الجواب الصحيح  `);
                message.react('✅')
            })
        })
    }
});


client.on('message', async message => {
    if (message.author.boss) return;

    if (!message.content.startsWith(prefix)) return;
    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);
    let args = message.content.split(" ").slice(1);
    if (command == "mute" || command == "اسكات" || command == "ميوت") {
        if (!message.channel.guild) return;
        if (!message.guild.member(message.author).hasPermission("MANAGE_MESSAGES")) return message.reply("انت لا تملك صلاحيات !! ").then(msg => msg.delete(5000));
        if (!message.guild.member(client.user).hasPermission("MANAGE_MESSAGES")) return message.reply("البوت لايملك صلاحيات ").then(msg => msg.delete(5000));;
        let user = message.mentions.users.first();
        let muteRole = message.guild.roles.find("name", "Muted");
        if (!muteRole) return message.reply("** لا يوجد رتبة الميوت 'Muted' **").then(msg => { msg.delete(5000) });
        if (message.mentions.users.size < 1) return message.reply('** يجب عليك المنشن اولاً **').then(msg => { msg.delete(5000) });
        let reason = message.content.split(" ").slice(2).join(" ");
        message.guild.member(user).addRole(muteRole);
        const muteembed = new Discord.RichEmbed()
            .setColor("RANDOM")
            .setAuthor(`Muted!`, user.displayAvatarURL)
            .setThumbnail(user.displayAvatarURL)
            .addField("**:busts_in_silhouette:  المستخدم**", '**[ ' + `${user.tag}` + ' ]**', true)
            .addField("**:hammer:  تم بواسطة **", '**[ ' + `${message.author.tag}` + ' ]**', true)
            .addField("**:book:  السبب**", '**[ ' + `${reason}` + ' ]**', true)
            .addField("User", user, true)
        message.channel.send({ embed: muteembed });
        var muteembeddm = new Discord.RichEmbed()
            .setAuthor(`Muted!`, user.displayAvatarURL)
            .setDescription(`      
${user} انت معاقب بميوت كتابي بسبب مخالفة القوانين
${message.author.tag} تمت معاقبتك بواسطة
[ ${reason} ] : السبب
اذا كانت العقوبة عن طريق الخطأ تكلم مع المسؤلين
`)
            .setFooter(`في سيرفر : ${message.guild.name}`)
            .setColor("RANDOM")
        user.send(muteembeddm);
    }
})







client.on('message', message => {
    if (message.author.x5bz) return;
    if (!message.content.startsWith(prefix)) return;

    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);

    let args = message.content.split(" ").slice(1);

    if (command == "kick" || command == "طرد" || command == "اطرد") {
        if (!message.channel.guild) return message.reply('** هاذ الامر مخصص للسيرفرات فقط**');

        if (!message.guild.member(message.author).hasPermission("KICK_MEMBERS")) return message.reply("**You Don't Have ` KICK_MEMBERS ` Permission**");
        if (!message.guild.member(client.user).hasPermission("KICK_MEMBERS")) return message.reply("**I Don't Have ` KICK_MEMBERS ` Permission**");
        let user = message.mentions.users.first();
        let reason = message.content.split(" ").slice(2).join(" ");
        if (message.mentions.users.size < 1) return message.reply("**منشن شخص**");
        if (!reason) return message.reply("**اكتب سبب الطرد**");
        if (!message.guild.member(user)
            .kickable) return message.reply("**لايمكنني طرد شخص اعلى من رتبتي يرجه اعطاء البوت رتبه عالي**");

        message.guild.member(user).kick();

        const kickembed = new Discord.RichEmbed()
            .setAuthor(`KICKED!`, user.displayAvatarURL)
            .setColor("RANDOM")
            .setTimestamp()
            .addField("**User:**", '**[ ' + `${user.tag}` + ' ]**')
            .addField("**By:**", '**[ ' + `${message.author.tag}` + ' ]**')
            .addField("**Reason:**", '**[ ' + `${reason}` + ' ]**')
        message.channel.send({
            embed: kickembed
        })
    }
});
client.on('message', message => {
    if (message.author.codes) return;
    if (!message.content.startsWith(prefix)) return;

    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);

    let args = message.content.split(" ").slice(1);

    if (command == "ban" || command == "حظر") {
        if (!message.channel.guild) return message.reply('** This command only for servers**');

        if (!message.guild.member(message.author).hasPermission("BAN_MEMBERS")) return message.reply("**انت لا تملك الصلاحيات المطلوبه**");
        if (!message.guild.member(client.user).hasPermission("BAN_MEMBERS")) return message.reply("****");
        let user = message.mentions.users.first();

        if (message.mentions.users.size < 1) return message.reply("**منشن شخص**");
        if (!message.guild.member(user)
            .bannable) return message.reply("**يجب ان تكون رتبة البوت اعلي من رتبه الشخص المراد تبنيدة**");


        message.guild.member(user).ban(7, user);

        message.channel.send(`**:white_check_mark: ${user.tag}تم طرد العضو من السيرفر ! :airplane: **  `)

    }
});

client.on('message', message => {

    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    let command = message.content.split(" ")[0];
    command = command.slice(prefix.length);

    let args = message.content.split(" ").slice(1);

    if (command == "embed") {
        if (!message.channel.guild) return message.reply('** This command only for servers **');
        let say = new Discord.RichEmbed()
            .addField('Emebad:', `${message.author.username}#${message.author.discriminator}`)
            .setDescription(args.join("  "))
            .setColor(0x23b2d6)
        message.channel.sendEmbed(say);
        message.delete();
    }
});



client.on('message', message => {
    if (message.content.startsWith(prefix + "ct")) {
        if (!message.channel.guild) return message.reply('**❌ اسف لكن هذا الامر للسيرفرات فقط **');
        if (!message.member.hasPermission('MANAGE_CHANNELS')) return message.reply('**لا يوجد لديك الصلاحية ل انشاء شات**');
        var args = message.content.split(" ").slice(1);
        var argrst = args.join(' ');
        message.guild.createChannel(`${argrst}`, 'text')
        const CT = new Discord.RichEmbed()
            .setAuthor(`CT!`, user.displayAvatarURL)
            .setColor("RANDOM")
            .setTimestamp()
            .addField("**اسم الروم:**", '**[ ' + `${channel.name}` + ' ]**')
            .addField("**بواسطة:**", '**[ ' + `${message.author.tag}` + ' ]**')
            .addField("ID: ${channel.id}")
        message.channel.send({ embed: CT })
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + "cv")) {
        if (!message.channel.guild) return message.reply('**❌ اسف لكن هذا الامر للسيرفرات فقط **');
        if (!message.member.hasPermission('MANAGE_CHANNELS')) return message.reply('**لا يوجد لديك الصلاحية ل انشاء شات**');
        var args = message.content.split(" ").slice(1);
        var argrst = args.join(' ');
        message.guild.createChannel(`${argrst}`, 'voice')
        const cv = new Discord.RichEmbed()
            .setAuthor(`cv!`, user.displayAvatarURL)
            .setColor("RANDOM")
            .setTimestamp()
            .addField("**اسم الروم:**", '**[ ' + `${channel.name}` + ' ]**')
            .addField("**بواسطة:**", '**[ ' + `${message.author.tag}` + ' ]**')
            .addField("ID: ${channel.id}")
        message.channel.send({ embed: CT })
    }
});




client.on('message', msg => {
    if (msg.content.startsWith(prefix + 'send')) {
        let args = msg.content.split(' ').slice(1)
        if (!args[0]) return msg.reply(`**منشن الشخص اولا**`)
        if (!args[1]) return msg.reply(`**ما هي الرساله المطلوب ارسالها**`)
        let alpha = msg.mentions.members.first()
        if (!alpha) return msg.reply(`**يجب تحديد الشخص**`)
        let alphaEmbed = new Discord.RichEmbed()
            .setTitle(`**رسالة جديده لك من شخص ما**`)
            .setDescription(args.join(" "))

        client.users.get(`${alpha.id}`).send(alphaEmbed)
        msg.reply(`**تم ارسال الرساله**`)
    }
});

var cats = [

    "https://static.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg",
    "https://www.petfinder.com/wp-content/uploads/2012/11/101438745-cat-conjunctivitis-causes.jpg",
    "http://www.i-love-cats.com/images/2015/04/12/cat-wallpaper-38.jpg",
    "https://www.aspca.org/sites/default/files/cat-care_urine-marking_main-image.jpg",
    "https://vignette1.wikia.nocookie.net/houseofnight/images/8/8b/Cats.jpg/revision/latest?cb=20130812053537",
    "https://s-media-cache-ak0.pinimg.com/originals/f0/3b/76/f03b7614dfadbbe4c2e8f88b69d12e04.jpg",
    "http://www.rd.com/wp-content/uploads/sites/2/2016/04/15-cat-wants-to-tell-you-attention.jpg"
]
client.on('message', message => {
    var args = message.content.split(" ").slice(1);
    if (message.content.startsWith(prefix + 'cat') || message.content.startsWith(prefix + 'قطة')) {
        if (!message.channel.guild) return message.reply('** This command only for servers **');
        var cat = new Discord.RichEmbed()
            .setImage(cats[Math.floor(Math.random() * cats.length)])
            .setColor(0xd3d0c4)
            .setFooter(`system | Bot`)
        message.channel.sendEmbed(cat);

    }
});

client.on('message', message => {;
    let user = message.mentions.users.first() || client.users.get(message.content.split(' ')[1])
    if (message.content.startsWith(prefix + 'unban')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('❌|**\`ADMINISTRATOR\`لا توجد لديك رتبة`**');
        if (!user) return message.channel.send(`Do this ${prefix} <@ID user> \n or \n ${prefix}unban ID user`);
        message.guild.unban(user);
        message.guild.owner.send(`لقد تم فك الباند عن الشخص \n ${user} \n By : <@${message.author.id}>`)
        var embed = new Discord.RichEmbed()
            .setThumbnail(message.author.avatarURl)
            .setColor("RANDOM")
            .setTitle('**●Unban** !')
            .addField('**●User Unban :** ', `${user}`, true)
            .addField('**●By :**', ` <@${message.author.id}> `, true)
            .setAuthor(message.guild.name)
        message.channel.sendEmbed(embed)
    }
});




client.on('message', message => {
    if (message.content.startsWith(prefix + 'bs')) {
        let msg = client.guilds.map(guild => `**${guild.name}** عدد الاعضاء: ${guild.memberCount}`).join('\n');
        let embed = new Discord.RichEmbed()
            .setTitle(`${client.guilds.size}سيرفرات `)
            .setDescription(`${msg}`)
            .setColor("#ebf442");
        message.channel.send(embed);
    }
});



client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'allbots') || message.content.startsWith(prefix + 'بوتات')) {
        if (message.author.bot) return;
        let i = 1;
        const botssize = message.guild.members.filter(m => m.user.bot).map(m => `${i++} - <@${m.id}>`);
        const embed = new Discord.RichEmbed()
            .setAuthor(message.author.tag, message.author.avatarURL)
            .setDescription(`**Found ${message.guild.members.filter(m=>m.user.bot).size} bots in this Server**
${botssize.join('\n')}`)
            .setFooter(client.user.username, client.user.avatarURL)
            .setTimestamp();
        message.channel.send(embed)

    }


});

client.on('message', message => {
    if (message.content.startsWith(prefix + 'mvall') || message.content.startsWith(prefix + 'سحب الكل')) {
        if (!message.member.hasPermission("MOVE_MEMBERS")) return message.channel.send('**:x:ليس لديك الصلاحيات لنقل الاعضاء**');
        if (!message.guild.member(client.user).hasPermission("MOVE_MEMBERS")) return message.reply("**:x: I Dont Have Perms `MOVE_MEMBERS`**");
        if (message.member.voiceChannel == null) return message.channel.send(`**يجب أن تكون في غرفة الصوت**`)
        var author = message.member.voiceChannelID;
        var m = message.guild.members.filter(m => m.voiceChannel)
        message.guild.members.filter(m => m.voiceChannel).forEach(m => {
            m.setVoiceChannel(author)
        })
        message.channel.send(`**:white_check_mark: تم بي نجاح نقل الاعضاء**`)


    }
});

client.on('message', message => {
    if (message.author.bot) return;
    if (message.content.startsWith(prefix + "xo")) {
        let array_of_mentions = message.mentions.users.array();
        let symbols = [':o:', ':heavy_multiplication_x:']
        var grid_message;

        if (array_of_mentions.length == 1 || array_of_mentions.length == 2) {
            let random1 = Math.floor(Math.random() * (1 - 0 + 1)) + 0;
            let random2 = Math.abs(random1 - 1);
            if (array_of_mentions.length == 1) {
                random1 = 0;
                random2 = 0;
            }
            var player1_id = message.author.id
            let player2_id = array_of_mentions[random2].id;
            var turn_id = player1_id;
            var symbol = symbols[0];
            let initial_message = `المباراة بين<@${player1_id}> and <@${player2_id}>!`;
            if (player1_id == player2_id) {
                initial_message += '\n_( ألعب مع نفسك)_'
            }
            message.channel.send(`Xo ${initial_message}`)
                .then(console.log("Successful tictactoe introduction"))
                .catch(console.error);
            message.channel.send(':one::two::three:' + '\n' +
                    ':four::five::six:' + '\n' +
                    ':seven::eight::nine:')
                .then((new_message) => {
                    grid_message = new_message;
                })
                .then(console.log("Successful tictactoe game initialization"))
                .catch(console.error);
            message.channel.send('يجب الانتضار حيث ما يتم الموافقه')
                .then(async(new_message) => {
                    await new_message.react('1⃣');
                    await new_message.react('2⃣');
                    await new_message.react('3⃣');
                    await new_message.react('4⃣');
                    await new_message.react('5⃣');
                    await new_message.react('6⃣');
                    await new_message.react('7⃣');
                    await new_message.react('8⃣');
                    await new_message.react('9⃣');
                    await new_message.react('🆗');
                    await new_message.edit(`It\'s <@${turn_id}>\'s turn! Your symbol is ${symbol}`)
                        .then((new_new_message) => {
                            require('./xo.js')(client, message, new_new_message, player1_id, player2_id, turn_id, symbol, symbols, grid_message);
                        })
                        .then(console.log("Successful tictactoe listener initialization"))
                        .catch(console.error);
                })
                .then(console.log("Successful tictactoe react initialization"))
                .catch(console.error);
        } else {
            message.reply(`منشن مع من تريد ألعب`)
                .then(console.log("Successful error reply"))
                .catch(console.error);
        }
    }
});

client.on('message', msg => {
    if (msg.content.startsWith(prefix + 'cal')) {
        let args = msg.content.split(" ").slice(1);
        const question = args.join(' ');
        if (args.length < 1) {
            msg.reply('حدد معادلة من فضلك..');
        } else {
            let answer;
            try {
                answer = math.eval(question);
            } catch (err) {
                msg.reply(`Error: ${err}`);
            }

            const embed = new Discord.RichEmbed()
                .addField("**إدخال**: ", `**${question}**`, true)
                .addField("**إخراج**: ", `**${answer}**`, true)
            msg.channel.send(embed)
        }
    };
});
//امر حذف كل الرتب
/*
client.on('message', omar => {
    if (omar.content.split(' ')[0] == prefix + 'dc') {
        if (!omar.channel.guild) return;
        if (!omar.guild.member(omar.author).hasPermission("MANAGE_CHANNELS")) return omar.reply("**You Don't Have ` MANAGE_CHANNELS ` Permission**");
        if (!omar.guild.member(client.user).hasPermission("MANAGE_CHANNELS")) return omar.reply("**I Don't Have ` MANAGE_CHANNELS ` Permission**");
        omar.guild.channels.forEach(m => {
            m.delete();
        });
    }
    if (omar.content.split(' ')[0] == prefix + 'dr') {
        if (!omar.channel.guild) return;
        if (!omar.guild.member(omar.author).hasPermission("MANAGE_ROLES_OR_PERMISSIONS")) return omar.reply("**You Don't Have ` MANAGE_ROLES_OR_PERMISSIONS ` Permission**");
        if (!omar.guild.member(client.user).hasPermission("MANAGE_ROLES_OR_PERMISSIONS")) return omar.reply("**I Don't Have ` MANAGE_ROLES_OR_PERMISSIONS ` Permission**");
        omar.guild.roles.forEach(m => {
            m.delete();
        });
        omar.reply("✅ `Success Deleted All Roles - Ranks`")
    }
});
*/


client.on('message', async message => {

    if (message.content.startsWith(prefix + "تقديم")) {

        if (!message.channel.guild) return message.reply(' ');


        let submite = message.guild.channels.find(`name`, "التقديمات");

        if (!submite) return message.channel.send("❌لم اجد الروم الخاص بالتقديمات");

        let filter = m => m.author.id === message.author.id;

        let thisMessage;

        let thisFalse;

        message.channel.send('📝 **| من فضلك اكتب اسمك الأن... ✏ **').then(msg => {



            message.channel.awaitMessages(filter, {

                max: 1,

                time: 90000,

                errors: ['time']

            })

            .then(collected => {

                    collected.first().delete();

                    thisMessage = collected.first().content;

                    let boi;

                    msg.edit('📜 **| هل ستحترم القوانين؟... ✏ **').then(msg => {



                        message.channel.awaitMessages(filter, {

                            max: 1,

                            time: 90000,

                            errors: ['time']

                        })

                        .then(collected => {

                                collected.first().delete();

                                boi = collected.first().content;

                                let boi2;

                                msg.edit('🤵 **| ما اسم ارتبه التى تريد الحصول عليها ولماذا؟... ✏ **').then(msg => {



                                    message.channel.awaitMessages(filter, {

                                        max: 1,

                                        time: 90000,

                                        errors: ['time']

                                    })

                                    .then(collected => {

                                        collected.first().delete();

                                        boi2 = collected.first().content;

                                        msg.edit('🛡 **| [ هل انت متأكد من تقديمك؟ | [ نعم ] او [ لا**');

                                        message.channel.awaitMessages(response => response.content === 'نعم' || 'لا' && filter, {

                                            max: 1,

                                            time: 90000,

                                            errors: ['time']

                                        })

                                        .then(collected => {

                                                if (collected.first().content === 'لا') {

                                                    msg.delete();

                                                    message.delete();

                                                    thisFalse = false;

                                                }

                                                if (collected.first().content === 'نعم') {

                                                    if (thisFalse === false) return;

                                                    msg.edit('🕊 **| Done ✅, تم بنجاح نشر تقديم في روم التقديمات**');

                                                    collected.first().delete();

                                                    submite.send(`@everyone | @here
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
**[ ${message.guild.name}:arrow_down: ] Submite⬇**
 
[**اسم المقدم**]:
${thisMessage}
 
[**هلسيحترم القوانين؟**]:
${boi}
 
[**اسم الرتبه والسبب**]:
${boi2}
 
[**تم التقديم بواسطة**]:
${message.author}
 
[**ايدي المقدم**]:
${message.author.id}`);

                                                }

                                            }

                                        );

                                    });

                                });

                            }

                        );

                    });

                }

            );

        })
    }
});



client.on('message', message => {
    if (message.content.startsWith(prefix + 'ranks') || message.content.startsWith(prefix + 'رتبي')) {

        const Rank = message.guild.roles.map(e => e.toString()).join(" ");

        const RankList = new Discord.RichEmbed()
            .setTitle('➠ Roles.')
            .setAuthor(message.guild.name, message.guild.iconURL)
            .setColor('RANDOM')
            .setDescription(Rank)
            .setFooter(message.guild.name)
        message.channel.send(RankList)
    }
});

client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'سحب')) {
        if (message.member.hasPermission("MOVE_MEMBERS")) {
            if (message.mentions.users.size === 0) {
                return message.channel.send("``Use : " + prefix + "move @User``")
            }
            if (message.member.voiceChannel != null) {
                if (message.mentions.members.first().voiceChannel != null) {
                    var authorchannel = message.member.voiceChannelID;
                    var usermentioned = message.mentions.members.first().id;
                    var embed = new Discord.RichEmbed()
                        .setTitle("Succes!")
                        .setColor("#000000")
                        .setDescription(`✅ تم ارسال <@${usermentioned}>للروم`)
                    var embed = new Discord.RichEmbed()
                        .setTitle(`لقد تم نقلك ${message.guild.name}`)
                        .setColor("RANDOM")
                        .setDescription(`**<@${message.author.id}>تم نقلك إلى روم!\nServer --> ${message.guild.name}**`)
                    message.guild.members.get(usermentioned).setVoiceChannel(authorchannel).then(m => message.channel.send(embed))
                    message.guild.members.get(usermentioned).send(embed)
                } else {
                    message.channel.send("`لا يمكنك التحرك`" + message.mentions.members.first() + " `يجب أن يكون المستخدم في روم`")
                }
            } else {
                message.channel.send("**``يجب أن تكون في غرفة الصوت لسحبك``**")
            }
        } else {
            message.react("❌")
        }
    }
});



client.on('message', async message => {
    let args = message.content.split(" ").slice(1).join(" ");
    let role = message.guild.roles.find('name', args) || message.guild.roles.get(args);

    if (message.content.startsWith(prefix + "newrole") || message.content.startsWith(prefix + "رتبة جديدة")) {
        if (!args) return message.reply('اكتب اسم الرتبة');
        if (!role) return message.reply('هذه الرتبة غير موجودة');
        let iQp = new Discord.RichEmbed()
            .setAuthor(message.author.tag, message.author.avatarURL)
            .setTitle(message.guild.name)
            .setThumbnail(message.guild.iconURL)
            .addField('- اسم الرتبة', role.name, true)
            .addField('- اي دي الرتبة', role.id, true)
            .addField('- تم انشاء الرتبة', role.createdAt.toLocaleString(), true)
            .addField('- لون الرتبة', role.hexColor, true)
            .addField('- عدد الاعضاء الذي لديهم نفس الرتبة', role.members.size, true)
            .addField('- مركز الرتبة بين كل الرتب', role.position - message.guild.roles.size, true)
            .addField('- خصائص الرتبة', role.permissions, true)
            .setFooter(message.author.tag, message.author.avatarURL);

        message.channel.send(iQp);
    }
});

client.on("message", message => {
    const command = message.content.split(" ")[0];

    if (command == prefix + "kv") {

        if (!message.guild.member(message.author).hasPermission('MOVE_MEMBERS') || !message.guild.member(message.author).hasPermission('ADMINISTRATOR')) {
            return message.reply('تحتاج الى صلاحيات الادمن!');
        }

        var member = message.guild.members.get(message.mentions.users.array()[0].id);
        if (!message.mentions.users) {
            message.reply("منشن الشخص")
            return;
        }

        if (!member.voiceChannel) {
            message.reply("لا يمكنني الوصول الروم صوتية للعضو!")
            return;
        }
        message.guild.createChannel('voicekick', 'voice').then(c => {
            member.setVoiceChannel(c).then(() => {
                c.delete(305).catch(console.log)




            });
        });
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + 'tag')) {
        let args = message.content.split(" ").slice(1);
        if (!args[0]) return message.reply('اكتب الكلمة');

        figlet(args.join(" "), (err, data) => {
            message.channel.send("```" + data + "```")
        })
    }
});



client.on("message", message => {
    if (message.content.startsWith(prefix + "obc")) {
        if (!message.member.hasPermission("ADMINISTRATOR")) return;
        let args = message.content.split(" ").slice(1);
        var argresult = args.join(' ');
        message.guild.members.filter(m => m.presence.status !== 'all').forEach(m => {
            m.send(`${argresult}\n ${m}`);
        })
        message.channel.send(`\`${message.guild.members.filter( m => m.presence.status !== 'all').size}\`:mailbox:  عدد المستلمين `);
        message.delete();
    };
});




client.on('message', (message) => {
    if (message.content.startsWith(prefix + 'kiss') || message.content.startsWith(prefix + 'قبلة') || message.content.startsWith(prefix + 'بوسة')) {
        let user = message.mentions.users.first();
        if (!user) {

            return message.emit('commandUsage', message, this.help);
        }
        var kiss = [
            'https://media.giphy.com/media/Z21HJj2kz9uBG/giphy.gif',
            'https://media.giphy.com/media/dpSrm4cwUmCeQ/giphy.gif',
            'https://media.giphy.com/media/dMYVHzANYb9p6/giphy.gif',
            'https://media.giphy.com/media/DfzHC09hY64Gk/giphy.gif',
            'https://media.giphy.com/media/10UUe8ZsLnaqwo/giphy.gif',
            'https://media.giphy.com/media/v4JbTGe4KJjKo/source.gif',

        ];

        message.channel.send({
            embed: {
                description: `${message.author.username}اداك قبله ا�� بوسه ${user.username}!`,
                image: {
                    url: kiss[Math.floor(Math.random() * kiss.length)]
                }
            }
        }).catch(e => {
            client.log.error(e);
        })
    }
});



client.on('message', message => {
    if (message.content.startsWith(prefix + "cto")) {
        if (!message.channel.guild) return;
        if (!message.member.hasPermission("MANAGE_CHANNEL")) return;
        var a = message.content.split(' ').slice(1).join("  ");
        if (!a) return message.reply("اكتب كلام لوضعه في التوبيك!")
        message.channel.setTopic(`${a}`)
            .then(newChannel => message.channel.send(`تم تغيير التوبيك لـ **${a}**`))
            .catch(console.error);
    }
});




client.on("message", function(message) {
    if (message.content.startsWith(prefix + "help") || message.content.startsWith(prefix + "ساعدني")) {
        let messageArgs = message.content.split(" ").slice(1).join(" ");
        let messageRPS = message.content.split(" ").slice(2).join(" ");
        let arrayRPS = ['**# - Rock**', '**# - Paper**', '**# - Scissors**'];
        let result = `${arrayRPS[Math.floor(Math.random() * arrayRPS.length)]}`;
        var RpsEmbed = new Discord.RichEmbed()
            .setAuthor(message.author.username)
            .setThumbnail(message.author.avatarURL)
            .addField("Puplic | عامه", "👥", true)
            .addField("Admin | ادمنيه", "👑", true)
            .addField("Games | العاب", "🎮", true)
            .addField("BotRooms | رومات البوت", "🤖", true)
            .addField("music | موسيقى", "🎶", true)
        message.channel.send(RpsEmbed).then(msg => {
            msg.react("👥")
            msg.react("👑")
            msg.react("🎮")
            msg.react("🤖")
            msg.react("🎶")
                .then(() => msg.react('👥'))
                .then(() => msg.react('👑'))
                .then(() => msg.react('🎮'))
                .then(() => msg.react('🤖'))
                .then(() => msg.react('🎶'))
            let reaction1Filter = (reaction, user) => reaction.emoji.name === '👥' && user.id === message.author.id;
            let reaction2Filter = (reaction, user) => reaction.emoji.name === '👑' && user.id === message.author.id;
            let reaction3Filter = (reaction, user) => reaction.emoji.name === '🎮' && user.id === message.author.id;
            let reaction4Filter = (reaction, user) => reaction.emoji.name === '🤖' && user.id === message.author.id;
            let reaction5Filter = (reaction, user) => reaction.emoji.name === '🎶' && user.id === message.author.id;
            let reaction1 = msg.createReactionCollector(reaction1Filter, { time: 20000 });
            let reaction2 = msg.createReactionCollector(reaction2Filter, { time: 19000 });
            let reaction3 = msg.createReactionCollector(reaction3Filter, { time: 18000 });
            let reaction4 = msg.createReactionCollector(reaction4Filter, { time: 17000 });
            let reaction5 = msg.createReactionCollector(reaction5Filter, { time: 16000 })
            reaction1.on("collect", r => {
                const embed = new Discord.RichEmbed()
                    .setThumbnail('https://images-ext-2.discordapp.net/external/JD7xvknBVacXHoC2re78AtJN4PUY5IjUZy1uWIqzObI/https/s3.amazonaws.com/eclincher.wp.upload/wp-content/uploads/2015/08/25155834/people-icon.png')
                    .setColor("#000000")
                    .setDescription(`
      :busts_in_silhouette:***__اوامر عامة__***:loudspeaker: 
**
╓${prefix}ping ====> لمعرفة سرعة اتصال البوت
╠${prefix}link ====> يسويلك رابط لمدة يوم وعدد الاستخدامات 100
╠${prefix}tag ====> لعرض الكلام بشكل جميل و كبير
╠${prefix}تقديم
╠${prefix}quran ====> لعرض 200 صفحة من القرآن الكريم
╠${prefix}perms ====> لعرض صلاحياتك
╠${prefix}topinv ====> لعرض صاحب اكثر دعوات 
╠${prefix}hypixel ====> لرؤية احصائياتك في هايبكسل
╠${prefix}contact ====> للتواصل مع صاحب البوت
╠${prefix}clan ====> لعبة الكلانات
╠${prefix}report ====> للابلاغ عن احد
╠${prefix}Minv ====> لمعرفة عدد دعواتك
╠${prefix}color ====> لوضع لون لك
╠${prefix}emojilist ====> لرؤية قائمة اموجيات السيرفر
╠${prefix}date ====> يعرضلك تاريخ اليوم
╠${prefix}email ====> يعطيك ايميل و باس عشوائي
╠${prefix}nweRole Role name ====> يوريك معلومات رتبة باسمها او الايدي حقها
╠${prefix}bot ====> يعرض لك كل معلومات البوت
╠${prefix}say ====> يكرر الكلام الي تكتبو
╠${prefix}savatar ====> صورة السيرفر
╠${prefix}id ====> معلومات عنك
╠${prefix}new ====> يفتح لك تكت
╠${prefix}avatar ====> صورتك او صورة الي تمنشنو
╠${prefix}embed ====> يكرر الي تقولو بشكل حلو
╠${prefix}rules ====> يعرض لك قوانين السيرفر
╠${prefix}v2min ====> لصنع روم صوتي مؤقت
╙${prefix}inv ====> لدعوة البوت الى سيرفرك
**
`)
                message.author.sendEmbed(embed)
                message.reply('تم ارسالك بلخاص')
            })
            reaction2.on("collect", r => {
                const embed = new Discord.RichEmbed()
                    .setThumbnail('https://cdn.discordapp.com/attachments/553862087382925313/556036868492230667/logo-admin-png-4.png')
                    .setColor("#000000")
                    .setDescription(`
      :key:***__اوامر ادارية__***:crown: 
**
╓${prefix}bc ====> رسالة لجميع اعضاء السيرفر
╠${prefix}bk ====> رسالة لجميع اعضاء السيرفر 2
╠${prefix}rolebc ====> رسالة لرتبة معينة
╠${prefix}setbot ====> لعمل روم صوتي بعدد البوتات في السيرفر
╠${prefix}bans ====> الاعضاء المبندين من سيرفرك
╠${prefix}setmember ====> لعمل روم صوتي بعدد اعضاء السيرفر
╠${prefix}cto ====> تغير الكلام في اعلى الروم
╠${prefix}leave ====> لطرد البوت من سيرفرك
╠${prefix}setMedia ====> لتحديد روم الصور
╠${prefix}ranks ====> يوريك رتب السيرفر
╠${prefix}vonline ====> لعمل روم صوتي اونلاين
╠${prefix}schannel ====> اضهار الشات المخفية
╠${prefix}sr Exemple ====> لتغيير اسم السيرفر
╠${prefix}kv ====> لطرد عضو من روم صوتي
╠${prefix}hchannel ====> اخفاء الشات
╠${prefix}talk ====> للتكلم بصفة البوت
╠${prefix}count ====> عدد اعضاء السيرفر
╠${prefix}setlog ====> لصنع روم اللوج
╠${prefix}server ====> يعرض لك معلومات عن السيرفر
╠${prefix}movall ====> لسحب الجميع الى رومك
╠${prefix}sug ====> suggestions لصنع اقتراح لازم روم 
╠${prefix}bs ====> لمعرفة سيرفرات البوت
╠${prefix}rooms ====> لرؤية رومات السيرفر
╠${prefix}dc ====> مسح كل الرومات
╠${prefix}dr ====>  فوق كل الرانكات
╠${prefix}allbots ====> يوريك كل البوتات في سيرفرك
╠${prefix}move ====> لسحب عضو الى روم صوتية
╠${prefix}giveaway ====> لصنع جيفواي
╠${prefix}role @mention rolename ====> لأعطاء رتبة لعضو معين
╠${prefix}role all rolename ====> لأعطاء رتبة للجميع
╠${prefix}role humans rolename ====> لأعطاء رتبة للاشخاص فقط
╠${prefix}role bots rolename ====> لأعطاء رتبة لجميع البوتات
╠${prefix}members ====> حالات اعضاء السيرفر
╠${prefix}send ====> ارسال رسالة لشخص المنشن
╠${prefix}clr <numbr> ====> مسح الشات بعدد
╠${prefix}clear ====> مسح الشات
╠${prefix}mute @user <reason> ====> اعطاء العضو ميوت لازم رتبة <Muted>
╠${prefix}unmute @user ====> لفك الميوت عن الشخص 
╠${prefix}kick @user <reason> ====> طرد الشخص من السيرفر
╠${prefix}ban @user <reason> ====> حضر الشخص من السيرفر
╠${prefix}unban @user ====> لفك حضر الشخص من السيرفر
╠${prefix}mutechannel ====> تقفيل الشات
╠${prefix}unmutechannel ====> فتح الشات
╠${prefix}ct <name> ====> انشاء شات
╙${prefix}cv <name> ====> انشاء رووم فويس
**
`)
                message.author.sendEmbed(embed)
                message.reply('تم ارسالك بلخاص')
            })
            reaction3.on("collect", r => {
                const embed = new Discord.RichEmbed()
                    .setThumbnail('https://images-ext-1.discordapp.net/external/4IGqoA1bqVqu_o2I-jY51fqJFy2S8f8NrzcnzxhFtVU/http/reli.sh/wp-content/themes/relish/assets/img/services/icon-games.png')
                    .setColor("#000000")
                    .setDescription(`
       :video_game: ***__اوامر العاب__***:game_die:
 **       
╓${prefix}8ball ====> لعبه تسال البوت اسال  وهو يجاوب عنها
╠${prefix}cuttweet ====> لعبة كت تويت
╠${prefix}هل تعلم
╠${prefix}cal ====> ألة حاسبة
╠${prefix}za5 ====> لزخرفة ما تقول
╠${prefix}cats ====> قطط كيوت
╠${prefix}love ====> يعطيك اقوال عن الحب 
╠${prefix}حكم
╠${prefix}جمع
╠${prefix}طرح
╠${prefix}ضرب
╠${prefix}فواكه
╠${prefix}فكك
╠${prefix}sara7a ====> لعبة صراحة
╠${prefix}roll ====> قرعة
╠${prefix}xo ====> xo لعبة 
╠${prefix}نكت مضحكه ====> نكت
╠${prefix}kiss ====> ما يحتاج شرح ههههه
╠${prefix}marry ====> لعبة الزواج
╠${prefix}hack ====> لعبه هاك
╠${prefix}kill ====> لعبة قتل
╠${prefix}quas ====> اسئلة عامة
╠${prefix}لعبة مريم ====> مريم
╠${prefix}عواصم
╙${prefix}يعطيك عقابات قاسية ====> عقاب
`)
                message.author.sendEmbed(embed)
                message.reply('تم ارسالك بلخاص')
            })
            reaction4.on("collect", r => {
                const embed = new Discord.RichEmbed()
                    .setColor("#000000")
                    .setDescription(`
            -=- الرومات اللازمة للبوت -=-
			=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.

╔تحتاج رومات بالاسماء التالية
╠Weclom : روم الترحيب
╠leave : روم التوديع
╠suggestions : روم الاقتراحات
╙روم : التقديمات

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.
`)


                message.author.sendEmbed(embed)
                message.reply('تم ارسالك بلخاص')

            })

            reaction5.on("collect", r => {
                const embed = new Discord.RichEmbed()
				    .setThumbnail('https://cdn.discordapp.com/attachments/704473852788605030/728354963209584740/c61ad9214980a069.jpg')
                    .setColor("#000000")
					
                    .setDescription(`**
╔${prefix}play ,p : ل تشغيل اغنية
╠${prefix}skip,s, : لتخطي اغنية
╠${prefix}stop,s , ل ايقاف الاغنية : ايقاف
╠${prefix}resume,r,ل اكمال الاغنية : كمل
╠${prefix}volume,vol,لتعديل صوت البوت : صوت
╠${prefix}queue,q, ل اضهار قائمة التشغي  : قائمة
╠${prefix}re, ل تشغيل وضع التكرار : تكرار
╠${prefix}forceskip,تخطي الكل,fskip: ل تخطي الكل
╠${prefix}skipto,st, ل نقل البوت : اذهب الى
╙${prefix}nowplaying,np,: القائمة الان
                    **`)
                message.author.sendEmbed(embed)
                message.reply('تم ارسالك بلخاص')
            })

        })

    }


});


client.on('message', message => {
    if (message.content == prefix + "فكك") {
        var x = ["محمد",
            "مدرسة",
            "بيت",
            "الله",
            "بيت مقدس",
            "مهندس",
            "ريضيات",
            "بسم الله رحمن رحيم",
            "طماطم",
            "سيرفر",
        ];
        var x2 = ['م ح م ح',
            "م د ر س ة",
            "ب ي ت ",
            "ا ل ل ه",
            "ب ي ت م ق د س",
            "م ه ن د س",
            "ر ي ض ي ا ت",
            "ب س م ا ل ل ه ر ح م ن ر ح ي م",
            "ط م ا ط م",
            "س ي ر ف ر",
        ];

        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(`  فكك
 :  __**${x[x3]}**__
لديك 20 ثانية`).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                maxMatches: 1,
                time: 20000,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الإجآبة الصحيحةة هي __**${x2[x3]}**__`)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author}لقد قمت بتفكيك كلمة في وقت مناسب`);
            })
        })
    }
})

client.on('message', message => {
    if (message.content.startsWith(prefix + "فواكه")) {
        let slot1 = ['🍏', '🍇', '🍒', '🍍', '🍅', '🍆', '🍑', '🍓'];
        let slots1 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
        let slots2 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
        let slots3 = `${slot1[Math.floor(Math.random() * slot1.length)]}`;
        let we;
        if (slots1 === slots2 && slots2 === slots3) {
            we = "Win!"
        } else {
            we = "Lose!"
        }
        message.channel.send(`${slots1} | ${slots2} | ${slots3} - ${we}`)
    }
});

client.on('message', message => {
    if (message.content == prefix + "عواصم") {
        var x = ["ما عاصمة **المغرب**",
            "ما عاصمة **افغانستان**",
            "ما عاصمة **الجزائر **",
            "ما عاصمة **الارجنتين",
            "ما عاصمة ** مصر**",
            "ما عاصمة ** استراليا**",
            "ما عاصمة ** البرازيل**",
            "ما عاصمة **قطر  **",
            "ما عاصمة **السعودية  **",
            "ما عاصمة **سوريا  **",
            "ما عاصمة **تركيا  **",
            "ما عاصمة **العراق  **",
            "ما عاصمة **لبنان  **",
            "ما عاصمة **فلسطين  **",
            "ما عاصمة **امريكا  **",
            "ما عاصمة **كندا  **",
            "ما عاصمة **البرازيل  **",
        ];
        var x2 = ['الرباط',
            "كابل",
            "الجزائر",
            "بوينس ايرس",
            "القاهرة",
            "كانبرا",
            "برازيليا",
            "الدوحة",
            "الرياض",
            "دمشق",
            "انقرة",
            "بغداد",
            "بيروت",
            "القدس",
            "وشنطن",
            "اوتاوا",
            "برازيليا",


        ];

        var x3 = Math.floor(Math.random() * x.length)
        message.channel.send(` اول شخص يكتب عاصمة صح :  __**${x[x3]}**__
لديك 20 ثانية لكتابة عاصمة صحيحة`).then(msg1 => {
            var r = message.channel.awaitMessages(msg => msg.content == x2[x3], {
                maxMatches: 1,
                time: 20000,
                errors: ['time']
            })
            r.catch(() => {
                return message.channel.send(`:negative_squared_cross_mark: لقد انتهى الوقت ولم يقم أحد بالأجابة بشكل صحيح 
            الإجآبة الصحيحةة هي __**${x2[x3]}**__`)
            })

            r.then((collected) => {
                message.channel.send(`${collected.first().author}لقد قمت بكتابة عاصمة صح في الوقت المناسب  `);
            })
        })
    }
})

client.on('message', message => {
    if (message.content.startsWith(prefix + "avatar")) {
        if (!message.channel.guild) return;
        var mentionned = message.mentions.users.first();
        var client;
        if (mentionned) {
            var client = mentionned;
        } else {
            var client = message.author;
        }
        const embed = new Discord.RichEmbed()
            .addField('Requested by:', "<@" + message.author.id + ">")
            .setColor(000000)
            .setImage(`${client.avatarURL}`)
        message.channel.sendEmbed(embed);
    }
});

client.on('message', message => {
    if (message.content.includes('discord.gg')) {
        if (!message.channel.guild) return message.reply('** advertising me on DM ? 🤔   **');
        if (!message.member.hasPermissions(['ADMINISTRATOR'])) {
            message.delete()
            return message.reply(`** ممنوع نشر الروابط :angry: ! **`)
        }
    }
});

client.on('message', async message => {
    if (message.content.startsWith(prefix + "setbot")) {
        if (!message.guild.member(message.author).hasPermissions('MANAGE_CHANNELS')) return message.reply('❌ **لا تمتلك صلاحيه**');
        if (!message.guild.member(client.user).hasPermissions(['MANAGE_CHANNELS', 'MANAGE_ROLES_OR_PERMISSIONS'])) return message.reply('❌ **لا امتلك صلاحيه**');
        message.channel.send('✅| **تم عمل الروم بنجاح**');
        message.guild.createChannel(`Bots : : [ ${message.guild.members.filter(m=>m.user.bot).size} ]`, 'voice').then(c => {
            console.log(`Done make room in: \n ${message.guild.name}`);
            c.overwritePermissions(message.guild.id, {
                CONNECT: false,
                SPEAK: false
            });
            setInterval(() => {
                c.setName(`Bots : [ ${message.guild.members.filter(m=>m.user.bot).size} ]`)
            }, 1000);
        });
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + 'emojilist')) {

        const List = message.guild.emojis.map(e => e.toString()).join(" ");

        const EmojiList = new Discord.RichEmbed()
            .setTitle('➠ Emojis')
            .setAuthor(message.guild.name, message.guild.iconURL)
            .setColor('RANDOM')
            .setDescription(List)
            .setFooter(message.guild.name)
        message.channel.send(EmojiList)
    }
});


client.on('message', message => {
    var cats = ["http://palestine-kitchen.ps/wp-content/uploads/2017/12/%D9%86%D9%83%D8%AA-%D8%AF%D8%A8%D8%A7%D9%86%D8%A9.png", "http://www.i7lm.com/wp-content/uploads/2017/04/136769797816.jpg", "https://4.bp.blogspot.com/-p62zmDIDXmI/WKzqNt9smaI/AAAAAAAAC4Q/sW_bSIB8OaQhwOYFeplc3uzz8PBN7l3YACEw/s1600/13602501135.jpg", "https://www.universemagic.com/images/2016/03/7938-2-or-1457539273.jpg", "https://1.bp.blogspot.com/-yFk-FzHSyE8/WR9fmPcsCUI/AAAAAAAAE6c/AmvjLadOiLY9GiCqMLHgA121bY2RS_dCwCLcB/s1600/%25D9%2586%25D9%2583%25D8%25AA%2B%25D9%2585%25D8%25B6%25D8%25AD%25D9%2583%25D8%25A9%2B1.jpg", "https://l7zaat.com/wp-content/uploads/2018/02/423.jpg", "https://www.petfinder.com/wp-content/uploads/2012/11/101438745-cat-conjunctivitis-causes.jpg", "http://www.shuuf.com/shof/uploads/2018/02/08/jpg/shof_97d686082bdb0a2.jpg"];
    var args = message.content.split(" ").slice(1);
    if (message.content.startsWith(prefix + 'نكت')) {
        var cat = new Discord.RichEmbed()
            .setImage(cats[Math.floor(Math.random() * cats.length)])
        message.channel.sendEmbed(cat);
    }
});

client.on('message', message => {
    let args = message.content.split(" ").slice(1).join(" ")
    let men = message.mentions.users.first()
    if (message.content.startsWith(prefix + "roll")) {
        if (!args) return message.channel.send("يجب كتابه رقم")
        message.channel.send(Math.floor(Math.random() * args))
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + "bans")) {
        message.guild.fetchBans()
            .then(bans => message.channel.send(`${bans.size} عدد اشخاص المبندة من السيرفر `))
            .catch(console.error);
    }
});




client.on('message', message => {
    if (message.content.startsWith(prefix + 'perms')) {
        if (!message.channel.guild) return;
        var perms = JSON.stringify(message.channel.permissionsFor(message.author).serialize(), null, 4);
        var zPeRms = new Discord.RichEmbed()
            .setColor('RANDOM')
            .setTitle(':tools: Permissions')
            .addField('Your Permissions:', perms)
        message.channel.send({ embed: zPeRms });

    }
});


client.on("message", async message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'Minv') || message.content.startsWith(prefix + 'دعواتي')) {
        var nul = 0
        var guild = message.guild
        await guild.fetchInvites()
            .then(invites => {
                invites.forEach(invite => {
                    if (invite.inviter === message.author) {
                        nul += invite.uses
                    }
                });
            });
        if (nul > 0) {
            console.log(`\n${message.author.tag} has ${nul} invites in ${guild.name}\n`)
            var embed = new Discord.RichEmbed()
                .setColor("#000000")
                .addField(`${message.author.username}`, `لقد قمت بدعوة **${nul}** شخص`)
            message.channel.send({ embed: embed });
            return;
        } else {
            var embed = new Discord.RichEmbed()
                .setColor("#000000")
                .addField(`${message.author.username}`, `لم تقم بدعوة أي شخص لهذة السيرفر`)

            message.channel.send({ embed: embed });
            return;
        }
    }
    if (message.content.startsWith(prefix + 'invitecodes')) {
        let guild = message.guild
        var codes = [""]
        message.channel.send(":postbox: **لقد قمت بأرسال جميع روابط الدعوات التي قمت بأنشائها في الخاص**")
        guild.fetchInvites()
            .then(invites => {
                invites.forEach(invite => {
                    if (invite.inviter === message.author) {
                        codes.push(`discord.gg/${invite.code}`)
                    }
                })
            }).then(m => {
                if (codes.length < 0) {
                    var embed = new Discord.RichEmbed()
                        .setColor("#000000")
                        .addField(`Your invite codes in ${message.guild.name}`, `You currently don't have any active invites! Please create an invite and start inviting, then you will be able to see your codes here!`)
                    message.author.send({ embed: embed });
                    return;
                } else {
                    var embed = new Discord.RichEmbed()
                        .setColor("#000000")
                        .addField(`Your invite codes in ${message.guild.name}`, `Invite Codes:\n${codes.join("\n")}`)
                    message.author.send({ embed: embed });
                    return;
                }
            })
    }

});


client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'bc')) {
        if (!message.channel.guild) return message.channel.send('**هذا الأمر فقط للسيرفرات**').then(m => m.delete(5000));
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('**للأسف لا تمتلك صلاحية** `ADMINISTRATOR`');
        let args = message.content.split(" ").join(" ").slice(2 + prefix.length);
        let copy = "ScrpitBot";
        let request = `Requested By ${message.author.username}`;
        if (!args) return message.reply('**يجب عليك كتابة كلمة او جملة لإرسال البرودكاست**');
        message.channel.send(`**هل أنت متأكد من إرسالك البرودكاست؟ \nمحتوى البرودكاست:** \` ${args}\``).then(msg => {
            msg.react('✅')
                .then(() => msg.react('❌'))
                .then(() => msg.react('✅'))

            let reaction1Filter = (reaction, user) => reaction.emoji.name === '✅' && user.id === message.author.id;
            let reaction2Filter = (reaction, user) => reaction.emoji.name === '❌' && user.id === message.author.id;
            let reaction1 = msg.createReactionCollector(reaction1Filter, { time: 12000 });
            let reaction2 = msg.createReactionCollector(reaction2Filter, { time: 12000 });
            reaction1.on("collect", r => {
                message.channel.send(`☑ | Done ... The Broadcast Message Has Been Sent For ${message.guild.members.size} Members`).then(m => m.delete(5000));
                message.guild.members.forEach(m => {
                    var bc = new
                    Discord.RichEmbed()
                        .setColor('RANDOM')
                        .setTitle('Broadcast')
                        .addField('Server', message.guild.name)
                        .addField('Sender', message.author.username)
                        .addField('Message', args)
                        .setThumbnail(message.author.avatarURL)
                        .setFooter(copy, client.user.avatarURL);
                    m.send({ embed: bc })
                    msg.delete();
                })
            })
            reaction2.on("collect", r => {
                message.channel.send(`**Broadcast Canceled.**`).then(m => m.delete(5000));
                msg.delete();
            })
        })
    }
});
client.on('message', message => {
    if (!message.channel.guild) return;
    if (message.content.startsWith(prefix + 'bk')) {
        if (!message.channel.guild) return message.channel.send('**هذا الأمر فقط للسيرفرات**').then(m => m.delete(5000));
        if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('**للأسف لا تمتلك صلاحية** `ADMINISTRATOR`');
        let args = message.content.split(" ").join(" ").slice(2 + prefix.length);
        let BcList = new Discord.RichEmbed()
            .setThumbnail(message.author.avatarURL)
            .setAuthor(`محتوى الرساله ${args}`)
            .setDescription(`برودكاست بـ امبد 📝\nبرودكاست بدون امبد✏ \nلديك دقيقه للأختيار قبل الغاء البرودكاست`)
        if (!args) return message.reply('**يجب عليك كتابة كلمة او ��ملة لإرسال البرودكاست**');
        message.channel.send(BcList).then(msg => {
            msg.react('📝')
                .then(() => msg.react('✏'))
                .then(() => msg.react('📝'))

            let EmbedBcFilter = (reaction, user) => reaction.emoji.name === '📝' && user.id === message.author.id;
            let NormalBcFilter = (reaction, user) => reaction.emoji.name === '✏' && user.id === message.author.id;

            let EmbedBc = msg.createReactionCollector(EmbedBcFilter, { time: 60000 });
            let NormalBc = msg.createReactionCollector(NormalBcFilter, { time: 60000 });

            EmbedBc.on("collect", r => {
                message.channel.send(`:ballot_box_with_check: تم ارسال الرساله بنجاح`).then(m => m.delete(5000));
                message.guild.members.forEach(m => {
                    var bc = new
                    Discord.RichEmbed()
                        .setColor('RANDOM')
                        .setDescription(`Message : ${args}`)
                        .setAuthor(`Server : ${message.guild.name}`)
                        .setFooter(`Sender : ${message.author.username}`)
                        .setThumbnail(message.author.avatarURL)
                    m.send({ embed: bc })
                    msg.delete();
                })
            })
            NormalBc.on("collect", r => {
                message.channel.send(`:ballot_box_with_check: تم ارسال الرساله بنجاح`).then(m => m.delete(5000));
                message.guild.members.forEach(m => {
                    m.send(args);
                    msg.delete();
                })
            })
        })
    }
});
client.on('message', message => {
    if (message.author.bot) return;

    if (message.content.startsWith(prefix + "rolebc")) {
        if (!message.member.hasPermission("ADMINISTRATOR")) return;
        let args = message.content.split(" ").slice(2);
        var codes = args.join(' ')

        if (!codes) {
            message.channel.send("قم بكتابة الرسالة | !rolebc @everyone message")
            return;
        }


        var role = message.mentions.roles.first();
        if (!role) {
            message.reply("لا توجد رتبة بهذا الاسم")
            return;
        }
        message.guild.members.filter(m => m.roles.get(role.id)).forEach(n => {
            n.send(
                "**" + "السيرفر :" + "\n" +
                `${message.guild.name}` + "\n" +
                "المرسل :" + "\n" +
                `${message.author.tag}` + "\n" +
                "الرسالة :" + "\n" +
                `${codes}` + "**"
            )
        })
        message.channel.send(`لقد تم ارسال هذه الرسالة الى ${message.guild.members.filter(m => m.roles.get(role.id)).size} عضو`)
    }
});

client.on('message', message => {
            if (message.content.startsWith(prefix + 'topinv')) {
                message.guild.fetchInvites().then(i => {
                            var invites = [];

                            i.forEach(inv => {
                                var [invs, i] = [{}, null];

                                if (inv.maxUses) {
                                    invs[inv.code] = +inv.uses + "/" + inv.maxUses;
                                } else {
                                    invs[inv.code] = +inv.uses;
                                }
                                invites.push(`invite: ${inv.url} inviter: ${inv.inviter} \`${invs[inv.code]}\`;`);

                            });
                            var embed = new Discord.RichEmbed()
                                .setColor("#000000")
                                .setDescription(`${invites.join(`\n`)+'\n\n**By:** '+message.author}`)
  .setThumbnail("https://cdn.discordapp.com/attachments/442414506430169098/489929808244113409/JPEG_20180913_232108.jpg")
           message.channel.send({ embed: embed });
   
  });
   
    }
  });

client.on('message',async message => {
    if(message.content.startsWith(prefix + "setmember")) {
    if(!message.guild.member(message.author).hasPermissions('MANAGE_CHANNELS')) return message.reply('❌ **لا تمتلك صلاحيه**');
    if(!message.guild.member(client.user).hasPermissions(['MANAGE_CHANNELS','MANAGE_ROLES_OR_PERMISSIONS'])) return message.reply('❌ **لا امتلك صلاحيه**');
    message.channel.send('✅| **تم عمل الروم بنجاح**');
    message.guild.createChannel(`Members : [ ${message.guild.members.size} ]` , 'voice').then(c => {
      console.log(`Done make room in: \n ${message.guild.name}`);
      c.overwritePermissions(message.guild.id, {
        CONNECT: false,
        SPEAK: false
      });
      setInterval(() => {
        c.setName(`Members : [ ${message.guild.members.size} ]`)
      },1000);
    });
    }
  });

client.on('message', message => {
if(message.content === prefix + 'quran'||message.content === prefix + 'القران') {
	let pages = ['http://quran.ksu.edu.sa/ayat/safahat1/1.png','http://quran.ksu.edu.sa/ayat/safahat1/2.png','http://quran.ksu.edu.sa/ayat/safahat1/3.png','http://quran.ksu.edu.sa/ayat/safahat1/4.png','http://quran.ksu.edu.sa/ayat/safahat1/5.png','http://quran.ksu.edu.sa/ayat/safahat1/6.png','http://quran.ksu.edu.sa/ayat/safahat1/7.png','http://quran.ksu.edu.sa/ayat/safahat1/8.png','http://quran.ksu.edu.sa/ayat/safahat1/9.png','http://quran.ksu.edu.sa/ayat/safahat1/10.png','http://quran.ksu.edu.sa/ayat/safahat1/11.png','http://quran.ksu.edu.sa/ayat/safahat1/12.png','http://quran.ksu.edu.sa/ayat/safahat1/13.png','http://quran.ksu.edu.sa/ayat/safahat1/14.png','http://quran.ksu.edu.sa/ayat/safahat1/15.png','http://quran.ksu.edu.sa/ayat/safahat1/16.png','http://quran.ksu.edu.sa/ayat/safahat1/17.png','http://quran.ksu.edu.sa/ayat/safahat1/18.png','http://quran.ksu.edu.sa/ayat/safahat1/19.png','http://quran.ksu.edu.sa/ayat/safahat1/20.png','http://quran.ksu.edu.sa/ayat/safahat1/21.png','http://quran.ksu.edu.sa/ayat/safahat1/22.png','http://quran.ksu.edu.sa/ayat/safahat1/23.png','http://quran.ksu.edu.sa/ayat/safahat1/24.png','http://quran.ksu.edu.sa/ayat/safahat1/25.png','http://quran.ksu.edu.sa/ayat/safahat1/26.png','http://quran.ksu.edu.sa/ayat/safahat1/27.png','http://quran.ksu.edu.sa/ayat/safahat1/28.png','http://quran.ksu.edu.sa/ayat/safahat1/29.png','http://quran.ksu.edu.sa/ayat/safahat1/30.png','http://quran.ksu.edu.sa/ayat/safahat1/31.png','http://quran.ksu.edu.sa/ayat/safahat1/32.png','http://quran.ksu.edu.sa/ayat/safahat1/33.png','http://quran.ksu.edu.sa/ayat/safahat1/34.png','http://quran.ksu.edu.sa/ayat/safahat1/35.png','http://quran.ksu.edu.sa/ayat/safahat1/36.png','http://quran.ksu.edu.sa/ayat/safahat1/37.png','http://quran.ksu.edu.sa/ayat/safahat1/38.png','http://quran.ksu.edu.sa/ayat/safahat1/39.png','http://quran.ksu.edu.sa/ayat/safahat1/40.png','http://quran.ksu.edu.sa/ayat/safahat1/41.png','http://quran.ksu.edu.sa/ayat/safahat1/42.png','http://quran.ksu.edu.sa/ayat/safahat1/43.png','http://quran.ksu.edu.sa/ayat/safahat1/44.png','http://quran.ksu.edu.sa/ayat/safahat1/45.png','http://quran.ksu.edu.sa/ayat/safahat1/46.png','http://quran.ksu.edu.sa/ayat/safahat1/47.png','http://quran.ksu.edu.sa/ayat/safahat1/48.png','http://quran.ksu.edu.sa/ayat/safahat1/49.png','http://quran.ksu.edu.sa/ayat/safahat1/50.png','http://quran.ksu.edu.sa/ayat/safahat1/51.png','http://quran.ksu.edu.sa/ayat/safahat1/52.png','http://quran.ksu.edu.sa/ayat/safahat1/53.png','http://quran.ksu.edu.sa/ayat/safahat1/55.png','http://quran.ksu.edu.sa/ayat/safahat1/56.png','http://quran.ksu.edu.sa/ayat/safahat1/57.png','http://quran.ksu.edu.sa/ayat/safahat1/58.png','http://quran.ksu.edu.sa/ayat/safahat1/59.png','http://quran.ksu.edu.sa/ayat/safahat1/60.png','http://quran.ksu.edu.sa/ayat/safahat1/60.png','http://quran.ksu.edu.sa/ayat/safahat1/61.png','http://quran.ksu.edu.sa/ayat/safahat1/62.png','http://quran.ksu.edu.sa/ayat/safahat1/63.png','http://quran.ksu.edu.sa/ayat/safahat1/64.png','http://quran.ksu.edu.sa/ayat/safahat1/65.png','http://quran.ksu.edu.sa/ayat/safahat1/66.png','http://quran.ksu.edu.sa/ayat/safahat1/67.png','http://quran.ksu.edu.sa/ayat/safahat1/68.png','http://quran.ksu.edu.sa/ayat/safahat1/69.png','http://quran.ksu.edu.sa/ayat/safahat1/70.png','http://quran.ksu.edu.sa/ayat/safahat1/71.png','http://quran.ksu.edu.sa/ayat/safahat1/72.png','http://quran.ksu.edu.sa/ayat/safahat1/73.png','http://quran.ksu.edu.sa/ayat/safahat1/74.png','http://quran.ksu.edu.sa/ayat/safahat1/75.png','http://quran.ksu.edu.sa/ayat/safahat1/76.png','http://quran.ksu.edu.sa/ayat/safahat1/77.png','http://quran.ksu.edu.sa/ayat/safahat1/78.png','http://quran.ksu.edu.sa/ayat/safahat1/79.png','http://quran.ksu.edu.sa/ayat/safahat1/80.png','http://quran.ksu.edu.sa/ayat/safahat1/81.png','http://quran.ksu.edu.sa/ayat/safahat1/82.png','http://quran.ksu.edu.sa/ayat/safahat1/83.png','http://quran.ksu.edu.sa/ayat/safahat1/84.png','http://quran.ksu.edu.sa/ayat/safahat1/85.png','http://quran.ksu.edu.sa/ayat/safahat1/86.png','http://quran.ksu.edu.sa/ayat/safahat1/87.png','http://quran.ksu.edu.sa/ayat/safahat1/88.png','http://quran.ksu.edu.sa/ayat/safahat1/89.png','http://quran.ksu.edu.sa/ayat/safahat1/90.png','http://quran.ksu.edu.sa/ayat/safahat1/91.png','http://quran.ksu.edu.sa/ayat/safahat1/92.png','http://quran.ksu.edu.sa/ayat/safahat1/93.png','http://quran.ksu.edu.sa/ayat/safahat1/94.png','http://quran.ksu.edu.sa/ayat/safahat1/95.png','http://quran.ksu.edu.sa/ayat/safahat1/96.png','http://quran.ksu.edu.sa/ayat/safahat1/97.png','http://quran.ksu.edu.sa/ayat/safahat1/98.png','http://quran.ksu.edu.sa/ayat/safahat1/99.png','http://quran.ksu.edu.sa/ayat/safahat1/100.png','http://quran.ksu.edu.sa/ayat/safahat1/101.png','http://quran.ksu.edu.sa/ayat/safahat1/102.png','http://quran.ksu.edu.sa/ayat/safahat1/103.png','http://quran.ksu.edu.sa/ayat/safahat1/104.png','http://quran.ksu.edu.sa/ayat/safahat1/105.png','http://quran.ksu.edu.sa/ayat/safahat1/106.png','http://quran.ksu.edu.sa/ayat/safahat1/107.png','http://quran.ksu.edu.sa/ayat/safahat1/108.png','http://quran.ksu.edu.sa/ayat/safahat1/109.png','http://quran.ksu.edu.sa/ayat/safahat1/110.png','http://quran.ksu.edu.sa/ayat/safahat1/111.png','http://quran.ksu.edu.sa/ayat/safahat1/112.png','http://quran.ksu.edu.sa/ayat/safahat1/113.png','http://quran.ksu.edu.sa/ayat/safahat1/114.png','http://quran.ksu.edu.sa/ayat/safahat1/115.png','http://quran.ksu.edu.sa/ayat/safahat1/116.png','http://quran.ksu.edu.sa/ayat/safahat1/117.png','http://quran.ksu.edu.sa/ayat/safahat1/118.png','http://quran.ksu.edu.sa/ayat/safahat1/119.png','http://quran.ksu.edu.sa/ayat/safahat1/120.png','http://quran.ksu.edu.sa/ayat/safahat1/121.png','http://quran.ksu.edu.sa/ayat/safahat1/122.png','http://quran.ksu.edu.sa/ayat/safahat1/123.png','http://quran.ksu.edu.sa/ayat/safahat1/124.png','http://quran.ksu.edu.sa/ayat/safahat1/125.png','http://quran.ksu.edu.sa/ayat/safahat1/126.png','http://quran.ksu.edu.sa/ayat/safahat1/127.png','http://quran.ksu.edu.sa/ayat/safahat1/128.png','http://quran.ksu.edu.sa/ayat/safahat1/129.png','http://quran.ksu.edu.sa/ayat/safahat1/130.png','http://quran.ksu.edu.sa/ayat/safahat1/131.png','http://quran.ksu.edu.sa/ayat/safahat1/132.png','http://quran.ksu.edu.sa/ayat/safahat1/133.png','http://quran.ksu.edu.sa/ayat/safahat1/134.png','http://quran.ksu.edu.sa/ayat/safahat1/135.png','http://quran.ksu.edu.sa/ayat/safahat1/136.png','http://quran.ksu.edu.sa/ayat/safahat1/137.png','http://quran.ksu.edu.sa/ayat/safahat1/138.png','http://quran.ksu.edu.sa/ayat/safahat1/139.png','http://quran.ksu.edu.sa/ayat/safahat1/140.png','http://quran.ksu.edu.sa/ayat/safahat1/141.png','http://quran.ksu.edu.sa/ayat/safahat1/142.png','http://quran.ksu.edu.sa/ayat/safahat1/143.png','http://quran.ksu.edu.sa/ayat/safahat1/144.png','http://quran.ksu.edu.sa/ayat/safahat1/145.png','http://quran.ksu.edu.sa/ayat/safahat1/146.png','http://quran.ksu.edu.sa/ayat/safahat1/147.png','http://quran.ksu.edu.sa/ayat/safahat1/148.png','http://quran.ksu.edu.sa/ayat/safahat1/149.png','http://quran.ksu.edu.sa/ayat/safahat1/150.png','http://quran.ksu.edu.sa/ayat/safahat1/151.png','http://quran.ksu.edu.sa/ayat/safahat1/152.png','http://quran.ksu.edu.sa/ayat/safahat1/153.png','http://quran.ksu.edu.sa/ayat/safahat1/154.png','http://quran.ksu.edu.sa/ayat/safahat1/155.png','http://quran.ksu.edu.sa/ayat/safahat1/156.png','http://quran.ksu.edu.sa/ayat/safahat1/157.png','http://quran.ksu.edu.sa/ayat/safahat1/158.png','http://quran.ksu.edu.sa/ayat/safahat1/159.png','http://quran.ksu.edu.sa/ayat/safahat1/160.png','http://quran.ksu.edu.sa/ayat/safahat1/161.png','http://quran.ksu.edu.sa/ayat/safahat1/162.png','http://quran.ksu.edu.sa/ayat/safahat1/163.png','http://quran.ksu.edu.sa/ayat/safahat1/164.png','http://quran.ksu.edu.sa/ayat/safahat1/165.png','http://quran.ksu.edu.sa/ayat/safahat1/166.png','http://quran.ksu.edu.sa/ayat/safahat1/167.png','http://quran.ksu.edu.sa/ayat/safahat1/168.png','http://quran.ksu.edu.sa/ayat/safahat1/169.png','http://quran.ksu.edu.sa/ayat/safahat1/170.png','http://quran.ksu.edu.sa/ayat/safahat1/171.png','http://quran.ksu.edu.sa/ayat/safahat1/172.png','http://quran.ksu.edu.sa/ayat/safahat1/173.png','http://quran.ksu.edu.sa/ayat/safahat1/174.png','http://quran.ksu.edu.sa/ayat/safahat1/175.png','http://quran.ksu.edu.sa/ayat/safahat1/176.png','http://quran.ksu.edu.sa/ayat/safahat1/177.png','http://quran.ksu.edu.sa/ayat/safahat1/178.png','http://quran.ksu.edu.sa/ayat/safahat1/179.png','http://quran.ksu.edu.sa/ayat/safahat1/180.png','http://quran.ksu.edu.sa/ayat/safahat1/181.png','http://quran.ksu.edu.sa/ayat/safahat1/182.png','http://quran.ksu.edu.sa/ayat/safahat1/183.png','http://quran.ksu.edu.sa/ayat/safahat1/184.png','http://quran.ksu.edu.sa/ayat/safahat1/185.png','http://quran.ksu.edu.sa/ayat/safahat1/186.png','http://quran.ksu.edu.sa/ayat/safahat1/187.png','http://quran.ksu.edu.sa/ayat/safahat1/188.png','http://quran.ksu.edu.sa/ayat/safahat1/189.png','http://quran.ksu.edu.sa/ayat/safahat1/190.png','http://quran.ksu.edu.sa/ayat/safahat1/191.png','http://quran.ksu.edu.sa/ayat/safahat1/192.png','http://quran.ksu.edu.sa/ayat/safahat1/193.png','http://quran.ksu.edu.sa/ayat/safahat1/194.png','http://quran.ksu.edu.sa/ayat/safahat1/195.png','http://quran.ksu.edu.sa/ayat/safahat1/196.png','http://quran.ksu.edu.sa/ayat/safahat1/197.png','http://quran.ksu.edu.sa/ayat/safahat1/198.png','http://quran.ksu.edu.sa/ayat/safahat1/199.png','http://quran.ksu.edu.sa/ayat/safahat1/200.png']
	let page = 1;

	message.delete();

	let embed = new Discord.RichEmbed()
	.setColor('#264d00')
	.setFooter(`القراآن الكريم | صفحة رقم ${page} من اصل ${pages.length} صفحة`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png')
	.setImage(pages[page-1])


	message.channel.sendEmbed(embed).then(msg => {

		msg.react('⏮').then( r => {
			msg.react('⬅')
		.then(() => msg.react('⏹'))
		.then(() => msg.react('➡'))
		.then(() => msg.react('⏭'))

			let backwardsFilter = (reaction, user) => reaction.emoji.name === '⬅' && user.id === message.author.id;
			let forwardsFilter = (reaction, user) => reaction.emoji.name === '➡' && user.id === message.author.id;

			let sbackwardsFilter = (reaction, user) => reaction.emoji.name === '⏮' && user.id === message.author.id;
			let sforwardsFilter = (reaction, user) => reaction.emoji.name === '⏭' && user.id === message.author.id;

			let cancelFilter = (reaction, user) => reaction.emoji.name === '⏹' && user.id === message.author.id;

			let backwards = msg.createReactionCollector(backwardsFilter, { time: 0 });
			let forwards = msg.createReactionCollector(forwardsFilter, { time: 0 });

			let sbackwards = msg.createReactionCollector(sbackwardsFilter, { time: 0 });
			let sforwards = msg.createReactionCollector(sforwardsFilter, { time: 0 });

			let cancel = msg.createReactionCollector(cancelFilter, { time: 0 });

			backwards.on('collect', r => {
				if (page === 1) return;
				page--;
				embed.setImage(pages[page-1]);
				embed.setFooter(`القراآن الكريم | صفحة رقم ${page} من اصل ${pages.length} صفحة`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png');
				msg.edit(embed)
			})
			forwards.on('collect', r => {
				if (page === pages.length) return;
				page++;
				embed.setImage(pages[page-1]);
				embed.setFooter(`القراآن الكريم | صفحة رقم ${page} من اصل ${pages.length} صفحة`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png');
				msg.edit(embed)
			})
			sbackwards.on('collect', r => {
				if (page === 1) return;
				page = 1;
				embed.setImage(pages[page-1]);
				embed.setFooter(`القراآن الكريم | صفحة رقم ${page} من اصل ${pages.length} صفحة`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png');
				msg.edit(embed)
			})
			sforwards.on('collect', r => {
				if (page === pages.length) return;
				page = 200; 
				embed.setImage(pages[page-1]);
				embed.setFooter(`القراآن الكريم | صفحة رقم ${page} من اصل ${pages.length} صفحة`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png');
				msg.edit(embed)
			})
			cancel.on('collect', r => {
				embed.setDescription(`**سوف يتم إغلاق القائمة**`);
				embed.setImage('');
				embed.setFooter(`Menu will close after 3sec`, 'https://cdn.discordapp.com/attachments/404332408075190282/412722171325054996/NS1.png');
				msg.edit(embed).then(msg.delete(3000));
			})
		})
	})
}
});

client.on('message', msg => {
    if(msg.content.startsWith(prefix + 'binv')) {
    if(msg.channel.type === 'dm') return;
const user = msg.mentions.users.first();
if(!user) return msg.channel.send('``' + '**قم بتحديد بوت**' + '``')
if(!user.bot) return msg.reply('`منشن بوت`');
msg.channel.send(`**Bot InviteURL : ** https://discordapp.com/oauth2/authorize?client_id=${user.id}&scope=bot&permissions=384064`)
    }
});

client.on("message", message => {
    if (message.content === prefix + "rules"||message.content === prefix + "القوانين") {
           message.react("✅")
              message.react("❌")
     const embed = new Discord.RichEmbed() 
         .setColor("#ffff00")
         .setDescription(`
  ●▬▬▬▬▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬▬▬▬▬●
[ ★・rules   |  قوانين السيرفر  ]
1) ممنوع السب مع اى سبب 
2)ممنوع الحديث عن الدين او سبه او مفاوضات دينيه 
5)ممنوع التحدث عن السياسه  "
6)ممنوع الصور الاباحيه او اى شي مخل بالادب 
7)ممنوع نشر صور من  مواقع التواصل الاجتماعى  بحقوق ملكيه
8)ممنوع طلب الرتبه والرتب تكون بالتفاعل
9)لاستخدام البوت  فى روم الاوامر
__

@everyone || @here
●▬▬▬▬▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬▬▬▬▬●
  
    `)
   
      message.channel.sendEmbed(embed)
      
      }
}); 




		
        client.on('guildMemberRemove', member => {
            var embed = new Discord.RichEmbed()
            .setAuthor(member.user.username, member.user.avatarURL)
            .setThumbnail(member.user.avatarURL)
            .setTitle(`الله معاك ✋:skin-tone-1: 😔`)
            .setDescription(`مع السلامه تشرفنا بك ✋:skin-tone-1: 😔 `)
            .addField('👤   تبقي',`**[ ${member.guild.memberCount} ]**`,true)
            .setColor('RED')
            .setFooter(`==== نــتــمــنــآ لــكــم آســتــمـــتــآع ====`, 'https://cdn.discordapp.com/attachments/397818254439219217/399292026782351381/shy.png')
        
        var channel =member.guild.channels.find('name', 'leave')
        if (!channel) return;
        channel.send({embed : embed});
        })

const HeRo = new Discord.Client();
client.on('message', message => {
    if (message.content === prefix + "date"||message.content === prefix + "التاريخ") {
        if (!message.channel.guild) return message.reply('** This command only for servers **');  
        var currentTime = new Date(),
            Year = currentTime.getFullYear(),
            Month = currentTime.getMonth() + 1,
            Day = currentTime.getDate();

            var Date15= new Discord.RichEmbed()
            .setTitle("**!-[ التاريخ ]-! **")
            .setColor('RANDOM')
            .setTimestamp()
            .setDescription( ""+ Day + "-" + Month + "-" + Year + "")
             message.channel.sendEmbed(Date15);
    }
});

client.on('message', msg => {
                        let args = msg.content.split(" ").slice(1).join(" ")
if (msg.content.split(" ")[0].toLowerCase() === prefix + "cr") {
    if(!args) return msg.channel.send('`الرجاء كتابة عدد اللوان المرجى صنعها`');
             if (!msg.member.hasPermission('MANAGE_ROLES')) return;
              msg.channel.send(`** تم انشاء الرتب بي نجاح ${args}**`);
                  setInterval(function(){})
                    let count = 0;
                    let ecount = 0;
          for(let x = 1; x < `${parseInt(args)+1}`; x++){
            msg.guild.createRole({name:x,
              color: 'RANDOM'})
              }
            }
});

client.on('message', message => {
          let args = message.content.split(' ').slice(1);
   if(message.content.split(' ')[0] == prefix + 'color'){
           const embedd = new Discord.RichEmbed()
     .setFooter('Requested by '+message.author.username, message.author.avatarURL)
   .setDescription(`**There's No Color With This Number ** :x: `)
   .setColor(`ff0000`)

    if(!isNaN(args) && args.length > 0)
    

if    (!(message.guild.roles.find("name",`${args}`))) return  message.channel.sendEmbed(embedd);


       var a = message.guild.roles.find("name",`${args}`)
                if(!a)return;
const embed = new Discord.RichEmbed()
                    
     .setFooter('Requested by '+message.author.username, message.author.avatarURL)
   .setDescription(`**Color Changed To Successfully** :white_check_mark: `)
 
   .setColor(`${a.hexColor}`)
  message.channel.sendEmbed(embed);
          if (!args)return;
setInterval(function(){})
                  let count = 0;
                  let ecount = 0;
        for(let x = 1; x < 201; x++){
           
            message.member.removeRole(message.guild.roles.find("name",`${x}`))
          
            }
                message.member.addRole(message.guild.roles.find("name",`${args}`));
        
            
    }
});

client.on('message', message => {
    if (message.content.startsWith(prefix + 'sug')) {
        if (message.author.bot) return
        if (!message.guild) return message.reply('**:x: This Commands Just In Server**').then(v => {v.react('❌')})
        var args =  message.content.split(' ').slice(1).join(' ')
        if (!args) return message.reply('Type You Suggestion').then(c => {c.delete(5000)})
        let Room = message.guild.channels.find(`name`, "suggestions")
        if (!Room) return message.channel.send("Can't find suggestions channel.").then(d => d.react('❌'))
        let embed = new Discord.RichEmbed()
        .setColor('RANDOM')
        .setAuthor(`Vote on ${message.author.username}'s suggestion`, message.author.avatarURL)
       .addField('**Suggestion**',`${args}`)
       .setThumbnail(message.author.avatarURL)
       .setFooter(`ID: ${message.author.id}`)
       Room.sendEmbed(embed).then(c => {
           c.react('✅').then(() =>
               c.react('❌'))
           
       }).catch(e => console.error(e)
       )
   }
});

client.on('message', message => {
    if (message.author.bot) return;
     if (message.content === prefix + "email") {
function randomem() {
let email = '';
const ReBeL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._';
for (let i = 0; i < 5; i++) email += ReBeL.charAt(Math.floor(Math.random() * ReBeL.length));
return email;
}
function randompass() {
let pass = '';
const CoDeS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
for (let i = 0; i < 8; i++) pass += CoDeS.charAt(Math.floor(Math.random() * CoDeS.length));
return pass;
}
const random1 = randomem();
const random2 = randompass();
message.author.send(`P.P.------------------------P.P.
Email : **${random1}@gmail.com**
Password : **${random2}**
P.P.------------------------P.P.`).catch(err => {
   if(err == "DiscordAPIError: Cannot send messages to this user") {
      return message.channel.send("**للأسف , لديك اعدادات خصوصية لاتسمح لي بأرسال رسائل خاصة لك **");
}
});

message.channel.send("**تم الارسال الحساب في الخاص | ☑ **")
}});

client.on('message', message => {
   if(message.channel.type === "dm") return;
     if(message.content.startsWith (prefix + "marry")||message.content.startsWith (prefix + "زواج")) {
     if(!message.channel.guild) return message.reply(' This command only for servers ')
     var proposed = message.mentions.members.first()
 
     if(!message.mentions.members.first()) return message.reply('لازم تطلب ايد وحدة').catch(console.error);
     if(message.mentions.users.size > 1) return message.reply('ولد ما يضبط لازم بنت').catch(console.error);
      if(proposed === message.author) return message.reply(`**خنتى ؟ **`);
       if(proposed === client.user) return message.reply(`** تبي تتزوجني؟ **`);
             message.channel.send(`**${proposed}
بدك تقبلي عرض الزواج من ${message.author}
العرض لمدة 10 ثواني
اكتبي موافقه او لا**`)
 
const filter = m => m.content.startsWith("موافقه");
message.channel.awaitMessages(filter, { max: 1, time: 15000, errors: ['time'] })
.then(collected =>{
   message.channel.send(`**${message.author} و ${proposed} الف الف مبروك انشاء الله تستمتعون بحياتكم الزوجية ويطول اعماركم ولا تنسون شهر العسل**`);
})
  .catch(collected => message.channel.send(`**السكوت علامة الرضا نقول مبرووك**`))
 
  const filte = m => m.content.startsWith("لا");
message.channel.awaitMessages(filte, { max: 1, time: 15000, errors: ['time'] })
.then(collected =>{
  message.channel.send(`**${message.author} تم رفض عرضك**`);
})
 
 
 
 
 }
});


 

client.on('message', function(message) {
    if(message.content.startsWith(prefix + "report")) {
        let messageArgs = message.content.split(" ").slice(1).join(" ");
        let messageReason = message.content.split(" ").slice(2).join(" ");
        if(!messageReason) return message.reply("** Specify a reason!**");
    let mUser = message.mentions.users.first();
    if(!mUser) return message.channel.send("Couldn't find user.");
    let Rembed = new Discord.RichEmbed()
    .setTitle("`New Report!`")
    .setThumbnail(message.author.avatarURL)
    .addField("**# - Reported User:**",mUser,true)
    .addField("**# - Reported User ID:**",mUser.id,true)
    .addField("**# - Reason:**",messageReason,true)
    .addField("**# - Channel:**",message.channel,true)
    .addField("**# - Time:**",message.createdAt,true)
    .setFooter("لو ان الابلاغ فيه مزح راح يتعرض صاحب الابلاغ لقوبات")
message.channel.send(Rembed)
message.channel.send("__Are you sure you want to send this to the Server owner??__").then(msg => {
    msg.react("✅")
    msg.react("❌")
.then(() => msg.react('❌'))
.then(() =>msg.react('✅'))
let reaction1Filter = (reaction, user) => reaction.emoji.name === '✅' && user.id === message.author.id;
let reaction2Filter = (reaction, user) => reaction.emoji.name === '❌' && user.id === message.author.id;

let reaction1 = msg.createReactionCollector(reaction1Filter, { time: 12000 });
let reaction2 = msg.createReactionCollector(reaction2Filter, { time: 12000 });
reaction1.on("collect", r => {
    message.guild.owner.send(Rembed)
    message.reply("**# - Done! 🎇**");
})
reaction2.on("collect", r => {
    message.reply("**# - Canceled!**");
})
})
}
});




client.on('message', message => {
        if(message.content.startsWith(prefix + 'hypixel')) {
            let args = message.content.split(' ').slice(1).join(' ');
            if (!args) return message.channel.send("**Please provide a Minecraft username. ❌**");
            var link = (`https://hypixel.net/player/${args}`);
            message.channel.send(link);
        }
    });
client.on('message',  (message) => {
        if(message.content.startsWith(prefix + 'love')) {
  let user = message.mentions.users.first();
  if (!user) {

    return message.emit('commandUsage', message, this.help);
  }
  let loves = [
    'https://media.giphy.com/media/YDB4EF3U6i6IM/giphy.gif',
    'https://media.giphy.com/media/l41JWw65TcBGjPpRK/giphy.gif',
    'https://media.giphy.com/media/3o6gDZ9unSrDk3EuR2/giphy.gif',
    'https://media.giphy.com/media/ymkLJAxVz2la/giphy.gif',
    'https://media.giphy.com/media/ZOln4JxCoZay4/giphy.gif',
    'https://media.giphy.com/media/l0K4kWJir91VEoa1W/giphy.gif',
    'https://media.giphy.com/media/X3FmqQ7ehoCBy/giphy.gif',
    'https://media.giphy.com/media/VlzUkJJzvz0UU/giphy.gif',
    'https://media.giphy.com/media/NbPJFUS6Vkx7q/giphy.gif',
    'https://media.giphy.com/media/wDEWXcisSjrQQ/giphy.gif',
    'https://media.giphy.com/media/xT8qBuhwq0OyL7UkdW/giphy.gif',
    'https://media.giphy.com/media/gfvxlwRKH1y5q/giphy.gif',
    'https://media.giphy.com/media/PuTSgeacS3Z7i/giphy.gif',
    'https://media.giphy.com/media/l49JBwneyflgjm5zO/giphy.gif',
    'https://media.giphy.com/media/QKUA2bIAgjFgk/giphy.gif',
    'https://media.giphy.com/media/T3Uzzre7Ap0mk/giphy.gif',
    'https://media.giphy.com/media/3oeSB6pawq6G99xCXS/giphy.gif',
    'https://media.giphy.com/media/iKIgD5j0I3hMQ/giphy.gif',
    'https://media.giphy.com/media/hhHcFH0xAduCs/giphy.gif',
    'https://media.giphy.com/media/3o7qDJKIO5rSeyHhvO/giphy.gif',
    'https://media.giphy.com/media/92bGINsmjAuUE/giphy.gif',
    'https://media.giphy.com/media/bErElGdAHUmoE/giphy.gif',
    'https://media.giphy.com/media/jQqU9dCKUOdri/giphy.gif',
    'https://media.giphy.com/media/10uJ0IFxlCA06I/giphy.gif',
    'https://media.giphy.com/media/bMLGNRoAy0Yko/giphy.gif',
    'https://media.giphy.com/media/3osxYcry2fDfqyhOQ8/giphy.gif',
    'https://media.giphy.com/media/3ohs84a6AyArTscVsk/giphy.gif',
    'https://media.giphy.com/media/3o6Zt6D0wctP0kpuwg/giphy.gif',
    'https://media.giphy.com/media/4zmFt0xpke8AU/giphy.gif',
    'https://media.giphy.com/media/l3vR9O3vpOCDRo8rC/giphy.gif',
    'https://media.giphy.com/media/13sgibUDaaaEU0/giphy.gif'
  ];

  message.channel.send({
    embed: {
      description: `${message.author.username} :heart:  يعبر لك عن حبه الحقيقي   ${user.username}!`,
      image: {
        url: loves[Math.floor(Math.random() * loves.length)]
      }
    }
  }).catch(e => {
    client.log.error(e);
  })
        }  
});
client.on('message',  (message) => {
        if(message.content.startsWith(prefix + 'boom')) {
  let user = message.mentions.users.first();
  if (!user) {

    return message.emit('commandUsage', message, this.help);
  }
  let bombs = [
    'https://media.giphy.com/media/Xp98Vi5OBvhXpwA0Zp/giphy.gif',
    'https://media.giphy.com/media/POnwee2RZBWmWWCeiX/giphy.gif',
	'https://media.giphy.com/media/oywQ7OhnYupINQa0L4/giphy.gif',
    'https://media.giphy.com/media/5aLrlDiJPMPFS/giphy.gif',
	'https://media.giphy.com/media/l1BgS9aNtdCdjgkaQ/giphy.gif',
	'https://media.giphy.com/media/d0NnEG1WnnXqg/giphy.gif',
    'https://media.giphy.com/media/NmrqUdwGXPOog/giphy.gif',
	'https://media.giphy.com/media/dpnfPvaCIHBrW/giphy.gif',
	'https://media.giphy.com/media/mks5DcSGjhQ1a/giphy.gif',
    'https://media.giphy.com/media/8wfoaIjVc0FBaLu5xH/giphy.gif',
	'https://media.giphy.com/media/xThtanBNixj1O1m5oY/giphy.gif',
	'https://media.giphy.com/media/fdGkCOiM0oOqI/giphy.gif',
    'https://media.giphy.com/media/c862b2dAhJXYA/giphy.gif',
	'https://media.giphy.com/media/CepTYjGRbV1ba/giphy.gif',
	'https://media.giphy.com/media/sRGCQ7INgSD0qbTqB5/giphy.gif',
    'https://media.giphy.com/media/ZJYOwl8SbFsic/giphy.gif',
	'https://media.giphy.com/media/3oEhmKspQX9EN48HNm/giphy.gif',
	'https://media.giphy.com/media/l1KVcAP6jvP9r4MaA/giphy.gif',
    'https://media.giphy.com/media/j2mY6orBJqAdG/giphy.gif',
	'https://media.giphy.com/media/3oz8xEqn8AGAQbR0yY/giphy.gif',
	'https://media.giphy.com/media/l4lQW9KfRQscU0ds4/giphy.gif',
    'https://media.giphy.com/media/XathaB5ILqSME/giphy.gif',
	'https://media.giphy.com/media/26AHvF2p5pridaSf6/giphy.gif',
	'https://media.giphy.com/media/Nlur5uO8GkjC0/giphy.gif',
    'https://media.giphy.com/media/l1J3preURPiwjRPvG/giphy.gif',
	'https://media.giphy.com/media/8cdZit2ZcjTri/giphy.gif',
	'https://media.giphy.com/media/3o7btNa0RUYa5E7iiQ/giphy.gif',
    'https://media.giphy.com/media/V88pTEefkoOFG/giphy.gif',
    'https://media.giphy.com/media/rfWAomOTPeOo8/giphy.gif'
  ];

  message.channel.send({
    embed: {
      description: `${message.author.username} لقد تم تطير الجبه بنجاح  جبهتك طارت ${user.username}!`,
      image: {
        url: bombs[Math.floor(Math.random() * bombs.length)]
      }
    }
  }).catch(e => {
    client.log.error(e);
  })
        }  
});
client.on('message',  (message) => {
        if(message.content.startsWith(prefix + 'hug')) {
  let user = message.mentions.users.first();
  if (!user) {

    return message.emit('commandUsage', message, this.help);
  }
  let hugs = [
    'https://media.giphy.com/media/od5H3PmEG5EVq/giphy.gif',
    'https://media.giphy.com/media/13YrHUvPzUUmkM/giphy.gif',
    'https://media.giphy.com/media/wnsgren9NtITS/giphy.gif',
    'https://media.giphy.com/media/qscdhWs5o3yb6/giphy.gif',
    'https://media.giphy.com/media/hi0VuTUqLrmuc/giphy.gif',
	'https://media.giphy.com/media/xJlOdEYy0r7ZS/giphy.gif',
	'https://media.giphy.com/media/7WQQXPg6o3YNa/giphy.gif',
	'https://media.giphy.com/media/LWTxLvp8G6gzm/giphy.gif',
	'https://media.giphy.com/media/xZshtXrSgsRHy/giphy.gif',
	'https://media.giphy.com/media/BXrwTdoho6hkQ/giphy.gif',
	'https://media.giphy.com/media/10BcGXjbHOctZC/giphy.gif',
	'https://media.giphy.com/media/49mdjsMrH7oze/giphy.gif',
	'https://media.giphy.com/media/xUPGcgtKxm4PADy3Cw/giphy.gif',
	'https://media.giphy.com/media/JTjSlqiz63j5m/giphy.gif',
	'https://media.giphy.com/media/aD1fI3UUWC4/giphy.gif',
	'https://media.giphy.com/media/5eyhBKLvYhafu/giphy.gif',
	'https://media.giphy.com/media/ddGxYkb7Fp2QRuTTGO/giphy.gif',
	'https://media.giphy.com/media/pXQhWw2oHoPIs/giphy.gif',
	'https://media.giphy.com/media/ZRI1k4BNvKX1S/giphy.gif',
	'https://media.giphy.com/media/ZQN9jsRWp1M76/giphy.gif',
	'https://media.giphy.com/media/s31WaGPAmTP1e/giphy.gif',
	'https://media.giphy.com/media/wSY4wcrHnB0CA/giphy.gif',
	'https://media.giphy.com/media/aVmEsdMmCTqSs/giphy.gif',
	'https://media.giphy.com/media/C4gbG94zAjyYE/giphy.gif',
	'https://media.giphy.com/media/ArLxZ4PebH2Ug/giphy.gif',
	'https://media.giphy.com/media/kFTKQfjK4ysZq/giphy.gif',
	'https://media.giphy.com/media/vVA8U5NnXpMXK/giphy.gif',
	'https://media.giphy.com/media/2q2qHJu838EyQ/giphy.gif',
	'https://media.giphy.com/media/q3kYEKHyiU4kU/giphy.gif',
	'https://media.giphy.com/media/3ZnBrkqoaI2hq/giphy.gif',
	'https://media.giphy.com/media/ExQqjagJBoECY/giphy.gif',
    'https://media.giphy.com/media/3o6Yg5fZCGeFArIcbm/giphy.gif'
  ];

  message.channel.send({
    embed: {
      description: `${message.author.username} اداك حضن او ضمه ${user.username}!`,
      image: {
        url: hugs[Math.floor(Math.random() * hugs.length)]
      }
    }
  }).catch(e => {
    client.log.error(e);
  })
        }  
});
client.on('message',  (message) => {
        if(message.content.startsWith(prefix + 'slap')) {
  let user = message.mentions.users.first();
  if (!user) {

    return message.emit('commandUsage', message, this.help);
  }
  let slaps = [
    'https://i.giphy.com/media/3XlEk2RxPS1m8/giphy.gif',
    'https://i.giphy.com/media/mEtSQlxqBtWWA/giphy.gif',
    'https://i.giphy.com/media/j3iGKfXRKlLqw/giphy.gif',
    'https://i.giphy.com/media/2M2RtPm8T2kOQ/giphy.gif',
    'https://i.giphy.com/media/l3YSimA8CV1k41b1u/giphy.gif',
    'https://media.giphy.com/media/81kHQ5v9zbqzC/giphy.gif',
    'https://media.giphy.com/media/QYT2VEOXVyVmE/giphy.gif',
    'https://media.giphy.com/media/xUNd9HZq1itMkiK652/giphy.gif',
    'https://media.giphy.com/media/xXRDuvEcMA2JO/giphy.gif',
    'https://media.giphy.com/media/zRlGxKCCkatIQ/giphy.gif',
    'https://media.giphy.com/media/9U5J7JpaYBr68/giphy.gif',
    'https://media.giphy.com/media/q0uYk5uwJVFug/giphy.gif',
    'https://media.giphy.com/media/iREUC7qrjN4vC/giphy.gif',
    'https://media.giphy.com/media/AkKEOnHxc4IU0/giphy.gif',
    'https://media.giphy.com/media/6Fad0loHc6Cbe/giphy.gif',
    'https://media.giphy.com/media/prKt29rL7zAbe/giphy.gif',
    'https://media.giphy.com/media/LeTDEozJwatvW/giphy.gif',
    'https://media.giphy.com/media/6UTkJXBd26qiI/giphy.gif',
    'https://media.giphy.com/media/VEmm8ngZxwJ9K/giphy.gif',
    'https://media.giphy.com/media/EtdEOL3MbPbmE/giphy.gif',
    'https://media.giphy.com/media/CIvfqJqBbvliU/giphy.gif',
    'https://media.giphy.com/media/3pSKnxaDzl9Oo/giphy.gif',
    'https://media.giphy.com/media/1iw7RG8JbOmpq/giphy.gif',
    'https://media.giphy.com/media/m0VwgrO5yXxQY/giphy.gif',
    'https://media.giphy.com/media/2o855hr1xVotO/giphy.gif',
    'https://media.giphy.com/media/URBigLkgWoYzS/giphy.gif',
    'https://media.giphy.com/media/pGOdXNi6J7ML6/giphy.gif',
    'https://media.giphy.com/media/HHUd5nOFbSYtG/giphy.gif',
    'https://media.giphy.com/media/TZp6XSDusOnXG/giphy.gif',
    'https://media.giphy.com/media/wqP5TOFnOMwqQ/giphy.gif',
    'https://i.giphy.com/media/WLXO8OZmq0JK8/giphy.gif'
  ];

  message.channel.send({
    embed: {
      description: `${message.author.username} اداك بالقلم علي وشك ${user.username}!`,
      image: {
        url: slaps[Math.floor(Math.random() * slaps.length)]
      }
    }
  }).catch(e => {
    client.log.error(e);
  })
        }  
});


let cmds = {
  play: { cmd: "play", a: ["p", "شغل"] },
  skip: { cmd: "skip", a: ["s", "تخطى"] },
  stop: { cmd: "stop", a: ["ايقاف"] },
  pause: { cmd: "pause", a: ["ايقاف مؤقت"] },
  resume: { cmd: "resume", a: ["r", "كمل"] },
  volume: { cmd: "volume", a: ["vol", "صوت"] },
  queue: { cmd: "queue", a: ["q", "قائمة"] },
  repeat: { cmd: "repeat", a: ["re", "تكرار"] },
  forceskip: { cmd: "forceskip", a: ["تخطي الكل", "fskip"] },
  skipto: { cmd: "skipto", a: ["st", "اذهب الى"] },
  nowplaying: { cmd: "Nowplaying", a: ["np", "الان"] }
};

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

Object.keys(cmds).forEach(key => {
  var value = cmds[key];
  var command = value.cmd;
  client.commands.set(command, command);

  if (value.a) {
    value.a.forEach(alias => {
      client.aliases.set(alias, command);
    });
  }
});

let active = new Map();

client.on("warn", console.warn);

client.on("error", console.error);

client.on("ready", () => {
  console.log(`on`);
  console.log(`Guilds: ${client.guilds.size}`);
  console.log(`Users: ${client.users.size}`);
});

client.on("message", async msg => {
  if (msg.author.bot) return undefined;
  if (!msg.content.startsWith(prefix)) return undefined;

  const args = msg.content
    .slice(prefix.length)
    .trim()
    .split(/ +/g);
  const command = args.shift().toLowerCase();

  const url = args[1] ? args[1].replace(/<(.+)>/g, "$1") : "";

  let cmd =
    client.commands.get(command) ||
    client.commands.get(client.aliases.get(command));

  let s;

  if (cmd === "play") {
    const voiceChannel = msg.member.voiceChannel;
    if (!voiceChannel)
      return msg.channel.send(
        `:no_entry_sign: You must be listening in a voice channel to use that!`
      );
    const permissions = voiceChannel.permissionsFor(msg.client.user);
    if (!permissions.has("CONNECT")) {
      return msg.channel.send(
        `:no_entry_sign: I can't join Your voiceChannel because i don't have ` +
          "`" +
          "`CONNECT`" +
          "`" +
          ` permission!`
      );
    }

    if (!permissions.has("SPEAK")) {
      return msg.channel.send(
        `:no_entry_sign: I can't SPEAK in your voiceChannel because i don't have ` +
          "`" +
          "`SPEAK`" +
          "`" +
          ` permission!`
      );
    }

    if (url.match(/^https?:\/\/(www.youtube.com|youtube.com)\/playlist(.*)$/)) {
      const playlist = await youtube.getPlaylist(url);
      const videos = await playlist.getVideos();

      for (const video of Object.values(videos)) {
        const video2 = await youtube.getVideoByID(video.id); // eslint-disable-line no-await-in-loop
        await handleVideo(video2, msg, voiceChannel, true); // eslint-disable-line no-await-in-loop
      }
      return msg.channel.send(`Added to queue: ${playlist.title}`);
    } else {
      try {
        var video = await youtube.getVideo(url);
      } catch (error) {
        try {
          var videos = await youtube.searchVideos(args, 1);

          // eslint-disable-next-line max-depth
          var video = await youtube.getVideoByID(videos[0].id);
        } catch (err) {
          console.error(err);
          return msg.channel.send("I can't find any thing");
        }
      }

      return handleVideo(video, msg, voiceChannel);
    }

    async function handleVideo(video, msg, voiceChannel, playlist = false) {
      const serverQueue = active.get(msg.guild.id);

      //	console.log('yao: ' + Util.escapeMarkdown(video.thumbnailUrl));

      let hrs =
        video.duration.hours > 0
          ? video.duration.hours > 9
            ? `${video.duration.hours}:`
            : `0${video.duration.hours}:`
          : "";
      let min =
        video.duration.minutes > 9
          ? `${video.duration.minutes}:`
          : `0${video.duration.minutes}:`;
      let sec =
        video.duration.seconds > 9
          ? `${video.duration.seconds}`
          : `0${video.duration.seconds}`;
      let dur = `${hrs}${min}${sec}`;

      let ms = video.durationSeconds * 1000;

      const song = {
        id: video.id,
        title: video.title,
        duration: dur,
        msDur: ms,
        url: `https://www.youtube.com/watch?v=${video.id}`
      };
      if (!serverQueue) {
        const queueConstruct = {
          textChannel: msg.channel,
          voiceChannel: voiceChannel,
          connection: null,
          songs: [], ////تعديل غير اساسي
          volume: 100, //// تعديل درجة الصوت الاساسية
          requester: msg.author,
          playing: true,
          repeating: false
        };
        active.set(msg.guild.id, queueConstruct);

        queueConstruct.songs.push(song);

        try {
          var connection = await voiceChannel.join();
          queueConstruct.connection = connection;
          play(msg.guild, queueConstruct.songs[0]);
        } catch (error) {
          console.error(`I could not join the voice channel: ${error}`);
          active.delete(msg.guild.id);
          return msg.channel.send(`I cant join this voice channel`);
        }
      } else {
        serverQueue.songs.push(song);

        if (playlist) return undefined;
        if (!args) return msg.channel.send("no results.");
        else
          return msg.channel
            .send(":watch: Loading... [`" + args + "`]")
            .then(m => {
              setTimeout(() => {
                //:watch: Loading... [let]
                m.edit(
                  `:notes: Added **${song.title}**` +
                    "(` " +
                    song.duration +
                    ")`" +
                    ` to the queue at position ` +
                    `${serverQueue.songs.length}`
                );
              }, 500);
            });
      }
      return undefined;
    }

    function play(guild, song) {
      const serverQueue = active.get(guild.id);

      if (!song) {
        serverQueue.voiceChannel.leave();
        active.delete(guild.id);
        return;
      }
      //console.log(serverQueue.songs);
      if (serverQueue.repeating) {
        console.log("Repeating");
      } else {
        serverQueue.textChannel.send(
          ":notes: Added **" +
            song.title +
            "** (`" +
            song.duration +
            "`) to begin playing."
        );
      }
      const dispatcher = serverQueue.connection
        .playStream(ytdl(song.url))
        .on("end", reason => {
          //if (reason === 'Stream is not generating quickly enough.') console.log('Song ended.');
          //else console.log(reason);
          if (serverQueue.repeating) return play(guild, serverQueue.songs[0]);
          serverQueue.songs.shift();
          play(guild, serverQueue.songs[0]);
        })
        .on("error", error => console.error(error));
      dispatcher.setVolumeLogarithmic(serverQueue.volume / 100);
    }
  } else if (cmd === "stop") {
    if (msg.guild.me.voiceChannel !== msg.member.voiceChannel)
      return msg.channel.send(
        `You must be in ${msg.guild.me.voiceChannel.name}`
      );
    if (!msg.member.hasPermission("ADMINISTRATOR")) {
      msg.react("❌");
      return msg.channel.send("You don't have permission `ADMINSTRATOR`");
    }
    let queue = active.get(msg.guild.id);
    if (queue.repeating)
      return msg.channel.send(
        "Repeating Mode is on, you can't stop the music, run `" +
          `${prefix}repeat` +
          "` to turn off it."
      );
    queue.songs = [];
    queue.connection.dispatcher.end();
    return msg.channel.send(
      ":notes: The player has stopped and the queue has been cleared."
    );
  } else if (cmd === "skip") {
    let vCh = msg.member.voiceChannel;

    let queue = active.get(msg.guild.id);

    if (!vCh)
      return msg.channel.send(
        "Sorry, but you can't because you are not in voice channel"
      );

    if (!queue) return msg.channel.send("No music playing to skip it");

    if (queue.repeating)
      return msg.channel.send(
        "You can't skip it, because repeating mode is on, run " +
          `\`${prefix}forceskip\``
      );

    let req = vCh.members.size - 1;

    if (req == 1) {
      msg.channel.send("**:notes: Skipped **" + args);
      return queue.connection.dispatcher.end("Skipping ..");
    }

    if (!queue.votes) queue.votes = [];

    if (queue.votes.includes(msg.member.id))
      return msg.say(
        `You already voted for skip! ${queue.votes.length}/${req}`
      );

    queue.votes.push(msg.member.id);

    if (queue.votes.length >= req) {
      msg.channel.send("**:notes: Skipped **" + args);

      delete queue.votes;

      return queue.connection.dispatcher.end("Skipping ..");
    }

    msg.channel.send(
      `**You have successfully voted for skip! ${queue.votes.length}/${req}**`
    );
  } else if (cmd === "pause") {
    let queue = active.get(msg.guild.id);

    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send(`You are not in my voice channel.`);

    if (!queue) {
      return msg.channel.send("No music playing to pause.");
    }

    if (!queue.playing)
      return msg.channel.send(
        ":no_entry_sign: There must be music playing to use that!"
      );

    let disp = queue.connection.dispatcher;

    disp.pause("Pausing..");

    queue.playing = false;

    msg.channel.send(
      ":notes: Paused " + args + ". **Type** `" + prefix + "resume` to unpause!"
    );
  } else if (cmd === "resume") {
    let queue = active.get(msg.guild.id);

    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send(`You are not in my voice channel.`);

    if (!queue) return msg.channel.send(":notes: No music paused to resume.");

    if (queue.playing)
      return msg.channel.send(":notes: No music paused to resume.");

    let disp = queue.connection.dispatcher;

    disp.resume("Resuming..");

    queue.playing = true;

    msg.channel.send(":notes: Resumed.");
  } else if (cmd === "volume") {
    let queue = active.get(msg.guild.id);

    if (!queue || !queue.songs)
      return msg.channel.send(
        ":notes: There is no music playing to set volume."
      );

    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send(":notes: You are not in my voice channel");

    let disp = queue.connection.dispatcher;

    if (isNaN(args[0])) return msg.channel.send(":notes: Numbers only!");

    if (parseInt(args[0]) > 100)
      return msg.channel.send("You can't set the volume more than **100**.");
    //:speaker: Volume changed from 20 to 20 ! The volume has been changed from ${queue.volume} to ${args[0]}
    msg.channel.send(
      ":loud_sound: Volume has been **changed** from (`" +
        queue.volume +
        "`) to (`" +
        args[0] +
        "`)"
    );

    queue.volume = args[0];

    disp.setVolumeLogarithmic(queue.volume / 100);
  } else if (cmd === "queue") {
    let queue = active.get(msg.guild.id);

    if (!queue)
      return msg.channel.send(
        ":no_entry_sign: There must be music playing to use that!"
      );

    let embed = new Discord.RichEmbed().setAuthor(
      `${client.user.username}`,
      client.user.displayAvatarURL
    );
    let text = "";

    for (var i = 0; i < queue.songs.length; i++) {
      let num;
      if (i > 8) {
        let st = `${i + 1}`;
        let n1 = converter.toWords(st[0]);
        let n2 = converter.toWords(st[1]);
        num = `:${n1}::${n2}:`;
      } else {
        let n = converter.toWords(i + 1);
        num = `:${n}:`;
      }
      text += `${num} ${queue.songs[i].title} [${queue.songs[i].duration}]\n`;
    }
    embed.setDescription(`Songs Queue | ${msg.guild.name}\n\n ${text}`);
    msg.channel.send(embed);
  } else if (cmd === "repeat") {
    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send("You are not in my voice channel");

    let queue = active.get(msg.guild.id);

    if (!queue || !queue.songs)
      return msg.channel.send("There is no music playing to repeat it.");

    if (queue.repeating) {
      queue.repeating = false;
      return msg.channel.send(
        ":arrows_counterclockwise: **Repeating Mode** (`False`)"
      );
    } else {
      queue.repeating = true;
      return msg.channel.send(
        ":arrows_counterclockwise: **Repeating Mode** (`True`)"
      );
    }
  } else if (cmd === "forceskip") {
    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send("You are not in my voice channel");

    let queue = active.get(msg.guild.id);

    if (queue.repeating) {
      queue.repeating = false;

      msg.channel.send("ForceSkipped, Repeating mode is on.");

      queue.connection.dispatcher.end("ForceSkipping..");

      queue.repeating = true;
    } else {
      queue.connection.dispatcher.end("ForceSkipping..");

      msg.channel.send("ForceSkipped.");
    }
  } else if (cmd === "skipto") {
    let vCh = msg.member.voiceChannel;

    if (!vCh || vCh !== msg.guild.me.voiceChannel)
      return msg.channel.send("You are not in my voice channel");

    let queue = active.get(msg.guild.id);

    if (!queue.songs || queue.songs < 2)
      return msg.channel.send("There is no music to skip to.");

    if (queue.repeating)
      return msg.channel.send(
        "You can't skip, because repeating mode is on, run " +
          `\`${prefix}repeat\` to turn off.`
      );

    if (!args[0] || isNaN(args[0]))
      return msg.channel.send(
        "Please input song number to skip to it, run " +
          prefix +
          `queue` +
          " to see songs numbers."
      );

    let sN = parseInt(args[0]) - 1;

    if (!queue.songs[sN])
      return msg.channel.send("There is no song with this number.");

    let i = 1;

    msg.channel.send(
      `Skipped to: **${queue.songs[sN].title}[${queue.songs[sN].duration}]**`
    );

    while (i < sN) {
      i++;
      queue.songs.shift();
    }

    queue.connection.dispatcher.end("SkippingTo..");
  } else if (cmd === "Nowplaying") {
    let q = active.get(msg.guild.id);

    let now = npMsg(q);

    msg.channel.send(now.mes, now.embed).then(me => {
      setInterval(() => {
        let noww = npMsg(q);
        me.edit(noww.mes, noww.embed);
      }, 5000);
    });

    function npMsg(queue) {
      let m =
        !queue || !queue.songs[0] ? "No music playing." : "Now Playing...";

      const eb = new Discord.RichEmbed();

      eb.setColor(msg.guild.me.displayHexColor);

      if (!queue || !queue.songs[0]) {
        eb.setTitle("No music playing");
        eb.setDescription(
          "\u23F9 " + bar(-1) + " " + volumeIcon(!queue ? 100 : queue.volume)
        );
      } else if (queue.songs) {
        if (queue.requester) {
          let u = msg.guild.members.get(queue.requester.id);

          if (!u) eb.setAuthor("Unkown (ID:" + queue.requester.id + ")");
          else eb.setAuthor(u.user.tag, u.user.displayAvatarURL);
        }

        if (queue.songs[0]) {
          try {
            eb.setTitle(queue.songs[0].title);
            eb.setURL(queue.songs[0].url);
          } catch (e) {
            eb.setTitle(queue.songs[0].title);
          }
        }
        eb.setDescription(embedFormat(queue));
      }

      return {
        mes: m,
        embed: eb
      };
    }

    function embedFormat(queue) {
      if (!queue || !queue.songs) {
        return "No music playing\n\u23F9 " + bar(-1) + " " + volumeIcon(100);
      } else if (!queue.playing) {
        return (
          "No music playing\n\u23F9 " + bar(-1) + " " + volumeIcon(queue.volume)
        );
      } else {
        let progress = queue.connection.dispatcher.time / queue.songs[0].msDur;
        let prog = bar(progress);
        let volIcon = volumeIcon(queue.volume);
        let playIcon = queue.connection.dispatcher.paused ? "\u23F8" : "\u25B6";
        let dura = queue.songs[0].duration;

        return (
          playIcon +
          " " +
          prog +
          " `[" +
          formatTime(queue.connection.dispatcher.time) +
          "/" +
          dura +
          "]`" +
          volIcon
        );
      }
    }

    function formatTime(duration) {
      var milliseconds = parseInt((duration % 1000) / 100),
        seconds = parseInt((duration / 1000) % 60),
        minutes = parseInt((duration / (1000 * 60)) % 60),
        hours = parseInt((duration / (1000 * 60 * 60)) % 24);

      hours = hours < 10 ? "0" + hours : hours;
      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      return (hours > 0 ? hours + ":" : "") + minutes + ":" + seconds;
    }

    function bar(precent) {
      var str = "";

      for (var i = 0; i < 12; i++) {
        let pre = precent;
        let res = pre * 12;

        res = parseInt(res);

        if (i == res) {
          str += "\uD83D\uDD18";
        } else {
          str += "▬";
        }
      }

      return str;
    }

    function volumeIcon(volume) {
      if (volume == 0) return "\uD83D\uDD07";
      if (volume < 30) return "\uD83D\uDD08";
      if (volume < 70) return "\uD83D\uDD09";
      return "\uD83D\uDD0A";
    }
  }
});




client.login(process.env.TOKEN);
